# HONOR DEBLOAT 1.0.21

Sửa kết nối sau pairing; thêm Quét cổng và Kết nối lại. Quét toàn bộ app, lọc Đang bật/Đã tắt, icon và mức độ gỡ UAD-ng. Giao diện Liquid Glass gọn, cấp quyền từng dòng, tải Gboard/CH Play trực tiếp.

Android 11+, universal APK, versionCode 28. Signed with the existing production certificate.

# HONOR DEBLOAT 1.0.15

- Ghép đôi Wireless Debugging bằng mã nhập ngay trong thông báo. App tự dò cổng và kết nối lại sau khi đã ghép đôi.
- Thiết lập có thứ tự từ Google và Gboard/CH Play đến dọn ứng dụng, cấp quyền và sửa thông báo. Các mục đã hoàn tất được nhận diện hoặc xác nhận để bỏ qua.
- Danh sách app chạy nền có thể tìm kiếm, chỉnh sửa và lưu. Danh sách Debloat giữ các hàng đã dựng khi lọc và giảm hiệu ứng làm mờ ở vùng cuộn.
- APK universal, Android 11 trở lên, ký cùng chứng thư với các bản trước.

# HONOR DEBLOAT 1.0.8

- Wireless ADB: leave the pairing port blank to discover it over mDNS while the six-digit pairing dialog is open. After pairing, the app looks for the connection port and verifies the local shell identity. Manual ports remain available.
- Debloat: scan all apps, then use the removable-only filter. Permanent uninstall runs plain `pm uninstall PACKAGE`, without `--user` or `-k`, after reviewing the exact list. It excludes system apps, the active launcher and keyboard, and HONOR DEBLOAT itself. System apps can still use the existing disable controls where supported.
- The notification preset only grants the selected app's notification permission. Other permissions and app settings remain available through explicit controls.

For this workspace, run `build.ps1 -SigningProperties <path to the original release-private/signing.properties>` to build without copying the private key. Use the original signing key for an in-place upgrade.

# HONOR DEBLOAT 1.0.7 — release

## 1.0.7

- VersionCode 14; universal release signed with the existing production key. Same app behavior as the tested 1.0.6; increased version enables OTA testing from 1.0.6.
- Two application profiles: Default reads and preserves the current state; notification profile enables all supported Custom options, excluding every location permission. Profile actions include review, per-step verification and undo. HONOR startup switches still require the device settings screen.
- Profile picker uses the bundled Liquid Glass dialog instead of Android's native select popup.
- Release build, unit tests and lint passed. Profile behavior and the picker were verified on the emulator in 1.0.6. Physical HONOR was clean-installed with production 1.0.6 for testing OTA to 1.0.7.
- Current output: `dist/release-1.0.7-universal/`; private mapping: `release-records/1.0.7/`. No signing credentials or mappings are included in the source archive.

## Previous release record: 1.0.2

- Package `com.vxm.honor`, versionCode 9; Android 11+. Production RSA 3072 signing, APK Signature Scheme v3 verified.
- Launcher icon: exact user-selected HONOR neon circle reference, with bottom text changed from VIỆT NAM to DEBLOAT. WebP 512px and 18% adaptive inset to retain the full neon ring.
- R8 code shrinking/optimization/obfuscation and resource shrinking enabled. JavaScript bridge names and JNI peers required at runtime are kept; Conscrypt keeps its upstream JNI rules.
- Uses platform RSA/SHA256 signature and X.509 certificate factory through BC's certificate builder. Does not register the entire BC provider. Unused provider-discovery, PQC and certificate-reviewer resource data excluded.
- One standalone universal APK containing arm64-v8a, armeabi-v7a and x86_64. ABI splitting disabled. Native libraries are compressed to reduce APK download size and extracted by Android at install time; installed storage is larger than APK size.
- One Google Sans TTF shared by native theme and WebView; no duplicate asset font.
- Release debuggable/jniDebuggable false; WebView remote debugging disabled. WebView only serves bundled content, blocks network loads, HTTP, mixed content, file/content access and geolocation. Existing CSP, validated ADB commands, loopback-only connections and confirmation tokens retained.
- ADB identity stays in app-private no-backup storage. No analytics or remote backend. Obfuscation raises reverse-engineering effort; it cannot hide all strings/UI assets or prevent a modified APK/root access.

Cryptographic dependencies updated to Bouncy Castle 1.86 and Conscrypt 2.6.3 from Maven Central with SHA-256 checks recorded in `qa/dependency-checksums-1.0.0.json`.

1.0.2 uses the same production certificate as 1.0.0. Verified in-place update on emulator; app data is preserved.

## Signing and updates

The production signing key and its credentials are in `release-private/`, excluded from Git and source archives. Back up this folder privately; it is required to issue updates. Never distribute it or the R8 mapping alongside the public APK.

This release uses a new production certificate, not the preview debug certificate. It cannot update the old preview in place. Do not automatically uninstall the preview: uninstalling clears this app's ADB identity and saved undo history, but does not undo prior debloat. Preserve that history first if needed. Future 1.0.2+ releases must use this same production key.

Run `./build.ps1` to build/check/package the single universal APK, write SHA-256 sums and preserve mapping under `release-records/1.0.2/`. In another checkout, provide your private `release-private/signing.properties` with `storeFile`, `storePassword`, `keyAlias`, `keyPassword`; a new key cannot update this signed release. Public source archives intentionally contain no key or passwords.

## Verification

See `qa/test-results-1.0.2.txt`. Release test runner exists only in the separate instrumentation APK; it is not packaged in the release app and adds no test keep rules. It runs only on emulator. Current HONOR phone has not been changed in this release pass.

## Distribution notes

Retain third-party notices/licenses and provide the replaceable library/source bundle as applicable. The supplied Google Sans HWT contained no redistribution license; font redistribution rights have not been verified. This APK is prepared for local distribution, not submitted to Google Play. QUERY_ALL_PACKAGES and local Wireless ADB capabilities may require separate store review.

## OTA 1.0.2

The app checks https://vietng228.github.io/honor/update.json once per day and on demand. A newer compatible version offers a browser download from the fixed HTTPS /honor/downloads/ path. Android validates the APK signature when the user installs it. No silent installation. Keep versionCode increasing and sign every update with the existing private key. The WebView remains offline.
