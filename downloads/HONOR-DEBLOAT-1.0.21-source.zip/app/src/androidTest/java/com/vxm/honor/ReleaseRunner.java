package com.vxm.honor;

import android.app.*;
import android.os.*;
import android.view.*;
import android.webkit.WebView;
import org.json.*;
import java.util.concurrent.*;

/** Exercises the actual optimized APK through its local UI, without R8 keep rules for tests. */
public class ReleaseRunner extends Instrumentation {
    private WebView web;
    private Bundle args;
    @Override public void onCreate(Bundle value){args=value;super.onCreate(value);start();}
    private WebView find(View view){if(view instanceof WebView)return (WebView)view;if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){WebView result=find(group.getChildAt(i));if(result!=null)return result;}}return null;}
    private String js(String source) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);String[] result={null};
        runOnMainSync(()->web.evaluateJavascript(source,value->{result[0]=value;latch.countDown();}));
        if(!latch.await(10,TimeUnit.SECONDS))throw new Exception("WebView timeout");return result[0];
    }
    private void waitJs(String source) throws Exception {for(int i=0;i<300;i++){if("true".equals(js(source)))return;Thread.sleep(100);}throw new Exception("UI condition timeout: "+source+"; "+js("JSON.stringify(state.logs.slice(0,2))"));}
    @Override public void onStart(){Bundle result=new Bundle();
        try {
            if(!Build.FINGERPRINT.contains("generic")&&!Build.MODEL.contains("sdk_gphone"))throw new Exception("Emulator only");
            Activity activity=startActivitySync(getTargetContext().getPackageManager().getLaunchIntentForPackage("com.vxm.honor").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            runOnMainSync(()->web=find(activity.findViewById(android.R.id.content)));
            waitJs("typeof state!=='undefined' && state.catalog.length===60");
            if("true".equals(args.getString("ota"))) {
                js("call('checkUpdate')");
                waitJs("state.checkingUpdate===false && state.updateStatus==='Bạn đang dùng bản mới nhất'");
                result.putString("ota",js("JSON.stringify({version:state.version,status:state.updateStatus,downloadHidden:el('downloadUpdate').hidden})"));
                result.putString("result","PASS: optimized release checks live GitHub Pages OTA endpoint");
                finish(Activity.RESULT_OK,result); return;
            }
            if("true".equals(args.getString("pairFile"))){
                String data="";java.io.File fixture=new java.io.File(getTargetContext().getExternalFilesDir(null),"release-pair.txt");
                for(int i=0;i<1200;i++){
                    if(fixture.isFile())try(java.io.InputStream input=new java.io.FileInputStream(fixture)){
                        data=new String(input.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).trim();
                    }
                    if(data.matches("[0-9]{1,5} [0-9]{6} [0-9]{1,5}"))break;
                    Thread.sleep(100);
                }
                if(!data.matches("[0-9]{1,5} [0-9]{6} [0-9]{1,5}"))throw new Exception("Pairing fixture timeout");
                String[] parts=data.split(" ");args.putString("pairPort",parts[0]);args.putString("pairCode",parts[1]);args.putString("port",parts[2]);
                if(!fixture.delete())throw new Exception("Cannot remove pairing fixture");
            }
            if(args.containsKey("pairPort")){
                js("call('pair',"+JSONObject.quote(args.getString("pairPort"))+","+JSONObject.quote(args.getString("pairCode"))+")");
                waitJs("!state.busy && state.logs.some(l=>l.ok&&l.title==='Ghép đôi Wireless ADB')");
                result.putString("pair","PASS: SPAKE2 pairing on optimized APK");
            }
            js("call('connect',"+JSONObject.quote(args.getString("port","5555"))+")");
            waitJs("state.connected&&!state.busy");
            if("true".equals(args.getString("reconnectPort"))) {
                js("call('disconnect')");
                waitJs("!state.busy&&!state.connected");
                js("tab('connect');call('scanConnectionPort')");
                waitJs("!state.findingPort&&!!state.port");
                if(!"true".equals(js("!state.connected&&el('connectPort').value===state.port")))
                    throw new Exception("Scan must expose a port without connecting");
                js("el('connectAgain').click()");
                waitJs("state.connected&&!state.busy&&current==='tools'");
                result.putString("result","PASS: discovered local TLS port, populated input, waited for explicit connect and advanced after shell verification");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("oneButton"))) {
                js("call('disconnect')");
                waitJs("!state.busy&&!state.connected");
                js("tab('connect')");
                if(!"true".equals(js("document.querySelectorAll('#connect button').length===1&&!el('transparency')&&!el('checkUpdate')&&!el('pairPort')")))
                    throw new Exception("Connection page still contains extra controls");
                js("call('startConnection')");
                waitJs("state.connected&&!state.busy&&current==='tools'");
                result.putString("result","PASS: one-button connection, reconnect through mDNS and automatic next step");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("compactUi"))) {
                js("tab('debloat')");
                waitJs("!state.busy&&state.scannedPackages.length>100");
                if(!"true".equals(js("!el('catalogMode')&&!document.querySelector('#profileCard')&&selected.size===0")))
                    throw new Exception("Legacy catalog or profile remains");
                js("el('appFilters').open=true;openAppFilter('packageType')");
                waitJs("el('appFilterDialog').open");
                js("[...el('appFilterChoices').children].find(b=>b.textContent==='App người dùng').click()");
                if(!"true".equals(js("!el('appFilterDialog').open&&packageItems().every(p=>p.type==='user')")))
                    throw new Exception("Glass filter failed");
                js("el('packageType').value='';renderPackages();el('appFilters').open=false");
                if(!"true".equals(js("el('packages').getBoundingClientRect().height>200&&el('finishDebloat').getBoundingClientRect().bottom<document.querySelector('nav').getBoundingClientRect().top")))
                    throw new Exception("List overlaps navigation");
                js("tab('permissions');call('listUserApps')");
                waitJs("state.userApps.length>0&&!state.busy");
                if(!"true".equals(js("document.querySelectorAll('#userAppList .pkg-icon').length===state.userApps.length")))
                    throw new Exception("Permission app icons missing");
                js("choosePermissionApp('com.vxm.honor.test')");
                waitJs("state.permissionReport.id==='com.vxm.honor.test'&&!state.busy");
                if(!"true".equals(js("!el('permissionAppHeader').hidden&&!!document.querySelector('#permissionRows .permission-actions')")))
                    throw new Exception("Manual permissions missing");
                result.putString("result","PASS: no catalog/profile, no preselection, glass picker, layout bounds, app icons and manual permission rows");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("appList"))) {
                js("tab('debloat');scanAllPackages()");
                waitJs("!state.busy&&state.scannedPackages.length>100");
                if(!"true".equals(js("state.scannedPackages.some(p=>p.type==='user')&&state.scannedPackages.some(p=>p.type==='system'&&p.uid>=0)")))
                    throw new Exception("Missing package types");
                if(!"true".equals(js("state.scannedPackages.some(p=>p.id==='com.android.systemui'&&p.risk==='Unsafe')")))
                    throw new Exception("Risk classification missing");
                js("el('packageType').value='user';renderPackages()");
                if(!"true".equals(js("packageItems().length>0&&packageItems().every(p=>p.type==='user')")))
                    throw new Exception("User filter failed");
                js("el('packageType').value='system';el('packageRisk').value='Unsafe';renderPackages()");
                if(!"true".equals(js("packageItems().length>0&&packageItems().every(p=>p.type==='system'&&p.risk==='Unsafe')")))
                    throw new Exception("System/risk filter failed");
                waitJs("[...document.querySelectorAll('.pkg-icon')].some(img=>img.complete&&img.naturalWidth>0)");
                if(!"true".equals(js("document.querySelector('.pkg').getBoundingClientRect().height>=76")))
                    throw new Exception("Package row too small");
                js("details('com.android.systemui')");
                if(!"true".equals(js("el('detailRisk').textContent.includes('Unsafe')&&el('detailRiskDescription').textContent.length>10")))
                    throw new Exception("Risk details missing");
                js("el('detail').close();el('packageType').value='';el('packageRisk').value='';renderPackages()");
                result.putString("result","PASS: user/system filters, Unsafe classification, loaded app icon, larger rows and risk description");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("remoteApk"))) {
                js("call('downloadSetupApk','store')");
                waitJs("state.confirmation?.title==='Tải và cài CH Play?'");
                js("answerConfirm(true)");
                for(int i=0;i<150;i++) {
                    if("true".equals(js("!state.busy&&!state.confirmation&&['Cài APK','Tải và cài CH Play?'].includes(state.logs[0]?.title)")))break;
                    Thread.sleep(1000);
                }
                String log=js("JSON.stringify(state.logs[0])");
                if(!"true".equals(js("!state.busy&&state.logs[0]?.title==='Cài APK'&&(state.logs[0].ok||state.logs[0].detail.includes('INSTALL_FAILED_UPDATE_INCOMPATIBLE')||state.logs[0].detail.includes('INSTALL_FAILED_VERSION_DOWNGRADE'))")))
                    throw new Exception("Remote APK did not reach Android installer: "+log);
                result.putString("installer",log);
                result.putString("result","PASS: GitHub download passed size and SHA-256 checks and reached Android installer");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("stress"))) {
                js("tab('debloat');scanAllPackages()");
                waitJs("current==='debloat'&&!state.busy&&state.scannedPackages.length>100");
                js("call('listUserApps')");
                waitJs("state.userApps.length>0&&!state.busy");
                js("""
                    (() => {
                      window.stressResult=null;
                      const intervals=[], work=[];
                      const tabs=['connect','tools','debloat','permissions','journal'];
                      let previous=0, step=0;
                      function frame(now) {
                        if(previous) intervals.push(now-previous);
                        previous=now;
                        const start=performance.now();
                        if(step%12===0)tab(tabs[(step/12)%tabs.length]);
                        if(current==='debloat'){
                          el('search').value=['','android','google',''][step%4];
                          renderPackages();
                          el('packages').scrollTop+=100;
                        }
                        if(current==='permissions'){
                          el('backgroundTools').open=true;
                          el('backgroundSearch').value=['','google','honor'][step%3];
                          renderBackgroundApps();
                        }
                        work.push(performance.now()-start);
                        if(++step<240)requestAnimationFrame(frame);
                        else {
                          const sorted=[...intervals].sort((a,b)=>a-b);
                          window.stressResult={actions:step,apps:state.scannedPackages.length,
                            frameP95:sorted[Math.floor(sorted.length*.95)],maxFrame:Math.max(...intervals),
                            over50:intervals.filter(ms=>ms>50).length,maxWork:Math.max(...work),
                            horizontalOverflow:document.documentElement.scrollWidth>innerWidth};
                        }
                      }
                      requestAnimationFrame(frame);
                    })()
                    """);
                waitJs("!!window.stressResult");
                if("true".equals(js("stressResult.horizontalOverflow")))throw new Exception("Horizontal overflow");
                result.putString("stress",js("JSON.stringify(stressResult)"));
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("complete"))) {
                js("tab('debloat');scanAllPackages()");
                waitJs("!state.busy&&state.scannedPackages.some(p=>p.completeAction==='disable')");
                js("el('completeFilter').value='disable';renderPackages()");
                if(!"true".equals(js("packageItems().length>0&&packageItems().every(p=>p.completeAction==='disable')&&selected.size===0")))
                    throw new Exception("HONOR Complete filter produced unexpected packages");
                js("call('setupNotifications',false)");
                waitJs("!state.busy&&state.logs[0]?.title==='Rà soát chạy nền'");
                if(!"true".equals(js("state.logs[0].detail.includes('com.zing.zalo')&&state.logs[0].detail.includes('Giữ nút nguồn:')")))
                    throw new Exception("Notification audit incomplete");

                java.io.File apk=new java.io.File(activity.getCacheDir(),"test-store.apk");
                try {
                    try(var source=new android.os.ParcelFileDescriptor.AutoCloseInputStream(
                            getUiAutomation().executeShellCommand("cat /data/local/tmp/honor-109-test-store.apk"));
                        var dest=new java.io.FileOutputStream(apk)) {
                        byte[] buffer=new byte[65536];
                        int count;
                        while((count=source.read(buffer))!=-1)dest.write(buffer,0,count);
                    }
                    var callback=activity.getClass().getDeclaredMethod("onActivityResult",int.class,int.class,android.content.Intent.class);
                    callback.setAccessible(true);
                    var selectedFile=new android.content.Intent().setData(android.net.Uri.fromFile(apk));
                    runOnMainSync(()->{
                        try { callback.invoke(activity,72,Activity.RESULT_OK,selectedFile); }
                        catch(ReflectiveOperationException e) { throw new IllegalStateException(e); }
                    });
                    waitJs("state.confirmation?.title==='Cài CH Play?'");
                    js("answerConfirm(true)");
                    for(int i=0;i<180&&"true".equals(js("state.busy"));i++)Thread.sleep(1000);
                    waitJs("!state.busy&&state.logs[0]?.title==='Cài APK'");
                    if(!"true".equals(js("state.logs[0].detail.includes('Success')||state.logs[0].detail.includes('INSTALL_FAILED_VERSION_DOWNGRADE')||state.logs[0].detail.includes('INSTALL_FAILED_UPDATE_INCOMPATIBLE')")))
                        throw new Exception("Store transfer did not return an Android installer verdict: "+js("state.logs[0].detail"));
                    result.putString("installer",js("state.logs[0].detail"));
                } finally { apk.delete(); }
                result.putString("result","PASS: Complete filter, notification audit and actual APK transfer on emulator");
                finish(Activity.RESULT_OK,result);return;
            }
            if("true".equals(args.getString("profile"))) {
                js("tab('permissions')");waitJs("state.userApps.length>0&&!state.busy");
                js("choosePermissionApp('com.vxm.honor.test')");waitJs("state.permissionReport.id==='com.vxm.honor.test'&&!state.busy");
                String baseline=js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted");
                String notifyBaseline=js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted");
                js("el('applyDefaultProfile').click()");waitJs("!state.busy&&state.logs[0]?.title==='Mặc định'");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Default changed camera");
                if("true".equals(js("!!state.confirmation||!!state.profileBackups['com.vxm.honor.test']")))throw new Exception("Default mutated or asked to grant");
                js("openProfilePicker()");waitJs("el('profilePicker').open");
                if(!"true".equals(js("el('profilePicker').classList.contains('glass')&&getComputedStyle(el('profilePicker')).borderRadius==='32px'")))throw new Exception("Picker is not glass");
                Thread.sleep(500);
                android.graphics.Bitmap preview=getUiAutomation().takeScreenshot();
                if(preview!=null) {
                    try(java.io.FileOutputStream file=new java.io.FileOutputStream(new java.io.File(getTargetContext().getExternalFilesDir(null),"profile-picker.png"))) {
                        preview.compress(android.graphics.Bitmap.CompressFormat.PNG,100,file);
                    }
                    preview.recycle();
                }
                js("document.querySelector('[data-preset=notify]').click()");waitJs("!el('profilePicker').open&&el('profileQuickPreset').value==='notify'");
                js("el('applyDefaultProfile').click()");waitJs("!!state.confirmation&&!state.busy");js("answerConfirm(false)");waitJs("!state.confirmation");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Cancel changed camera");
                js("el('applyDefaultProfile').click()");waitJs("!!state.confirmation&&!state.busy");js("answerConfirm(true)");
                waitJs("!state.busy&&!state.confirmation&&state.profileReport.id==='com.vxm.honor.test'");
                if(!"true".equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted")))throw new Exception("Profile did not grant notifications");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Notification profile changed camera");
                if("true".equals(js("state.profileReport.text.includes('! ')")))throw new Exception("Profile partial failure: "+js("state.profileReport.text"));
                js("call('restoreProfile','com.vxm.honor.test')");waitJs("!!state.confirmation");js("answerConfirm(true)");
                waitJs("!state.busy&&!state.confirmation&&!state.profileBackups['com.vxm.honor.test']");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Camera undo failed");
                if(!notifyBaseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted")))throw new Exception("Notification undo failed");
                js("call('applyProfile','com.vxm.honor.test',JSON.stringify({permissions:['android.permission.WRITE_SECURE_SETTINGS']}))");
                waitJs("!state.busy&&state.logs[0]?.ok===false");
                if("true".equals(js("!!state.confirmation")))throw new Exception("Protected permission accepted");
                result.putString("ui",js("JSON.stringify({profileVisible:!el('profileCard').hidden,overflow:document.documentElement.scrollWidth>innerWidth})"));
                result.putString("result","PASS: default leaves current permissions unchanged; glass picker; full notification preset preselects and grants all eligible options; background/Doze/Data Saver; cancel and undo; protected-permission rejection");
                finish(Activity.RESULT_OK,result);return;
            }
            js("tab('permissions')");waitJs("state.userApps.length>0&&!state.busy");
            js("choosePermissionApp('com.vxm.honor.test')");waitJs("state.permissionReport.id==='com.vxm.honor.test'&&!state.busy");
            js("permissionAction('android.permission.CAMERA',true)");waitJs("!!state.confirmation");js("answerConfirm(true)");
            waitJs("!state.busy&&!state.confirmation&&state.permissionReport.permissions.some(p=>p.id==='android.permission.CAMERA'&&p.granted===true)");
            js("permissionAction('android.permission.CAMERA',false)");waitJs("!!state.confirmation");js("answerConfirm(true)");
            waitJs("!state.busy&&!state.confirmation&&state.permissionReport.permissions.some(p=>p.id==='android.permission.CAMERA'&&p.granted===false)");
            js("editOp('VIBRATE')");waitJs("!!state.opEditor&&!state.busy");js("closeOpEditor()");
            js("tab('debloat');selected.add('com.android.providers.partnerbookmarks');batch(true)");waitJs("!!state.confirmation");js("answerConfirm(true)");waitJs("!state.busy&&state.status['com.android.providers.partnerbookmarks']==='disabled'");
            js("batch(false)");waitJs("!!state.confirmation");js("answerConfirm(true)");waitJs("!state.busy&&!state.confirmation&&state.status['com.android.providers.partnerbookmarks']==='enabled'");
            js("scanAllPackages()");waitJs("!state.busy&&state.scannedPackages.length>60");
            js("tab('tools');call('listSystemApps')");waitJs("state.systemApps.length>0&&!state.busy");js("systemLanguageApp='com.android.settings';call('systemLocales',systemLanguageApp)");waitJs("!state.busy&&state.localeReport.id==='com.android.settings'&&state.localeReport.locales.length>1");
            String ui=js("JSON.stringify({connected:state.connected,scan:state.scannedPackages.length,locales:state.localeReport.locales.length,fontLoaded:[...document.fonts].some(f=>f.family==='Google Sans'&&f.status==='loaded'),overflow:document.documentElement.scrollWidth>innerWidth})");
            result.putString("ui",ui);result.putString("result","PASS: optimized release bridge, self ADB, camera grant/revoke, AppOps inspection, disable/exact undo, full scan, APK locales");
            finish(Activity.RESULT_OK,result);
        }catch(Throwable e){result.putString("error",android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,result);}
    }
}
