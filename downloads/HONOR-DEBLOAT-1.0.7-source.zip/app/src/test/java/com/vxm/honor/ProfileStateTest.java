package com.vxm.honor;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileStateTest {
    @Test public void currentAppOpsHonorsUidOverrides() {
        assertTrue(ProfileState.opAllowed("No operations.\nDefault mode: allow", "RUN_IN_BACKGROUND"));
        assertFalse(ProfileState.opAllowed("Uid mode: RUN_IN_BACKGROUND: ignore\nRUN_IN_BACKGROUND: allow", "RUN_IN_BACKGROUND"));
        assertFalse(ProfileState.opAllowed("Unknown operation", "RUN_IN_BACKGROUND"));
    }
    @Test public void excludesEveryLocationPermissionFromProfiles() {
        for(String name:new String[]{"ACCESS_FINE_LOCATION","ACCESS_COARSE_LOCATION","ACCESS_BACKGROUND_LOCATION","ACCESS_MEDIA_LOCATION","LOCATION_HARDWARE","ACCESS_GEOFENCE"})
            assertTrue(ProfileState.isLocationPermission("android.permission."+name));
        assertFalse(ProfileState.isLocationPermission("android.permission.ACCESS_LOCAL_NETWORK"));
        assertFalse(ProfileState.isLocationPermission("android.permission.POST_NOTIFICATIONS"));
    }
    @Test public void whitelistMatchesWholePackage() {
        String raw="user,com.zing.zalopay,123\nuser,com.zing.zalo,124\nsystem,com.other,125";
        assertTrue(ProfileState.whitelisted(raw,"com.zing.zalo"));
        assertFalse(ProfileState.whitelisted("user,com.zing.zalopay,123","com.zing.zalo"));
    }
    @Test public void uidDoesNotMatchSubstring() {
        assertTrue(ProfileState.uidListed("Restrict background whitelisted UIDs: 10284 12345",10284));
        assertFalse(ProfileState.uidListed("102840 110284",10284));
    }
    @Test public void rejectsShellSyntaxInPackage() {
        assertTrue(ProfileState.validPackage("com.zing.zalo"));
        assertFalse(ProfileState.validPackage("com.zing.zalo; reboot"));
        assertFalse(ProfileState.validPackage("com.zing.zalo --user 10"));
    }
}
