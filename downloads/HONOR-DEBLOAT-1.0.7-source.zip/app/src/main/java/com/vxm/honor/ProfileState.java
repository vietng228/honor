package com.vxm.honor;

import java.util.regex.Pattern;

final class ProfileState {
    static boolean validPackage(String id) { return id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"); }
    static boolean isLocationPermission(String id) { return id.contains("LOCATION")||id.contains("GEOFENCE")||id.contains("GPS"); }
    static boolean opAllowed(String raw,String operation) {
        AppOpState mode=AppOpState.parse(raw,operation);
        String effective=!mode.uid.equals("default")?mode.uid:!mode.app.equals("default")?mode.app:mode.fallback;
        return effective.equals("allow");
    }
    static boolean whitelisted(String raw, String id) {
        for(String line:raw.split("\\R")) {
            String[] parts=line.trim().split(",");
            if(parts.length>=2 && parts[1].equals(id))return true;
        }
        return false;
    }
    static boolean uidListed(String raw,int uid) {
        return Pattern.compile("(?<![0-9])"+uid+"(?![0-9])").matcher(raw).find();
    }
}
