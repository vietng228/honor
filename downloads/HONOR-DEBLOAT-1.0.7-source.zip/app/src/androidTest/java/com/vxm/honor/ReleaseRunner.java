package com.vxm.honor;

import android.app.*;
import android.os.*;
import android.view.*;
import android.webkit.WebView;
import org.json.*;
import java.util.concurrent.*;

/** Exercises the actual optimized APK through its local UI, without R8 keep rules for tests. */
public class ReleaseRunner extends Instrumentation {
    private WebView web;
    private Bundle args;
    @Override public void onCreate(Bundle value){args=value;super.onCreate(value);start();}
    private WebView find(View view){if(view instanceof WebView)return (WebView)view;if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){WebView result=find(group.getChildAt(i));if(result!=null)return result;}}return null;}
    private String js(String source) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);String[] result={null};
        runOnMainSync(()->web.evaluateJavascript(source,value->{result[0]=value;latch.countDown();}));
        if(!latch.await(10,TimeUnit.SECONDS))throw new Exception("WebView timeout");return result[0];
    }
    private void waitJs(String source) throws Exception {for(int i=0;i<300;i++){if("true".equals(js(source)))return;Thread.sleep(100);}throw new Exception("UI condition timeout: "+source+"; "+js("JSON.stringify(state.logs.slice(0,2))"));}
    @Override public void onStart(){Bundle result=new Bundle();
        try {
            if(!Build.FINGERPRINT.contains("generic")&&!Build.MODEL.contains("sdk_gphone"))throw new Exception("Emulator only");
            Activity activity=startActivitySync(getTargetContext().getPackageManager().getLaunchIntentForPackage("com.vxm.honor").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            runOnMainSync(()->web=find(activity.findViewById(android.R.id.content)));
            waitJs("typeof state!=='undefined' && state.catalog.length===60");
            if("true".equals(args.getString("ota"))) {
                js("call('checkUpdate')");
                waitJs("state.checkingUpdate===false && state.updateStatus==='Bạn đang dùng bản mới nhất'");
                result.putString("ota",js("JSON.stringify({version:state.version,status:state.updateStatus,downloadHidden:el('downloadUpdate').hidden})"));
                result.putString("result","PASS: optimized release checks live GitHub Pages OTA endpoint");
                finish(Activity.RESULT_OK,result); return;
            }
            if("true".equals(args.getString("pairFile"))){
                String data="";java.io.File fixture=new java.io.File(getTargetContext().getExternalFilesDir(null),"release-pair.txt");
                for(int i=0;i<1200;i++){
                    if(fixture.isFile())try(java.io.InputStream input=new java.io.FileInputStream(fixture)){
                        data=new String(input.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).trim();
                    }
                    if(data.matches("[0-9]{1,5} [0-9]{6} [0-9]{1,5}"))break;
                    Thread.sleep(100);
                }
                if(!data.matches("[0-9]{1,5} [0-9]{6} [0-9]{1,5}"))throw new Exception("Pairing fixture timeout");
                String[] parts=data.split(" ");args.putString("pairPort",parts[0]);args.putString("pairCode",parts[1]);args.putString("port",parts[2]);
                if(!fixture.delete())throw new Exception("Cannot remove pairing fixture");
            }
            if(args.containsKey("pairPort")){
                js("call('pair',"+JSONObject.quote(args.getString("pairPort"))+","+JSONObject.quote(args.getString("pairCode"))+")");
                waitJs("!state.busy && state.logs.some(l=>l.ok&&l.title==='Ghép đôi Wireless ADB')");
                result.putString("pair","PASS: SPAKE2 pairing on optimized APK");
            }
            js("call('connect',"+JSONObject.quote(args.getString("port","5555"))+")");
            waitJs("state.connected&&!state.busy");
            if("true".equals(args.getString("profile"))) {
                js("tab('permissions')");waitJs("state.userApps.length>0&&!state.busy");
                js("choosePermissionApp('com.vxm.honor.test')");waitJs("state.permissionReport.id==='com.vxm.honor.test'&&!state.busy");
                String baseline=js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted");
                String notifyBaseline=js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted");
                js("el('applyDefaultProfile').click()");waitJs("!state.busy&&state.logs[0]?.title==='Mặc định'");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Default changed camera");
                if("true".equals(js("!!state.confirmation||!!state.profileBackups['com.vxm.honor.test']")))throw new Exception("Default mutated or asked to grant");
                js("openProfilePicker()");waitJs("el('profilePicker').open");
                if(!"true".equals(js("el('profilePicker').classList.contains('glass')&&getComputedStyle(el('profilePicker')).borderRadius==='32px'")))throw new Exception("Picker is not glass");
                Thread.sleep(500);
                android.graphics.Bitmap preview=getUiAutomation().takeScreenshot();
                if(preview!=null) {
                    try(java.io.FileOutputStream file=new java.io.FileOutputStream(new java.io.File(getTargetContext().getExternalFilesDir(null),"profile-picker.png"))) {
                        preview.compress(android.graphics.Bitmap.CompressFormat.PNG,100,file);
                    }
                    preview.recycle();
                }
                js("document.querySelector('[data-preset=notify]').click()");waitJs("!el('profilePicker').open&&el('profileQuickPreset').value==='notify'");
                if(!"true".equals(js("[...el('profileCard').querySelectorAll('input[type=checkbox]')].filter(e=>!e.closest('[hidden]')).every(e=>e.checked)")))throw new Exception("Full profile did not preselect custom options");
                js("el('applyDefaultProfile').click()");waitJs("!!state.confirmation&&!state.busy");js("answerConfirm(false)");waitJs("!state.confirmation");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Cancel changed camera");
                js("el('applyDefaultProfile').click()");waitJs("!!state.confirmation&&!state.busy");js("answerConfirm(true)");
                waitJs("!state.busy&&!state.confirmation&&state.profileReport.id==='com.vxm.honor.test'");
                if(!"true".equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted&&state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Full profile did not grant notification/camera");
                if("true".equals(js("state.profileReport.text.includes('! ')")))throw new Exception("Profile partial failure: "+js("state.profileReport.text"));
                if(!"true".equals(js("state.permissionReport.current.background&&state.permissionReport.current.doze&&state.permissionReport.current.dataSaver")))throw new Exception("Full background settings did not apply");
                js("call('restoreProfile','com.vxm.honor.test')");waitJs("!!state.confirmation");js("answerConfirm(true)");
                waitJs("!state.busy&&!state.confirmation&&!state.profileBackups['com.vxm.honor.test']");
                if(!baseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.CAMERA').granted")))throw new Exception("Camera undo failed");
                if(!notifyBaseline.equals(js("state.permissionReport.permissions.find(p=>p.id==='android.permission.POST_NOTIFICATIONS').granted")))throw new Exception("Notification undo failed");
                js("call('applyProfile','com.vxm.honor.test',JSON.stringify({permissions:['android.permission.WRITE_SECURE_SETTINGS']}))");
                waitJs("!state.busy&&state.logs[0]?.ok===false");
                if("true".equals(js("!!state.confirmation")))throw new Exception("Protected permission accepted");
                result.putString("ui",js("JSON.stringify({profileVisible:!el('profileCard').hidden,overflow:document.documentElement.scrollWidth>innerWidth})"));
                result.putString("result","PASS: default leaves current permissions unchanged; glass picker; full notification preset preselects and grants all eligible options; background/Doze/Data Saver; cancel and undo; protected-permission rejection");
                finish(Activity.RESULT_OK,result);return;
            }
            js("tab('permissions')");waitJs("state.userApps.length>0&&!state.busy");
            js("choosePermissionApp('com.vxm.honor.test')");waitJs("state.permissionReport.id==='com.vxm.honor.test'&&!state.busy");
            js("permissionAction('android.permission.CAMERA',true)");waitJs("!!state.confirmation");js("answerConfirm(true)");
            waitJs("!state.busy&&!state.confirmation&&state.permissionReport.permissions.some(p=>p.id==='android.permission.CAMERA'&&p.granted===true)");
            js("permissionAction('android.permission.CAMERA',false)");waitJs("!!state.confirmation");js("answerConfirm(true)");
            waitJs("!state.busy&&!state.confirmation&&state.permissionReport.permissions.some(p=>p.id==='android.permission.CAMERA'&&p.granted===false)");
            js("editOp('VIBRATE')");waitJs("!!state.opEditor&&!state.busy");js("closeOpEditor()");
            js("tab('debloat');selected.add('com.android.providers.partnerbookmarks');batch(true)");waitJs("!!state.confirmation");js("answerConfirm(true)");waitJs("!state.busy&&state.status['com.android.providers.partnerbookmarks']==='disabled'");
            js("batch(false)");waitJs("!!state.confirmation");js("answerConfirm(true)");waitJs("!state.busy&&!state.confirmation&&state.status['com.android.providers.partnerbookmarks']==='enabled'");
            js("scanAllPackages()");waitJs("!state.busy&&state.scannedPackages.length>60");
            js("tab('tools')");waitJs("state.systemApps.length>0&&!state.busy");js("systemLanguageApp='com.android.settings';call('systemLocales',systemLanguageApp)");waitJs("!state.busy&&state.localeReport.id==='com.android.settings'&&state.localeReport.locales.length>1");
            String ui=js("JSON.stringify({connected:state.connected,scan:state.scannedPackages.length,locales:state.localeReport.locales.length,fontLoaded:[...document.fonts].some(f=>f.family==='Google Sans'&&f.status==='loaded'),overflow:document.documentElement.scrollWidth>innerWidth})");
            result.putString("ui",ui);result.putString("result","PASS: optimized release bridge, self ADB, camera grant/revoke, AppOps inspection, disable/exact undo, full scan, APK locales");
            finish(Activity.RESULT_OK,result);
        }catch(Throwable e){result.putString("error",android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,result);}
    }
}
