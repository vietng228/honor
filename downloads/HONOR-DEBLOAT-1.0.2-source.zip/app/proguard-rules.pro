# The local WebView calls these annotated methods by name.
-keepclassmembers,allowoptimization class com.vxm.honor.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
# SPAKE2 native code looks up its Java peer by the original name.
-keep class io.github.muntashirakon.crypto.spake2.Spake2Context { *; }
-keep class io.github.muntashirakon.crypto.spake2.Spake2Role { *; }
# Do not ship source filenames with the optimized application.
-renamesourcefileattribute SourceFile
