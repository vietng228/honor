package com.vxm.honor;
import org.junit.Test;
import java.io.IOException;
import static org.junit.Assert.*;
public class ApkLocalesTest {
 @Test public void decodesLanguageRegionAndPackedCodes(){assertEquals("en",ApkLocales.unpack((byte)'e',(byte)'n','a'));assertEquals("US",ApkLocales.unpack((byte)'U',(byte)'S','0'));assertEquals("fil",ApkLocales.unpack((byte)0xad,(byte)0x05,'a'));assertEquals("419",ApkLocales.unpack((byte)0xa4,(byte)0x24,'0'));}
 @Test public void unqualifiedResourcesDoNotInventEnglish(){assertEquals("",ApkLocales.unpack((byte)0,(byte)0,'a'));}
 @Test(expected=IOException.class) public void rejectsTruncatedTable()throws Exception{ApkLocales.parse(new byte[]{2,0,12,0});}
 @Test(expected=IOException.class) public void rejectsChunkOutsideTable()throws Exception{ApkLocales.parse(new byte[]{2,0,12,0,99,0,0,0,1,0,0,0});}
}
