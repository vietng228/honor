package com.vxm.honor;

import org.junit.Test;
import static org.junit.Assert.*;

public class UpdatePolicyTest {
    @Test public void permitsOnlyPublishedApks() {
        assertTrue(UpdatePolicy.allowedDownload("https://vietng228.github.io/honor/downloads/HONOR-DEBLOAT-1.0.3.apk"));
        for (String url : new String[]{"http://vietng228.github.io/honor/downloads/HONOR-DEBLOAT-1.0.3.apk",
                "https://evil.example/honor/downloads/HONOR-DEBLOAT-1.0.3.apk",
                "https://vietng228.github.io.evil.example/honor/downloads/HONOR-DEBLOAT-1.0.3.apk",
                "https://vietng228.github.io/honor/downloads/../other.apk",
                "https://vietng228.github.io/honor/downloads/HONOR-DEBLOAT-1.0.3.apk?redirect=elsewhere",
                "https://user@vietng228.github.io/honor/downloads/HONOR-DEBLOAT-1.0.3.apk"}) {
            assertFalse(url, UpdatePolicy.allowedDownload(url));
        }
    }
}
