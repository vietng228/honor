package com.vxm.honor;
import org.junit.Test;
import static org.junit.Assert.*;
public class PermissionDumpTest {
 @Test public void separatesOwnerAndOtherUsers(){
  String dump="    requested permissions:\n      android.permission.CAMERA\n      android.permission.INTERNET\n    install permissions:\n      android.permission.INTERNET: granted=true\n    User 0: installed=true\n      runtime permissions:\n        android.permission.CAMERA: granted=false, flags=[ USER_SET|USER_FIXED]\n    User 10: installed=true\n      runtime permissions:\n        android.permission.CAMERA: granted=true, flags=[ USER_SET]\n";
  var rows=PermissionDump.parse(dump);assertEquals(2,rows.size());assertEquals(Boolean.FALSE,rows.get("android.permission.CAMERA").granted);assertEquals("USER_SET|USER_FIXED",rows.get("android.permission.CAMERA").flags);assertEquals(Boolean.TRUE,rows.get("android.permission.INTERNET").granted);
 }
 @Test public void missingStateStaysUnknown(){assertNull(PermissionDump.parse("    requested permissions:\n      vendor.permission.SPECIAL\n    queries:\n      not.a.permission\n").get("vendor.permission.SPECIAL").granted);}
 @Test public void ignoresComponentAndPermissionDefinitions(){assertEquals(0,PermissionDump.parse("Permissions:\n  Permission [vendor.permission.SPECIAL]:\n    package=com.example\n    protectionLevel=signature\n").size());}
}
