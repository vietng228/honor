package com.vxm.honor;
import org.junit.Test;
import static org.junit.Assert.*;
public class AppOpStateTest {
 @Test public void separatesUidAndPackageModes(){AppOpState s=AppOpState.parse("Uid mode: CAMERA: foreground\nCAMERA: allow; time=+1s ago\n","CAMERA");assertEquals("foreground",s.uid);assertEquals("allow",s.app);}
 @Test public void omittedModesAreDefault(){AppOpState s=AppOpState.parse("No operations.\nDefault mode: allow\n","VIBRATE");assertEquals("default",s.app);assertEquals("default",s.uid);assertEquals("allow",s.fallback);}
 @Test public void matchesExactOperation(){AppOpState s=AppOpState.parse("RECORD_AUDIO: allow\nCAMERA: ignore\n","CAMERA");assertEquals("ignore",s.app);assertEquals("default",s.uid);}
 @Test public void changeablePermissionTypesAndFixedFlags(){assertTrue(PermissionDump.canChange(1,"USER_FIXED"));assertTrue(PermissionDump.canChange(34,""));assertFalse(PermissionDump.canChange(0,""));assertFalse(PermissionDump.canChange(2,""));assertFalse(PermissionDump.canChange(1,"SYSTEM_FIXED"));assertFalse(PermissionDump.canChange(1,"POLICY_FIXED"));}
}
