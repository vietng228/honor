package com.vxm.honor;

import org.junit.Test;
import java.io.IOException;
import static org.junit.Assert.*;

public class StateParsingTest {
    @Test public void readsOnlyOwnerStateForUndo() throws Exception {
        String dump="    User 0: installed=true stopped=false enabled=0 instant=false\n    User 128: installed=true enabled=3\n";
        assertEquals(0,MainActivity.enabledState(dump));
    }
    @Test(expected=IOException.class) public void refusesUndoWithoutOriginalState() throws Exception {
        MainActivity.enabledState("    User 128: installed=true enabled=3");
    }
    @Test public void parsesExactPackageNamesOnly() {
        var packages=MainActivity.packages("package:com.honor.browser\r\npackage:com.hihonor.bluetooth\nwarning: failed\n");
        assertEquals(2,packages.size());
        assertFalse(packages.contains("com.android.bluetooth"));
    }
    @Test(expected=IOException.class) public void rejectsShellTextInsteadOfPort() throws Exception {
        MainActivity.parsePort("5555; id");
    }
    @Test(expected=IOException.class) public void rejectsOutOfRangePort() throws Exception {
        MainActivity.parsePort("65536");
    }
}
