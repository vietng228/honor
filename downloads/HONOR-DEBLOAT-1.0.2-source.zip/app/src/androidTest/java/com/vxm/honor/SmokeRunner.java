package com.vxm.honor;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.webkit.WebView;
import org.json.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;

/** Emulator-only integration checks; this class is not packaged in the user APK. */
public class SmokeRunner extends Instrumentation {
    @Override public void onCreate(Bundle args) { super.onCreate(args);start(); }
    @Override public void onStart() {
        Bundle results=new Bundle(); MainActivity activity=null; LocalAdb adb=null;
        try {
            if(!android.os.Build.FINGERPRINT.contains("generic") && !android.os.Build.MODEL.contains("sdk_gphone")) throw new Exception("Emulator only");
            activity=(MainActivity)startActivitySync(new Intent().setClassName("com.vxm.honor","com.vxm.honor.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            final MainActivity a=activity;
            Thread.sleep(1500);
            Method manager=MainActivity.class.getDeclaredMethod("manager");manager.setAccessible(true);
            adb=(LocalAdb)manager.invoke(activity);
            if(!adb.connect("127.0.0.1",5555))throw new Exception("ADB connect returned false");
            String identity=adb.shell("id");
            if(!identity.contains("uid=2000(shell)"))throw new Exception("Not ADB shell: "+identity);
            Method refresh=MainActivity.class.getDeclaredMethod("refresh");refresh.setAccessible(true);refresh.invoke(activity);
            Method apps=MainActivity.class.getDeclaredMethod("loadUserApps");apps.setAccessible(true);apps.invoke(activity);
            Method permissions=MainActivity.class.getDeclaredMethod("readPermissions",String.class);permissions.setAccessible(true);permissions.invoke(activity,"com.vxm.honor");
            Method render=MainActivity.class.getDeclaredMethod("render");render.setAccessible(true);
            runOnMainSync(()->{try{render.invoke(a);}catch(Exception e){throw new RuntimeException(e);}});
            Thread.sleep(800);
            Field field=MainActivity.class.getDeclaredField("web");field.setAccessible(true);WebView web=(WebView)field.get(activity);
            java.util.concurrent.CountDownLatch latch=new java.util.concurrent.CountDownLatch(1);
            final String[] uiResult={null};
            runOnMainSync(()->web.evaluateJavascript("JSON.stringify({catalog:state.catalog.length,rows:document.querySelectorAll('.pkg').length,selected:selected.size,connected:state.connected,tabs:document.querySelectorAll('nav .tab').length,overflow:document.documentElement.scrollWidth>innerWidth,permissions:state.permissionReport.permissions.length,apps:state.userApps.length})",value->{uiResult[0]=value;latch.countDown();}));
            if(!latch.await(10,java.util.concurrent.TimeUnit.SECONDS))throw new Exception("JS callback timeout");
            String raw=(String)new JSONTokener(uiResult[0]).nextValue();JSONObject ui=new JSONObject(raw);
            if(ui.getInt("catalog")!=60||ui.getInt("rows")!=60||ui.getInt("selected")!=0||!ui.getBoolean("connected")||ui.getInt("tabs")!=5||ui.getBoolean("overflow")||ui.getInt("permissions")==0||ui.getInt("apps")==0)throw new Exception("UI state: "+ui);
            results.putString("ui",ui.toString());
            String fixture="com.android.providers.partnerbookmarks";
            int original=MainActivity.enabledState(adb.shell("dumpsys package "+fixture));
            JSONObject saved=new JSONObject(activity.getSharedPreferences("honor",0).getString("originals","{}"));saved.remove(fixture);
            activity.getSharedPreferences("honor",0).edit().putString("originals",saved.toString()).commit();
            Method change=MainActivity.class.getDeclaredMethod("changePackage",String.class,boolean.class);change.setAccessible(true);
            try {
                change.invoke(activity,fixture,true);
                if(MainActivity.enabledState(adb.shell("dumpsys package "+fixture))!=3)throw new Exception("Fixture was not disabled: "+activity.getSharedPreferences("honor",0).getString("logs","none"));
                change.invoke(activity,fixture,false);
                if(MainActivity.enabledState(adb.shell("dumpsys package "+fixture))!=original)throw new Exception("Original enabled state was not restored");
                adb.shell("pm disable-user --user 0 "+fixture);
                Method enable=MainActivity.class.getDeclaredMethod("changePackage",String.class,boolean.class,boolean.class);enable.setAccessible(true);
                enable.invoke(activity,fixture,false,true);
                if(MainActivity.enabledState(adb.shell("dumpsys package "+fixture))!=1)throw new Exception("Previously disabled fixture was not enabled");
                change.invoke(activity,fixture,false);
                if(MainActivity.enabledState(adb.shell("dumpsys package "+fixture))!=3)throw new Exception("Enable undo did not restore disabled state");
            } finally {
                int now=MainActivity.enabledState(adb.shell("dumpsys package "+fixture));
                if(now!=original)adb.shell("pm "+(original==0?"default-state":original==1?"enable":"disable-user")+" --user 0 "+fixture);
            }
            String permissionFixture="com.vxm.honor.test",camera="android.permission.CAMERA";
            Boolean originalGrant=PermissionDump.parse(adb.shell("dumpsys package "+permissionFixture)).get(camera).granted;
            if(originalGrant==null)throw new Exception("Fixture grant state missing");
            Method changePermission=MainActivity.class.getDeclaredMethod("changePermission",String.class,String.class,boolean.class);changePermission.setAccessible(true);
            Method changeOp=MainActivity.class.getDeclaredMethod("changeAppOp",String.class,String.class,String.class,String.class);changeOp.setAccessible(true);
            AppOpState originalOp=AppOpState.parse(adb.shell("cmd appops get --user 0 "+permissionFixture+" VIBRATE"),"VIBRATE");
            try {
                changePermission.invoke(activity,permissionFixture,camera,true);
                if(!PermissionDump.parse(adb.shell("dumpsys package "+permissionFixture)).get(camera).granted)throw new Exception("Grant did not persist");
                changePermission.invoke(activity,permissionFixture,camera,false);
                if(PermissionDump.parse(adb.shell("dumpsys package "+permissionFixture)).get(camera).granted)throw new Exception("Revoke did not persist");
                changePermission.invoke(activity,permissionFixture,"android.permission.DUMP",true);
                if(activity.getPackageManager().checkPermission("android.permission.DUMP",permissionFixture)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new Exception("Development permission grant failed");
                changePermission.invoke(activity,permissionFixture,"android.permission.DUMP",false);
                if(activity.getPackageManager().checkPermission("android.permission.DUMP",permissionFixture)==android.content.pm.PackageManager.PERMISSION_GRANTED)throw new Exception("Development permission revoke failed");
                changeOp.invoke(activity,permissionFixture,"VIBRATE","ignore","app");
                changeOp.invoke(activity,permissionFixture,"VIBRATE","allow","app");
                changeOp.invoke(activity,permissionFixture,"VIBRATE","ignore","uid");
                changeOp.invoke(activity,permissionFixture,"VIBRATE","default","uid");
            } finally {
                adb.shell("pm revoke --user 0 "+permissionFixture+" android.permission.DUMP");
                adb.shell("pm "+(originalGrant?"grant":"revoke")+" --user 0 "+permissionFixture+" "+camera);
                adb.shell("cmd appops set --user 0 "+permissionFixture+" VIBRATE "+originalOp.app);
                adb.shell("cmd appops set --user 0 --uid "+permissionFixture+" VIBRATE "+originalOp.uid);
            }
            java.util.concurrent.atomic.AtomicInteger ran=new java.util.concurrent.atomic.AtomicInteger();
            Method confirm=MainActivity.class.getDeclaredMethod("confirm",String.class,String.class,MainActivity.Work.class);confirm.setAccessible(true);
            Field pending=MainActivity.class.getDeclaredField("confirmation");pending.setAccessible(true);
            MainActivity.Bridge bridge=a.new Bridge();
            confirm.invoke(activity,"Test glass","Cancel",(MainActivity.Work)()->ran.incrementAndGet());waitForIdleSync();
            String cancelToken=((JSONObject)pending.get(activity)).getString("id");bridge.answerConfirmation("wrong-token",true);waitForIdleSync();
            if(ran.get()!=0 || pending.get(activity)==null)throw new Exception("Confirmation token guard failed");
            bridge.answerConfirmation(cancelToken,false);waitForIdleSync();if(ran.get()!=0)throw new Exception("Cancel executed an operation");
            confirm.invoke(activity,"Test glass","Accept",(MainActivity.Work)()->ran.incrementAndGet());waitForIdleSync();
            bridge.answerConfirmation(((JSONObject)pending.get(activity)).getString("id"),true);
            for(int i=0;i<100&&ran.get()==0;i++)Thread.sleep(50);
            if(ran.get()!=1)throw new Exception("Confirmation did not execute exactly once");
            results.putString("permissions","PASS: grant/revoke camera and development DUMP permission, app and UID AppOps, restore original values, token-bound glass confirmation accept/cancel");
            Method systemApps=MainActivity.class.getDeclaredMethod("loadSystemApps");systemApps.setAccessible(true);systemApps.invoke(activity);
            Field systemList=MainActivity.class.getDeclaredField("systemApps");systemList.setAccessible(true);
            JSONArray systemRows=(JSONArray)systemList.get(activity);boolean settingsFound=false;
            for(int i=0;i<systemRows.length();i++){String id=systemRows.getJSONObject(i).getString("id");if(id.equals("com.vxm.honor")||id.equals("com.vxm.honor.test"))throw new Exception("Third-party app in system list");if(id.equals("com.android.settings"))settingsFound=true;}
            if(!settingsFound)throw new Exception("Settings not in launchable system list");
            Method readLocales=MainActivity.class.getDeclaredMethod("readSystemLocales",String.class);readLocales.setAccessible(true);readLocales.invoke(activity,"com.android.settings");
            Field localeField=MainActivity.class.getDeclaredField("localeReport");localeField.setAccessible(true);JSONObject localeData=(JSONObject)localeField.get(activity);
            JSONArray locales=localeData.getJSONArray("locales");if(locales.length()<2)throw new Exception("APK locale extraction failed: "+localeData);
            String originalLocale=localeData.getString("current"),chosen=locales.getJSONObject(0).getString("id");
            if(!originalLocale.matches("[A-Za-z0-9,-]*"))throw new Exception("Unexpected original locale");
            Method setLocale=MainActivity.class.getDeclaredMethod("changeSystemLocale",String.class,String.class);setLocale.setAccessible(true);
            try {setLocale.invoke(activity,"com.android.settings",chosen);
                if(!chosen.equals(((JSONObject)localeField.get(activity)).getString("current")))throw new Exception("Locale did not persist");
                setLocale.invoke(activity,"com.android.settings","");
                if(!((JSONObject)localeField.get(activity)).getString("current").isEmpty())throw new Exception("System locale reset failed");
                try {setLocale.invoke(activity,"com.android.settings","xx-FAKE");throw new Exception("Unsupported locale accepted");}
                catch(InvocationTargetException expected){if(!(expected.getCause() instanceof java.io.IOException))throw expected;}
                try {readLocales.invoke(activity,"com.vxm.honor");throw new Exception("Third-party locale target accepted");}
                catch(InvocationTargetException expected){if(!(expected.getCause() instanceof java.io.IOException))throw expected;}
            } finally {adb.shell("cmd locale set-app-locales com.android.settings --user 0"+(originalLocale.isEmpty()?"":" --locales "+originalLocale));}
            results.putString("locales","PASS: "+systemRows.length()+" system apps, "+locales.length()+" Settings locales from "+localeData.getString("source")+", set/reset/read-back, unsupported locale and user app rejected");
            Method scan=MainActivity.class.getDeclaredMethod("scanPackages");scan.setAccessible(true);scan.invoke(activity);
            Field scanned=MainActivity.class.getDeclaredField("scannedPackages");scanned.setAccessible(true);
            JSONArray scannedRows=(JSONArray)scanned.get(activity);boolean protectedSelf=false,extraFound=false;
            for(int i=0;i<scannedRows.length();i++){JSONObject row=scannedRows.getJSONObject(i);if(row.getString("id").equals("com.vxm.honor"))protectedSelf=row.getBoolean("protected");if(row.getString("id").equals("com.vxm.honor.test"))extraFound=true;}
            if(scannedRows.length()<60 || !protectedSelf || !extraFound)throw new Exception("Full scan missing apps or self guard");
            try {change.invoke(activity,"com.vxm.honor",true);throw new Exception("Protected self accepted");}
            catch(InvocationTargetException expected){if(!(expected.getCause() instanceof java.io.IOException))throw expected;}
            results.putString("scan","PASS: "+scannedRows.length()+" installed packages, extra user app included, self blocked before mutation");
            results.putString("identity",identity);
            results.putString("result","PASS: real loopback ADB, shell identity, 60 rows, no preselection, 5 tabs, no horizontal overflow, disable, enable previously disabled, exact undo, user app permissions on emulator fixture");
            finish(Activity.RESULT_OK,results);
        } catch(Throwable e) {
            Throwable cause=e instanceof InvocationTargetException?e.getCause():e;
            results.putString("error",android.util.Log.getStackTraceString(cause));finish(Activity.RESULT_CANCELED,results);
        }
    }
}
