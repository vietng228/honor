package com.vxm.honor;
import java.util.regex.*;

final class AppOpState {
    String uid="default", app="default", fallback="";
    static AppOpState parse(String raw,String operation) {
        AppOpState state=new AppOpState();
        Pattern line=Pattern.compile("^(Uid mode: )?"+Pattern.quote(operation)+": ([a-z]+)(?:;.*| \\(.*)?$");
        for(String text:raw.split("\\R")) {
            Matcher m=line.matcher(text.trim());
            if(m.matches()){if(m.group(1)!=null)state.uid=m.group(2);else state.app=m.group(2);}
            if(text.trim().startsWith("Default mode: "))state.fallback=text.trim().substring(14);
        }
        return state;
    }
}
