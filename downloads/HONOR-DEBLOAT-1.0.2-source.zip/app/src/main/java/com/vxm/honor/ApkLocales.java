package com.vxm.honor;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Locale qualifiers in this APK only, excluding Android framework asset locales. */
final class ApkLocales {
    static Set<String> read(String path) throws IOException {
        try(ZipFile apk=new ZipFile(path)) {
            ZipEntry entry=apk.getEntry("resources.arsc");if(entry==null)return new TreeSet<>();
            long size=entry.getSize();if(size<12 || size>128_000_000)throw new IOException("Bảng tài nguyên APK không hợp lệ hoặc quá lớn");
            byte[] data=new byte[(int)size];
            try(DataInputStream input=new DataInputStream(apk.getInputStream(entry))){input.readFully(data);}
            return parse(data);
        }
    }
    static Set<String> parse(byte[] data) throws IOException {
        Set<String> tags=new TreeSet<>();ByteBuffer b=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if(data.length<12 || u16(b,0)!=2)throw new IOException("Không phải bảng tài nguyên Android");
        int end=chunkEnd(b,0,data.length);
        for(int p=u16(b,2);p<end;){int next=chunkEnd(b,p,end);
            if(u16(b,p)==0x0200)for(int t=p+u16(b,p+2);t<next;){int typeEnd=chunkEnd(b,t,next);
                if(u16(b,t)==0x0201 && u16(b,t+2)>=32) {
                    int config=t+20,size=b.getInt(config);
                    if(size>=12 && config+(long)size<=t+u16(b,t+2)) {
                        String language=unpack(b.get(config+8),b.get(config+9),'a');
                        if(!language.isEmpty()) {
                            String region=unpack(b.get(config+10),b.get(config+11),'0');
                            String script=size>=40?ascii(data,config+36,4):"";
                            String variant=size>=48?ascii(data,config+40,8):"";
                            try {Locale.Builder locale=new Locale.Builder().setLanguage(language);
                                if(!region.isEmpty())locale.setRegion(region);
                                if(!script.isEmpty())locale.setScript(script);
                                if(!variant.isEmpty())locale.setVariant(variant);
                                tags.add(locale.build().toLanguageTag());
                            }catch(IllformedLocaleException ignored){}
                        }
                    }
                }
                t=typeEnd;
            }
            p=next;
        }
        return tags;
    }
    private static int chunkEnd(ByteBuffer b,int p,int limit) throws IOException {
        if(p<0 || p+8>limit)throw new IOException("Header tài nguyên bị thiếu");
        int header=u16(b,p+2),size=b.getInt(p+4);
        if(header<8 || size<header || p+(long)size>limit)throw new IOException("Kích thước tài nguyên không hợp lệ");
        return p+size;
    }
    private static int u16(ByteBuffer b,int p){return b.getShort(p)&65535;}
    static String unpack(byte first,byte second,char base) {
        int a=first&255,c=second&255;if(a==0&&c==0)return "";
        if((a&128)==0)return new String(new char[]{(char)a,(char)c});
        return new String(new char[]{(char)((c&31)+base),(char)((((c&224)>>5)|((a&3)<<3))+base),(char)(((a&124)>>2)+base)});
    }
    private static String ascii(byte[] bytes,int p,int length){int end=p;while(end<p+length&&bytes[end]!=0)end++;return new String(bytes,p,end-p,StandardCharsets.US_ASCII);}
}
