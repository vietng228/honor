package com.vxm.honor;

import java.net.URI;

final class UpdatePolicy {
    static boolean allowedDownload(String value) {
        try {
            URI uri = new URI(value);
            return "https".equals(uri.getScheme()) && "vietng228.github.io".equals(uri.getHost())
                    && uri.getPort() == -1 && uri.getUserInfo() == null && uri.getQuery() == null
                    && uri.getFragment() == null
                    && uri.getPath().matches("/honor/downloads/HONOR-DEBLOAT-[0-9]+\\.[0-9]+\\.[0-9]+\\.apk");
        } catch (Exception ignored) { return false; }
    }
}
