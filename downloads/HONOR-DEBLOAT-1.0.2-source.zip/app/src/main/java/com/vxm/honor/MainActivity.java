package com.vxm.honor;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.net.nsd.*;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public final class MainActivity extends Activity {
    private WebView web;
    private LocalAdb adb;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private JSONArray catalog, logs;
    private JSONArray scannedPackages=new JSONArray();
    private final Set<String> protectedPackages=new HashSet<>();
    private final Set<String> allowedPackages = new HashSet<>();
    private final Map<String,String> titles = new HashMap<>();
    private final Map<String,String> packageStatus = new HashMap<>();
    private JSONArray userApps=new JSONArray(),systemApps=new JSONArray();
    private JSONObject localeReport=new JSONObject();
    private JSONObject permissionReport=new JSONObject();
    private JSONObject confirmation;
    private JSONObject opEditor;
    private Work confirmationWork;
    private boolean busy;
    private boolean ready;
    private JSONObject updateInfo = new JSONObject();
    private String updateStatus = "Chưa kiểm tra";
    private boolean checkingUpdate;
    private String model = Build.MODEL, cloud = "?", connection = "Chưa kết nối";
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;

    @Override public void onCreate(Bundle saved) {
        setTheme(R.style.AppTheme);
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(39,48,57));
        getWindow().setNavigationBarColor(Color.rgb(39,48,57));
        prefs = getSharedPreferences("honor", MODE_PRIVATE);
        try {
            try (InputStream input = getAssets().open("packages.json")) {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int count;
                while ((count = input.read(buffer)) != -1) bytes.write(buffer,0,count);
                catalog = new JSONArray(bytes.toString(StandardCharsets.UTF_8.name()));
            }
            logs = new JSONArray(prefs.getString("logs", "[]"));
            for (int i=0;i<catalog.length();i++) {
                JSONObject p = catalog.getJSONObject(i);
                allowedPackages.add(p.getString("id")); titles.put(p.getString("id"), p.getString("name"));
            }
        } catch (Exception e) { throw new IllegalStateException("Không đọc được danh mục", e); }
        web = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.setBackgroundColor(Color.rgb(39,48,57));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.getSettings().setGeolocationEnabled(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "Honor");
        web.setWebViewClient(new WebViewClient() {
            // openRawResource supports file-backed font resources; share one TTF with the native theme.
            @android.annotation.SuppressLint("ResourceType")
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("https".equals(u.getScheme()) && "honor.vxm.local".equals(u.getHost()) && "/".equals(u.getPath())) {
                    try { return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html")); }
                    catch(IOException ignored) {}
                }
                if ("https".equals(u.getScheme()) && "honor.vxm.local".equals(u.getHost()) && "/fonts/google-sans.ttf".equals(u.getPath())) {
                    try { return new WebResourceResponse("font/ttf", null, getResources().openRawResource(R.font.google_sans)); }
                    catch(android.content.res.Resources.NotFoundException ignored) {}
                }
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public void onPageFinished(WebView view, String url) {
                ready=true; render();
                if(System.currentTimeMillis()-prefs.getLong("updateChecked",0)>86400000L) checkUpdate(false);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        getWindow().getInsetsController().setSystemBarsAppearance(
                0,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        // Respect Android's window insets without depending on a CSS guess for the status bar.
        root.setOnApplyWindowInsetsListener((v,insets) -> {
            android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.ime());
            v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets;
        });
        web.loadUrl("https://honor.vxm.local/");
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
    }

    private LocalAdb manager() throws Exception { if(adb==null) adb=new LocalAdb(this); return adb; }
    private void task(String name, Work work) {
        runOnUiThread(() -> {
            if(busy) return;
            busy=true; render();
            worker.execute(() -> {
                try { work.run(); }
                catch(Exception e) { log(name, false, e.getMessage()==null ? e.getClass().getSimpleName() : e.getMessage()); }
                finally { runOnUiThread(() -> { busy=false; render(); }); }
            });
        });
    }
    interface Work { void run() throws Exception; }
    private synchronized void log(String title, boolean ok, String detail) {
        try {
            JSONObject entry=new JSONObject().put("title",title).put("ok",ok).put("detail",detail).put("time",System.currentTimeMillis());
            JSONArray next=new JSONArray(); next.put(entry);
            for(int i=0;i<Math.min(logs.length(),99);i++) next.put(logs.get(i));
            logs=next; prefs.edit().putString("logs",logs.toString()).apply();
            runOnUiThread(()->{if(ready&&!isDestroyed())web.evaluateJavascript("window.notifyResult("+entry+")",null);});
        } catch(JSONException ignored) {}
    }
    private void render() {
        if(!ready || isDestroyed()) return;
        try {
            JSONObject state=new JSONObject().put("catalog",catalog).put("logs",logs).put("busy",busy)
                    .put("version",BuildConfig.VERSION_NAME).put("updateInfo",updateInfo)
                    .put("updateStatus",updateStatus).put("checkingUpdate",checkingUpdate)
                    .put("connected",adb!=null && adb.isConnected()).put("connection",connection).put("model",model)
                    .put("cloud",cloud).put("systemApps",systemApps).put("localeReport",localeReport).put("localeSupported",Build.VERSION.SDK_INT>=33)
                    .put("confirmation",confirmation==null?JSONObject.NULL:confirmation).put("opEditor",opEditor==null?JSONObject.NULL:opEditor).put("status",packageSnapshot())
                    .put("scannedPackages",scannedPackages).put("userApps",userApps).put("permissionReport",permissionReport)
                    .put("saved",new JSONObject(prefs.getString("originals","{}")))
                    .put("port",prefs.getString("port",""))
                    .put("systemReduceMotion",Settings.Global.getFloat(getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1)==0);
            web.evaluateJavascript("window.receiveState("+state+")",null);
        } catch(Exception ignored) {}
    }
    private JSONObject packageSnapshot() { synchronized(packageStatus) { return new JSONObject(packageStatus); } }
    private void refresh() throws Exception {
        LocalAdb a=manager();
        Set<String> installed=packages(a.shell("pm list packages --user 0"));
        Set<String> disabled=packages(a.shell("pm list packages -d --user 0"));
        synchronized(packageStatus) {
            Set<String> visible=new HashSet<>(allowedPackages);visible.addAll(protectedPackages);
            for(String p:visible) packageStatus.put(p, !installed.contains(p)?"missing":disabled.contains(p)?"disabled":"enabled");
        }
        cloud=a.shell("settings get system package_installer_state");
        model=a.shell("getprop ro.product.model");
        connection="Đã xác thực shell nội bộ";
    }
    private void scanPackages() throws Exception {
        Set<String> ids=packages(manager().shell("pm list packages --user 0"));
        PackageManager pm=getPackageManager();
        Set<String> core=new HashSet<>(Arrays.asList("android",getPackageName(),"com.android.systemui","com.android.settings","com.android.phone","com.android.providers.settings","com.android.permissioncontroller","com.google.android.permissioncontroller","com.android.packageinstaller","com.google.android.packageinstaller"));
        ResolveInfo home=pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),PackageManager.MATCH_DEFAULT_ONLY);
        if(home!=null && home.activityInfo!=null)core.add(home.activityInfo.packageName);
        String keyboard=Settings.Secure.getString(getContentResolver(),Settings.Secure.DEFAULT_INPUT_METHOD);
        if(keyboard!=null && keyboard.contains("/"))core.add(keyboard.substring(0,keyboard.indexOf('/')));
        List<JSONObject> rows=new ArrayList<>();
        for(String id:ids) {
            if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"))continue;
            String label=id;boolean blocked=core.contains(id);
            try { ApplicationInfo info=pm.getApplicationInfo(id,0);label=pm.getApplicationLabel(info).toString();blocked|=info.uid%100000<10000; }
            catch(PackageManager.NameNotFoundException e) { blocked=true; }
            boolean known=false;
            for(int i=0;i<catalog.length();i++)if(id.equals(catalog.getJSONObject(i).getString("id"))){known=true;break;}
            rows.add(new JSONObject().put("id",id).put("name",label).put("group",known?"Danh mục":"Chưa đánh giá")
                    .put("caution",true).put("protected",blocked).put("description",blocked?"Thành phần được bảo vệ; không cho thay đổi trong app.":known?"Có trong danh mục debloat tham chiếu.":"Gói chưa được đánh giá. Tắt có thể làm mất tính năng hoặc ảnh hưởng hệ thống."));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));
        for(JSONObject row:rows) {
            String id=row.getString("id");titles.put(id,row.getString("name"));
            if(row.getBoolean("protected")){protectedPackages.add(id);allowedPackages.remove(id);}
            else allowedPackages.add(id);
        }
        scannedPackages=new JSONArray(rows);refresh();
        log("Quét toàn bộ",true,rows.size()+" gói; chưa chọn gói nào tự động.");
    }
    private void loadUserApps() throws Exception {
        Set<String> ids=packages(manager().shell("pm list packages -3 --user 0"));
        List<JSONObject> rows=new ArrayList<>();
        PackageManager pm=getPackageManager();
        for(String id:ids) {
            String label=id;
            try {label=pm.getApplicationLabel(pm.getApplicationInfo(id,0)).toString();}catch(PackageManager.NameNotFoundException ignored){}
            rows.add(new JSONObject().put("id",id).put("name",label));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));
        userApps=new JSONArray(rows);
        if(!ids.contains(permissionReport.optString("id")))permissionReport=new JSONObject();
    }
    private void readPermissions(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -3 --user 0")).contains(id))
            throw new IOException("Chỉ đọc app người dùng còn cài trên user 0");
        permissionReport=new JSONObject();
        String dump=manager().shell("dumpsys package "+id);
        Map<String,PermissionDump.Entry> parsed=PermissionDump.parse(dump);
        JSONArray rows=new JSONArray();PackageManager pm=getPackageManager();
        for(PermissionDump.Entry entry:parsed.values()) {
            String label=entry.id,type="Không xác định",protection="";boolean editable=false;
            try {
                PermissionInfo info=pm.getPermissionInfo(entry.id,0);
                label=info.loadLabel(pm).toString();
                type=switch(info.getProtection()){case PermissionInfo.PROTECTION_NORMAL->"Thông thường";case PermissionInfo.PROTECTION_DANGEROUS->"Runtime";case PermissionInfo.PROTECTION_SIGNATURE->"Chữ ký";default->"Đặc biệt";};
                protection="0x"+Integer.toHexString(info.protectionLevel);
                editable=PermissionDump.canChange(info.protectionLevel,entry.flags);
                if(entry.granted==null && android.os.Process.myUserHandle().equals(UserHandle.getUserHandleForUid(0)))
                    entry.granted=pm.checkPermission(entry.id,id)==PackageManager.PERMISSION_GRANTED;
            }catch(PackageManager.NameNotFoundException ignored){}
            rows.put(new JSONObject().put("id",entry.id).put("name",label).put("type",type).put("protection",protection)
                    .put("editable",editable).put("granted",entry.granted==null?JSONObject.NULL:entry.granted).put("flags",entry.flags));
        }
        String ops=manager().shell("cmd appops get --user 0 "+id);
        permissionReport=new JSONObject().put("id",id).put("permissions",rows).put("appops",ops);
    }
    private ApplicationInfo requireSystemApp(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -s --user 0")).contains(id))
            throw new IOException("Chỉ áp dụng app hệ thống trên user 0");
        ApplicationInfo app=getPackageManager().getApplicationInfo(id,0);
        if((app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))==0 || !languageApp(app))
            throw new IOException("App hệ thống không có giao diện mở được");
        return app;
    }
    private boolean languageApp(ApplicationInfo app) {
        return app.enabled && (getPackageManager().getLaunchIntentForPackage(app.packageName)!=null
                || app.packageName.equals("com.android.packageinstaller") || app.packageName.equals("com.google.android.packageinstaller"));
    }
    private void loadSystemApps() throws Exception {
        Set<String> installed=packages(manager().shell("pm list packages -s --user 0"));
        List<JSONObject> rows=new ArrayList<>();PackageManager pm=getPackageManager();
        for(ApplicationInfo app:pm.getInstalledApplications(0)) {
            if(installed.contains(app.packageName) && (app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0 && languageApp(app))
                rows.add(new JSONObject().put("id",app.packageName).put("name",pm.getApplicationLabel(app).toString()));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));systemApps=new JSONArray(rows);
    }
    private Set<String> supportedLocales(ApplicationInfo app,StringBuilder source) throws Exception {
        Set<String> tags=new TreeSet<>();
        if(Build.VERSION.SDK_INT>=33) {
            Context context=createPackageContext(app.packageName,0);
            android.app.LocaleConfig config=Build.VERSION.SDK_INT>=34
                    ? android.app.LocaleConfig.fromContextIgnoringOverride(context) : new android.app.LocaleConfig(context);
            if(config.getStatus()==android.app.LocaleConfig.STATUS_SUCCESS && config.getSupportedLocales()!=null) {
                LocaleList locales=config.getSupportedLocales();for(int i=0;i<locales.size();i++)tags.add(locales.get(i).toLanguageTag());
                if(Build.VERSION.SDK_INT>=35 && config.getDefaultLocale()!=null)tags.add(config.getDefaultLocale().toLanguageTag());
                source.append("localeConfig");return tags;
            }
        }
        tags.addAll(ApkLocales.read(app.sourceDir));
        if(app.splitSourceDirs!=null)for(String split:app.splitSourceDirs)tags.addAll(ApkLocales.read(split));
        source.append("APK");return tags;
    }
    private void readSystemLocales(String id) throws Exception {
        if(Build.VERSION.SDK_INT<33)throw new IOException("Đổi ngôn ngữ từng app cần Android 13");
        ApplicationInfo app=requireSystemApp(id);StringBuilder source=new StringBuilder();Set<String> tags=supportedLocales(app,source);
        JSONArray locales=new JSONArray();for(String tag:tags)locales.put(new JSONObject().put("id",tag).put("name",Locale.forLanguageTag(tag).getDisplayName(Locale.forLanguageTag("vi"))+" · "+tag));
        String raw=manager().shell("cmd locale get-app-locales "+id+" --user 0");Matcher m=Pattern.compile("\\[(.*?)]").matcher(raw);
        localeReport=new JSONObject().put("token",UUID.randomUUID().toString()).put("id",id).put("name",getPackageManager().getApplicationLabel(app).toString())
                .put("locales",locales).put("source",source.toString()).put("current",m.find()?m.group(1):"");
    }
    private void changeSystemLocale(String id,String tag) throws Exception {
        if(Build.VERSION.SDK_INT<33)throw new IOException("Đổi ngôn ngữ từng app cần Android 13");
        ApplicationInfo app=requireSystemApp(id);
        if(!tag.isEmpty() && (!tag.matches("[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*") || !supportedLocales(app,new StringBuilder()).contains(tag)))
            throw new IOException("Ngôn ngữ không có trong danh sách của app");
        String result=manager().shell("cmd locale set-app-locales "+id+" --user 0"+(tag.isEmpty()?"":" --locales "+tag));
        readSystemLocales(id);
        boolean ok=tag.equals(localeReport.optString("current"));
        log("Ngôn ngữ ứng dụng",ok,id+" → "+(tag.isEmpty()?"Theo hệ thống":tag)+"\n"+result);
    }
    private void requireUserApp(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -3 --user 0")).contains(id))
            throw new IOException("Chỉ áp dụng app người dùng trên user 0");
    }
    private void changePermission(String id,String permission,boolean grant) throws Exception {
        requireUserApp(id);
        PermissionDump.Entry entry=PermissionDump.parse(manager().shell("dumpsys package "+id)).get(permission);
        if(entry==null)throw new IOException("App không khai báo quyền này");
        PermissionInfo info=getPackageManager().getPermissionInfo(permission,0);
        if(!PermissionDump.canChange(info.protectionLevel,entry.flags))throw new IOException("Quyền này do hệ thống hoặc chính sách quản lý");
        if(!permission.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"))throw new IOException("Tên quyền không hợp lệ");
        String output=manager().shell("pm "+(grant?"grant":"revoke")+" --user 0 "+id+" "+permission);
        readPermissions(id);
        Boolean after=null;
        JSONArray rows=permissionReport.getJSONArray("permissions");
        for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);
            if(permission.equals(row.getString("id")) && !row.isNull("granted"))after=row.getBoolean("granted");
        }
        if(after==null || after!=grant)throw new IOException("ROM không đổi quyền: "+output);
        log(grant?"Đã cấp quyền":"Đã thu hồi quyền",true,id+"\n"+permission);
    }
    private void changeAppOp(String id,String op,String mode,String scope) throws Exception {
        requireUserApp(id);
        if(!op.matches("[A-Z][A-Z0-9_]*") || !Set.of("allow","ignore","deny","foreground","default").contains(mode)
                || !Set.of("app","uid").contains(scope))throw new IOException("AppOps không hợp lệ");
        String before=manager().shell("cmd appops get --user 0 "+id+" "+op);
        if(before.contains("Error") || before.contains("Unknown"))throw new IOException(before);
        String output=manager().shell("cmd appops set --user 0 "+(scope.equals("uid")?"--uid ":"")+id+" "+op+" "+mode);
        String check=manager().shell("cmd appops get --user 0 "+id+" "+op);
        AppOpState after=AppOpState.parse(check,op);
        readPermissions(id);
        if(output.contains("Error") || output.contains("Exception") || !mode.equals(scope.equals("uid")?after.uid:after.app))
            throw new IOException("ROM không giữ chế độ yêu cầu: "+output+"\n"+check);
        log("Đã đổi AppOps",true,id+"\n"+op+" · "+scope+" · "+mode);
    }
    static Set<String> packages(String result) {
        Set<String> items=new HashSet<>();
        for(String line:result.split("\\r?\\n")) if(line.startsWith("package:")) items.add(line.substring(8).trim());
        return items;
    }
    static int enabledState(String dump) throws IOException {
        Matcher m=Pattern.compile("(?m)^    User 0:.*?\\benabled=(\\d+)").matcher(dump);
        if(!m.find()) throw new IOException("Không đọc được trạng thái gốc user 0");
        return Integer.parseInt(m.group(1));
    }
    private void remember(String id, Object value) throws JSONException, IOException {
        JSONObject originals=new JSONObject(prefs.getString("originals","{}"));
        if(!originals.has(id)) {
            originals.put(id,value);
            // Persist before issuing a shell mutation, even if the process is killed afterwards.
            if(!prefs.edit().putString("originals",originals.toString()).commit()) throw new IOException("Không lưu được trạng thái hoàn tác; đã dừng trước khi thay đổi.");
        }
    }
    private void changePackage(String p, boolean disable) throws Exception { changePackage(p,disable,false); }
    private void changePackage(String p, boolean disable, boolean enable) throws Exception {
        if(protectedPackages.contains(p) || !allowedPackages.contains(p)) throw new IOException("Gói không thuộc danh sách được phép");
        LocalAdb a=manager();
        if(!packages(a.shell("pm list packages --user 0")).contains(p)) { log(titles.get(p),false,"Không có gói này trên máy; đã bỏ qua."); return; }
        int before=enabledState(a.shell("dumpsys package "+p));
        if(disable && (before==2 || before==3 || before==4)) { log(titles.get(p),true,"Đã tắt từ trước; giữ nguyên trạng thái."); return; }
        JSONObject originals=new JSONObject(prefs.getString("originals","{}"));
        if(!disable && !enable && !originals.has(p)) { log(titles.get(p),false,"Không có bản ghi thay đổi từ app này để hoàn tác."); return; }
        int wanted=enable?1:disable?3:originals.getInt(p);
        remember(p,before);
        String verb=switch(wanted){case 0->"default-state";case 1->"enable";case 2->"disable";case 3->"disable-user";case 4->"disable-until-used";default->throw new IOException("Trạng thái gói không hỗ trợ");};
        String result=a.shell("pm "+verb+" --user 0 "+p);
        int after=enabledState(a.shell("dumpsys package "+p));
        boolean ok=after==wanted;
        if(ok && !disable && !enable) { originals.remove(p); prefs.edit().putString("originals",originals.toString()).commit(); }
        log(titles.get(p),ok,(ok?(enable?"Đã bật. ":disable?"Đã tắt. ":"Đã hoàn tác. "):"ROM không cho đổi hoặc không đạt trạng thái yêu cầu. ")+result);
    }
    private void feature(String id) throws Exception {
        LocalAdb a=manager(); String output,check;
        switch(id) {
            case "cloud-off", "cloud-on" -> {
                if(!packages(a.shell("pm list packages --user 0")).contains("com.hihonor.systemmanager")) throw new IOException("Không thấy trình quản lý HONOR; không áp dụng công tắc cloud cho máy này.");
                String old=a.shell("settings get system package_installer_state");
                remember("cloudValue",old);
                String wanted=id.equals("cloud-off")?"0":"1";
                output=a.shell("settings put system package_installer_state "+wanted);
                check=a.shell("settings get system package_installer_state");
                log("Kiểm tra cloud APK",wanted.equals(check),"Giá trị đọc lại: "+check+"\n"+output);
            }
            case "scanner-off" -> changePackage("com.hihonor.securitypluginbase",true);
            case "scanner-on" -> {
                String p="com.hihonor.securitypluginbase";
                int old=enabledState(a.shell("dumpsys package "+p)); remember(p,old);
                output=a.shell("pm enable --user 0 "+p);
                check=a.shell("dumpsys package "+p);
                log("Bật lại plugin quét",enabledState(check)==1,output);
            }
            default -> throw new IOException("Thao tác không hợp lệ");
        }
        refresh();
    }
    private void confirm(String title,String text,Work work) {
        runOnUiThread(() -> {
            if(busy) return;
            if(confirmationWork!=null)return;
            try {confirmation=new JSONObject().put("id",UUID.randomUUID().toString()).put("title",title).put("text",text);}
            catch(JSONException e){throw new IllegalStateException(e);}
            confirmationWork=work;render();
        });
    }
    private void discover() {
        if(discovery!=null) return;
        nsd=(NsdManager)getSystemService(NSD_SERVICE);
        discovery=new NsdManager.DiscoveryListener() {
            public void onDiscoveryStarted(String t) {}
            public void onDiscoveryStopped(String t) {}
            public void onStartDiscoveryFailed(String t,int e) { stopDiscovery(); }
            public void onStopDiscoveryFailed(String t,int e) {}
            public void onServiceLost(NsdServiceInfo s) {}
            public void onServiceFound(NsdServiceInfo s) {
                nsd.resolveService(s,new NsdManager.ResolveListener() {
                    public void onResolveFailed(NsdServiceInfo i,int e) {}
                    public void onServiceResolved(NsdServiceInfo i) {
                        try {
                            if(i.getHost()==null || !isLocal(i.getHost())) return;
                            prefs.edit().putString("port",String.valueOf(i.getPort())).apply();
                            log("Tìm cổng self ADB",true,"Cổng kết nối nội bộ: "+i.getPort());
                            runOnUiThread(()->{stopDiscovery();render();});
                        } catch(Exception ignored) {}
                    }
                });
            }
        };
        nsd.discoverServices("_adb-tls-connect._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
        new Handler(Looper.getMainLooper()).postDelayed(()->{stopDiscovery();render();},10000);
    }
    static boolean isLocal(InetAddress address) throws SocketException {
        return address.isLoopbackAddress() || NetworkInterface.getByInetAddress(address)!=null;
    }
    private void stopDiscovery() { if(discovery!=null){try{nsd.stopServiceDiscovery(discovery);}catch(Exception ignored){} discovery=null;} }

    private void checkUpdate(boolean manual) {
        if(checkingUpdate) return;
        checkingUpdate=true; updateStatus="Đang kiểm tra…"; render();
        worker.execute(()->{
            JSONObject result=new JSONObject(); String status;
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL("https://vietng228.github.io/honor/update.json").openConnection();
                connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
                connection.setInstanceFollowRedirects(false); connection.setUseCaches(false);
                if(connection.getResponseCode()!=200)throw new IOException("Máy chủ chưa sẵn sàng");
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                try(InputStream input=connection.getInputStream()) {
                    byte[] buffer=new byte[2048]; int count;
                    while((count=input.read(buffer))!=-1) {
                        if(bytes.size()+count>32768)throw new IOException("Thông tin cập nhật quá lớn");
                        bytes.write(buffer,0,count);
                    }
                }
                JSONObject data=new JSONObject(bytes.toString(StandardCharsets.UTF_8.name()));
                if(!getPackageName().equals(data.getString("packageName"))
                        || !UpdatePolicy.allowedDownload(data.getString("apkUrl"))
                        || !data.getString("sha256").matches("[a-fA-F0-9]{64}"))
                    throw new IOException("Thông tin cập nhật không hợp lệ");
                int code=data.getInt("versionCode");
                if(code>BuildConfig.VERSION_CODE) {
                    result=data;
                    status=data.getInt("minSdk")>Build.VERSION.SDK_INT?"Bản mới cần Android mới hơn":"Có bản mới: "+data.getString("versionName");
                    result.put("compatible",data.getInt("minSdk")<=Build.VERSION.SDK_INT);
                } else status="Bạn đang dùng bản mới nhất";
                prefs.edit().putLong("updateChecked",System.currentTimeMillis()).apply();
            } catch(Exception e) { status=manual?"Chưa kiểm tra được. Thử lại khi có mạng.":"Chưa kiểm tra được"; }
            finally { if(connection!=null)connection.disconnect(); }
            JSONObject next=result; String message=status;
            runOnUiThread(()->{updateInfo=next;updateStatus=message;checkingUpdate=false;render();});
        });
    }

    public final class Bridge {
        @JavascriptInterface public void checkUpdate() { runOnUiThread(()->MainActivity.this.checkUpdate(true)); }
        @JavascriptInterface public void downloadUpdate() { runOnUiThread(()->{
            String url=updateInfo.optString("apkUrl");
            if(!updateInfo.optBoolean("compatible") || !UpdatePolicy.allowedDownload(url))return;
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); }
            catch(ActivityNotFoundException e) { log("Cập nhật",false,"Cần trình duyệt để tải APK."); }
        }); }
        @JavascriptInterface public void state() { runOnUiThread(()->render()); }
        @JavascriptInterface public void openDebugging() { runOnUiThread(()->{
            int flags=Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT;
            for(String action : new String[]{"android.settings.WIRELESS_DEBUGGING_SETTINGS",Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,Settings.ACTION_SETTINGS}) {
                try { startActivity(new Intent(action).addFlags(flags)); return; }
                catch(ActivityNotFoundException | SecurityException ignored) {}
            }
        }); }
        @JavascriptInterface public void setAppearance() { runOnUiThread(()->{
            prefs.edit().remove("light").apply();
            setTheme(R.style.AppTheme);
            int color=Color.rgb(39,48,57);
            getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);web.setBackgroundColor(color);
            getWindow().getDecorView().setBackgroundColor(color);
            int mask=android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            getWindow().getInsetsController().setSystemBarsAppearance(0,mask);
        }); }
        @JavascriptInterface public void discoverPort() { runOnUiThread(()->discover()); }
        @JavascriptInterface public void connect(String port) { task("Kết nối self ADB",()->{
            int n=parsePort(port); LocalAdb a=manager(); if(a.isConnected())a.disconnect();
            if(!a.connect("127.0.0.1",n)) throw new IOException("Không kết nối được. Kiểm tra cổng kết nối và ghép đôi.");
            String identity=a.shell("id");
            if(!identity.contains("uid=2000(shell)")) { a.disconnect(); throw new IOException("Kết nối không có quyền shell ADB"); }
            prefs.edit().putString("port",String.valueOf(n)).apply();refresh();log("Kết nối self ADB",true,"Đã xác thực uid=2000(shell) trên "+model);
        }); }
        @JavascriptInterface public void pair(String port,String code) { task("Ghép đôi Wireless ADB",()->{
            if(!code.matches("\\d{6}"))throw new IOException("Mã ghép đôi phải gồm 6 chữ số");
            if(!manager().pair("127.0.0.1",parsePort(port),code))throw new IOException("Ghép đôi thất bại; mã có thể đã hết hạn");
            log("Ghép đôi Wireless ADB",true,"Đã ghép đôi. Nhập cổng kết nối (khác cổng ghép đôi), rồi bấm Kết nối.");
        }); }
        @JavascriptInterface public void disconnect() { task("Ngắt self ADB",()->{if(adb!=null)adb.disconnect();connection="Đã ngắt kết nối";log("Ngắt self ADB",true,"Đã đóng phiên của app. Wireless debugging vẫn theo cài đặt hệ thống.");}); }
        @JavascriptInterface public void answerConfirmation(String token,boolean accept) { runOnUiThread(()->{
            if(confirmation==null || !token.equals(confirmation.optString("id")))return;
            Work work=confirmationWork;String title=confirmation.optString("title");confirmation=null;confirmationWork=null;render();
            if(accept)task(title,work);
        }); }
        @JavascriptInterface public void permissionChange(String id,String permission,boolean grant) {
            if(!id.equals(permissionReport.optString("id")))return;
            JSONArray rows=permissionReport.optJSONArray("permissions");if(rows==null)return;
            for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);
                if(row!=null && permission.equals(row.optString("id")) && row.optBoolean("editable")) {
                    confirm(grant?"Cấp quyền?":"Thu hồi quyền?",row.optString("name")+"\n"+id+"\n"+permission,()->changePermission(id,permission,grant));return;
                }
            }
        }
        @JavascriptInterface public void inspectAppOp(String id,String op) { task("Đọc AppOps",()->{
            requireUserApp(id);
            if(!op.matches("[A-Z][A-Z0-9_]*"))throw new IOException("AppOps không hợp lệ");
            String raw=manager().shell("cmd appops get --user 0 "+id+" "+op);
            if(raw.contains("Error")||raw.contains("Unknown"))throw new IOException(raw);
            AppOpState modes=AppOpState.parse(raw,op);
            opEditor=new JSONObject().put("token",UUID.randomUUID().toString()).put("id",id).put("op",op)
                    .put("app",modes.app).put("uid",modes.uid).put("defaultMode",modes.fallback);
        }); }
        @JavascriptInterface public void closeAppOp() { runOnUiThread(()->{opEditor=null;render();}); }
        @JavascriptInterface public void appOpChange(String id,String op,String mode,String scope) {
            if(!id.equals(permissionReport.optString("id")) || !op.matches("[A-Z][A-Z0-9_]*"))return;
            if(!Pattern.compile("(?m)^(?:Uid mode: )?"+Pattern.quote(op)+": ").matcher(permissionReport.optString("appops")).find())return;
            String shared="";
            if(scope.equals("uid")) {
                try {String[] names=getPackageManager().getPackagesForUid(getPackageManager().getApplicationInfo(id,0).uid);
                    if(names!=null && names.length>1)shared="\nUID dùng chung: "+String.join(", ",names);
                }catch(PackageManager.NameNotFoundException ignored){}
            }
            runOnUiThread(()->opEditor=null);
            confirm("Đổi AppOps?",op+" → "+mode+"\n"+id+"\n"+(scope.equals("uid")?"UID":"Ứng dụng")+shared,()->changeAppOp(id,op,mode,scope));
        }
        @JavascriptInterface public void listSystemApps() { task("Đọc app hệ thống",()->loadSystemApps()); }
        @JavascriptInterface public void systemLocales(String id) { task("Đọc ngôn ngữ",()->readSystemLocales(id)); }
        @JavascriptInterface public void systemLocaleChange(String id,String tag) {
            if(!id.equals(localeReport.optString("id")))return;
            String label="Theo hệ thống";
            if(!tag.isEmpty()) {label=null;JSONArray rows=localeReport.optJSONArray("locales");if(rows==null)return;
                for(int i=0;i<rows.length();i++)if(tag.equals(rows.optJSONObject(i).optString("id")))label=rows.optJSONObject(i).optString("name");
                if(label==null)return;
            }
            confirm("Đổi ngôn ngữ?",localeReport.optString("name")+"\n"+id+"\n"+label,()->changeSystemLocale(id,tag));
        }
        @JavascriptInterface public void scanPackages() { task("Quét toàn bộ",()->MainActivity.this.scanPackages()); }
        @JavascriptInterface public void listUserApps() { task("Đọc app người dùng",()->loadUserApps()); }
        @JavascriptInterface public void permissions(String id) { task("Đọc quyền",()->readPermissions(id)); }
        @JavascriptInterface public void refreshState() { task("Làm mới",()->{refresh();log("Làm mới",true,"Đã đọc lại trạng thái gói và tiện ích.");}); }
        @JavascriptInterface public void batch(String json,boolean disable) { batchAction(json,disable,false); }
        @JavascriptInterface public void enableBatch(String json) { batchAction(json,false,true); }
        private void batchAction(String json,boolean disable,boolean enable) {
            try {
                JSONArray raw=new JSONArray(json); LinkedHashSet<String> ids=new LinkedHashSet<>();
                for(int i=0;i<raw.length();i++){String p=raw.getString(i);if(protectedPackages.contains(p) || !allowedPackages.contains(p))throw new IOException("Gói không hợp lệ");ids.add(p);}
                if(ids.isEmpty())return;
                StringBuilder description=new StringBuilder(enable?"Bật các gói đã chọn.\n\n":disable?"Tắt cho user 0; không xóa dữ liệu.\n\n":"Hoàn tác về trạng thái app đã lưu, không tự bật gói vốn đã tắt trước đó.\n\n");
                for(String p:ids)description.append("• ").append(titles.get(p)).append("\n").append(p).append("\n");
                if(disable && scannedPackages.length()>0)description.append("\nGói quét thêm chưa được đánh giá an toàn; tắt có thể ảnh hưởng tính năng hệ thống.");
                confirm(enable?"Bật "+ids.size()+" gói đã chọn?":disable?"Tắt "+ids.size()+" gói đã chọn?":"Hoàn tác "+ids.size()+" gói?",description.toString(),()->{
                    for(String p:ids){try{changePackage(p,disable,enable);}catch(Exception e){log(titles.get(p),false,e.getMessage());}}
                    refresh();
                });
            }catch(Exception e){log("Thao tác không hợp lệ",false,e.getMessage());}
        }
        @JavascriptInterface public void utility(String id) {
            String text=switch(id){
                case "cloud-off"->"Tắt Enhanced service của trình cài APK. Kiểm tra cloud của trình cài đặt sẽ bị bỏ qua; quét cục bộ vẫn còn.";
                case "cloud-on"->"Bật lại Enhanced service của trình cài APK HONOR.";
                case "scanner-off"->"Tắt gói com.hihonor.securitypluginbase, gồm Qihoo, AVL và plugin chống gian lận. Giảm bảo vệ APK của HONOR; không tắt Phone Manager hoặc Play Protect.";
                case "scanner-on"->"Bật lại gói plugin quét APK HONOR (Qihoo / AVL / chống gian lận).";
                default->null;
            };
            if(text!=null)confirm("Xác nhận tiện ích",text,()->feature(id));
        }
    }
    static int parsePort(String value) throws IOException {
        try { int n=Integer.parseInt(value);if(n<1||n>65535)throw new NumberFormatException();return n; }
        catch(NumberFormatException e){throw new IOException("Cổng phải nằm trong khoảng 1–65535");}
    }
    private void handleBack() { web.evaluateJavascript("window.dismissTopDialog()",value->{if(!"true".equals(value))finish();}); }
    @Override public void onBackPressed() { handleBack(); }
    @Override protected void onDestroy(){stopDiscovery();worker.shutdownNow();if(adb!=null)try{adb.close();}catch(IOException ignored){} web.removeJavascriptInterface("Honor");web.destroy();super.onDestroy();}
}
