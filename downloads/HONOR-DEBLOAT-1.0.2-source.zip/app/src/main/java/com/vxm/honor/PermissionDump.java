package com.vxm.honor;
import java.util.*;
import java.util.regex.*;

final class PermissionDump {
    static final class Entry {
        final String id; Boolean granted; String flags="";
        Entry(String id){this.id=id;}
    }
    static boolean canChange(int protection,String flags) {
        return ((protection & 15)==1 || (protection & 32)!=0)
                && !flags.contains("SYSTEM_FIXED") && !flags.contains("POLICY_FIXED");
    }
    static Map<String,Entry> parse(String dump) {
        Map<String,Entry> rows=new LinkedHashMap<>();
        String section="";int level=-1;String user="";
        Pattern permission=Pattern.compile("([A-Za-z0-9_.]+): granted=(true|false)(?:, flags=\\[(.*)])?.*");
        for(String line:dump.split("\\R")) {
            String t=line.trim();if(t.isEmpty())continue;
            int indent=line.length()-line.stripLeading().length();
            if(t.startsWith("User ")){user=t.substring(5).split(":",2)[0];section="";}
            if(indent<=level)section="";
            if(t.equals("requested permissions:")){user="";section="requested";level=indent;continue;}
            if(t.equals("install permissions:") && user.isEmpty()){section="install";level=indent;continue;}
            if(t.equals("runtime permissions:") && user.equals("0")){section="runtime";level=indent;continue;}
            if(section.equals("requested") && t.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"))rows.computeIfAbsent(t,Entry::new);
            if(section.equals("install")||section.equals("runtime")) {
                Matcher m=permission.matcher(t);
                if(m.matches()) {Entry row=rows.computeIfAbsent(m.group(1),Entry::new);row.granted=Boolean.valueOf(m.group(2));row.flags=m.group(3)==null?"":m.group(3).trim();}
            }
        }
        return rows;
    }
}
