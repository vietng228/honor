# HONOR DEBLOAT — release 1.0.2

Package: `com.vxm.honor`. Android 11 trở lên, ưu tiên HONOR/MagicOS. APK universal có arm64-v8a, armeabi-v7a và x86_64. Bản release ký khóa riêng, R8 và resource shrinking; Chỉ xuất một APK universal, không tách theo ABI. Không tự thay đổi máy khi khởi chạy. Xem RELEASE.md trước khi thay bản preview vì chữ ký khác.

## Chức năng

- **Kết nối**: ghép đôi Wireless Debugging bằng mã 6 số, tìm cổng bằng mDNS, kết nối self ADB ở 127.0.0.1. Có thể dùng TCP 5555 nếu cổng này đã được bật.
- **Debloat**: Quét toàn bộ app đang cài cho user 0 để chọn thêm; gói ngoài danh mục ghi Chưa đánh giá, không tự chọn. Chặn app này, một số thành phần lõi, UID hệ thống, launcher mặc định và bàn phím đang dùng nhận diện được; không bảo đảm các gói còn lại đều an toàn. Gói quét thêm vẫn tắt/bật/hoàn tác theo trạng thái lưu; sau mở lại app cần quét lại để thao tác gói ngoài danh mục. 60 gói tham chiếu từ phiên kiểm tra HONOR trước. Hiện 10 dòng trong khung và cuộn để xem tiếp. Tìm theo tên/package, đọc mô tả, chọn từng gói, tắt, bật kể cả gói đã tắt từ trước, hoặc hoàn tác. Không chọn sẵn, không uninstall và không xóa dữ liệu.
- **Tiện ích**: chọn ngôn ngữ cho app hệ thống có giao diện mở được (kể cả Package Installer); ngôn ngữ từ localeConfig hoặc tài nguyên APK/split APK, có Theo hệ thống; tắt/bật Enhanced service kiểm tra cloud APK; tắt/bật gói plugin quét HONOR gồm Qihoo, AVL và chống gian lận.
- **Quyền**: Bấm app trong danh sách để xem quyền thông thường với tên tiếng Việt và Cho phép / Không cho phép. Mã ADB thu vào Chi tiết; quyền kỹ thuật và AppOps nằm trong Nâng cao. Chỉ đổi tên hiển thị, không gộp các quyền khác nhau thành một công tắc. Đọc danh sách app người dùng qua ADB user 0; hiển thị tên quyền, định danh ADB, trạng thái, protection level, cờ và AppOps mà ROM cung cấp. Cấp/thu hồi quyền runtime hoặc development mà ADB cho phép; SYSTEM_FIXED/POLICY_FIXED và quyền hệ thống không đổi được sẽ chỉ xem. AppOps có chế độ allow/ignore/foreground/deny/default với phạm vi app hoặc UID; UID dùng chung được liệt kê khi xác nhận. Mỗi thay đổi đọc lại kết quả. AppOps không đồng nghĩa với quyền runtime; Nếu dumpsys thiếu trạng thái nhưng PackageManager có định nghĩa quyền và app đang chạy trên user 0, trạng thái được đối chiếu qua API PackageManager; còn lại giữ Chưa rõ. QUERY_ALL_PACKAGES dùng để lấy nhãn app/quyền cho chức năng này.
- **Nhật ký**: tối đa 100 kết quả, trạng thái đọc lại từ shell; số bản ghi hiện trên badge tab.

Giao diện WebView cục bộ theo Liquid Glass, dùng blur/saturation, điểm sáng ở viền, capsule và nền gradient xám xanh có chiều sâu, một giao diện tối duy nhất, và font Google Sans Flex Freeze Regular lấy từ file HWT do người dùng cung cấp. Theo yêu cầu cuối, cả bảng, thẻ, toast và hộp xác nhận trong app đều có chất liệu glass. Lớp phủ kính rất nhẹ, giảm blur và độ đục; bảng, nút, dock, toast và popup để nền bên dưới hiện rõ hơn. Hộp thoại của hệ thống Android vẫn do hệ thống hiển thị. Các ô tìm kiếm dùng combobox/listbox Liquid Glass, có nhãn ARIA, aria-activedescendant và Arrow/Enter/Escape, không tự focus khi mở app. Có tùy chọn giảm độ trong suốt và giảm chuyển động; không có animation đẩy màn hình khi chuyển tab.

## Kết nối lần đầu trên HONOR

1. Bật Tùy chọn nhà phát triển và Wi-Fi. Nút Mở gỡ lỗi song song yêu cầu Android mở Cài đặt cạnh app; ROM có thể mở toàn màn hình, lúc đó dùng chia đôi màn hình thủ công.
2. Trong Cài đặt, mở Gỡ lỗi không dây → Ghép đôi bằng mã. Dùng chia đôi màn hình để giữ hộp mã trong lúc nhập cổng ghép đôi và mã vào HONOR DEBLOAT.
3. Sau khi ghép đôi thành công, quay về màn hình chính của Gỡ lỗi không dây. Cổng kết nối ở đây KHÁC cổng ghép đôi.
4. Nhập cổng kết nối hoặc bấm Tìm cổng, sau đó Kết nối.
5. Chọn tab Debloat/Tiện ích. Mỗi thay đổi cần thao tác xác nhận trong app.

Nếu dùng TCP ADB 5555 đã bật bằng PC, nhập 5555 và chấp thuận hộp khóa RSA nếu hệ thống hỏi. Sau reboot, Wireless Debugging/cổng có thể đổi; ghép đôi lại khi hệ thống đã thu hồi khóa.

## Phạm vi và hoàn tác

- Lệnh chạy cho user 0: debloat theo danh mục hoặc gói đã quét trên máy, quyền/AppOps theo danh sách app người dùng. Không có ô nhập shell tùy ý và không có kết nối ADB sang máy khác.
- Trạng thái enabled ban đầu được lưu trước khi app thay đổi một gói. Hoàn tác trả về đúng trạng thái đó. Gói vốn đã tắt trước lần sử dụng này không tự được bật lại.
- Khi cài app này lên điện thoại đã debloat từ PC, các thay đổi cũ không thuộc lịch sử hoàn tác của app. Dùng script backup của phiên PC cho các thay đổi cũ.
- Theo hệ thống xóa ngôn ngữ riêng của app đã chọn; không đổi ngôn ngữ hệ thống. Chỉ liệt kê app hệ thống đang bật có launcher, cùng Package Installer có giao diện cài APK. Không liệt kê app người dùng. Khi thiếu localeConfig, danh sách dựa trên cấu hình ngôn ngữ thực có trong APK/split APK; không đoán tiếng Anh từ tài nguyên mặc định không có mã ngôn ngữ và không khẳng định mọi chuỗi đã được dịch.
- Tắt cloud không đồng nghĩa tắt quét cục bộ. Tắt `com.hihonor.securitypluginbase` ảnh hưởng cả ba plugin quét, không chỉ Qihoo; Phone Manager, trình cài và Google Play Services vẫn giữ.
- Một số gói như Kid Mode có thể bị ROM bảo vệ. App báo không đổi được nếu trạng thái đọc lại không khớp. Không thử lách bằng uninstall.
- Game Assistant không được chọn sẵn; Game Kit là một package riêng, được chú thích trong danh mục.

Khóa ADB/certificate nằm trong vùng riêng không sao lưu của app. Mã pairing không được ghi vào nhật ký. WebView chỉ tải tài nguyên đi kèm APK và không được truy cập nội dung web ngoài. App không có analytics hoặc server.

## Build trên workspace hiện tại

```powershell
.\build.ps1
```

Cần JDK 17, Android SDK 36, Gradle 8.11.1 và AGP 8.10.1. `local.properties` trỏ đến Android SDK cục bộ. Dependency self ADB/TLS và BouncyCastle đã có trong `app/libs`; AndroidX annotation và JUnit dùng Gradle cache.

## Kiểm thử

- Unit tests: đọc đúng enabled state user 0, từ chối hoàn tác nếu không đọc được trạng thái, phân biệt đúng tên package, chặn cổng sai hoặc chuỗi shell thay cho cổng; đọc quyền đúng user 0 và giữ Chưa rõ khi không có trạng thái.
- Android integration runner chỉ cho emulator: self ADB thật, shell uid 2000, danh mục 60 gói, 5 tab, cấp/thu hồi quyền Camera, AppOps cấp app/UID, xác nhận glass nhận/hủy, không chọn sẵn, không tràn ngang, tắt, bật gói vốn đã tắt và hoàn tác gói mẫu trên emulator.
- HONOR-specific Weather/Enhanced service/plugin commands dựa trên các lệnh đã xác minh ở phiên ADB trên máy thật; APK này cần thử ghép đôi và giao diện trên HONOR trước khi coi là bản ổn định.

Kết quả kiểm thử và ảnh giao diện nằm trong `qa/`. Không cài bản thử lên điện thoại HONOR của người dùng trong lượt build này.

## Thư viện

Nguồn và license được ghi trong `THIRD_PARTY_NOTICES.md` và `app/src/main/assets/licenses/`.

## OTA 1.0.2

The app checks https://vietng228.github.io/honor/update.json once per day and on demand. A newer compatible version offers a browser download from the fixed HTTPS /honor/downloads/ path. Android validates the APK signature when the user installs it. No silent installation. Keep versionCode increasing and sign every update with the existing private key. The WebView remains offline.
