package com.vxm.honor;

import static org.junit.Assert.*;
import org.junit.Test;

public class ScriptCommandTest {
    @Test public void plainCommandsUntouched() {
        assertEquals("pm list packages", MainActivity.scriptCommand("pm list packages"));
        assertEquals("ls /sdcard/Download", MainActivity.scriptCommand("ls /sdcard/Download"));
    }
    @Test public void pathScriptRunsThroughSh() {
        assertEquals("sh '/sdcard/Download/fixnoti.sh'", MainActivity.scriptCommand("/sdcard/Download/fixnoti.sh"));
        assertEquals("sh '/sdcard/a b.sh' 1", MainActivity.scriptCommand("sh \"/sdcard/a b.sh\" 1"));
    }
    @Test public void bareScriptIsLookedUp() {
        for (String in : new String[]{"fixnoti.sh", "./fixnoti.sh", "sh fixnoti.sh", "bash fixnoti.sh"}) {
            String out = MainActivity.scriptCommand(in);
            assertTrue(in, out.startsWith("f='fixnoti.sh';"));
            assertTrue(in, out.contains("/sdcard/Download"));
        }
    }
}
