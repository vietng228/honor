# Build bản release Việt Ximi: R8 làm rối + rút gọn, ký VietMiTV (v2/v3/v4), gom vào dist\.
# Mật khẩu keystore giải mã từ D:\Claude\secrets (DPAPI, chỉ user này đọc được).
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$sec = Import-Clixml 'D:\Claude\secrets\vietmitv-ks-pass.xml'
$env:VXM_KS_PASS = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
$env:JAVA_HOME = 'C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot'
try { & .\gradlew.bat clean assembleRelease --no-daemon -q } finally { Remove-Item Env:VXM_KS_PASS }
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }

$meta = Get-Content app\build\outputs\apk\release\output-metadata.json -Raw | ConvertFrom-Json
$ver = $meta.elements[0].versionName
New-Item -ItemType Directory -Force dist | Out-Null
$apk = "dist\VietXimi-Assist-$ver.apk"
Copy-Item app\build\outputs\apk\release\app-release.apk $apk -Force
"$((Get-FileHash $apk -Algorithm SHA256).Hash.ToLower())  $(Split-Path $apk -Leaf)" | Out-File "$apk.sha256" -Encoding ascii
$kb = [math]::Round((Get-Item $apk).Length / 1KB)
Write-Host "OK: $apk ($kb KB)"

# Xác minh chữ ký v2/v3 bằng apksigner của build-tools mới nhất
$bt = Get-ChildItem "$env:LOCALAPPDATA\Android\Sdk\build-tools" | Sort-Object Name -Desc | Select-Object -First 1
& "$($bt.FullName)\apksigner.bat" verify --print-certs -v $apk 2>&1 | Select-String 'Verified using|Number of signers|SHA-256'
