# ===== Làm rối tối đa + chống dịch ngược =====
-optimizationpasses 5
-allowaccessmodification
-repackageclasses 'o'        # dồn mọi lớp vào 1 gói tên 'o' cho khó đọc
-overloadaggressively
-renamesourcefileattribute ''
# Bỏ hết log của app khi chạy thật
-assumenosideeffects class android.util.Log {
    public static int v(...); public static int d(...); public static int i(...);
    public static int w(...); public static int e(...);
}

# ===== Lớp tự kiểm tra chữ ký phải giữ nguyên để chạy đúng =====
-keep class com.viet.trolyai.Guard { *; }

# Điểm vào khai báo trong Manifest do AGP tự giữ (Activity/Service). Giữ thêm tên để log sự cố đọc được.
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*,RuntimeVisible*Annotations

# ===== Anthropic Java SDK + Jackson (dùng phản chiếu để đọc/ghi JSON) =====
-keep class com.anthropic.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-keep interface com.fasterxml.jackson.** { *; }
-keepnames class com.fasterxml.jackson.** { *; }
-keepclassmembers class * {
    @com.fasterxml.jackson.annotation.* *;
}
-dontwarn com.fasterxml.jackson.**
-dontwarn com.anthropic.**

# ===== OkHttp / Okio =====
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# ===== org.json có sẵn trong Android, không cần giữ gì thêm =====

# Bỏ cảnh báo thư viện chỉ dùng khi biên dịch
-dontwarn javax.annotation.**
-dontwarn java.beans.**
-dontwarn org.slf4j.**
-dontwarn kotlin.**
-dontwarn com.google.auto.value.**
-dontwarn com.github.victools.**
-dontwarn io.opentelemetry.**
-dontwarn java.lang.reflect.AnnotatedType
-dontwarn java.lang.reflect.AnnotatedParameterizedType
-dontwarn org.slf4j.**
# Bỏ tính năng sinh JSON schema và OpenTelemetry của SDK (không dùng trong app) nếu R8 bỏ được
-dontwarn com.fasterxml.jackson.databind.**
