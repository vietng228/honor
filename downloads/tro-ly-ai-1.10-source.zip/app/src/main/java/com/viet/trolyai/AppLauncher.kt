package com.viet.trolyai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import java.text.Normalizer

/**
 * Thao tác trên máy theo lời người dùng. AI chèn thẻ lệnh vào câu trả lời, ví dụ
 * [MO_APP: Facebook], [BAO_THUC: 06:30 | Đi làm]; ở đây thực hiện rồi bỏ thẻ khỏi câu trả lời.
 */
object AppLauncher {
    /** Hướng dẫn cho AI (ghép vào system prompt). */
    val GUIDE = """
        Bạn điều khiển được điện thoại bằng cách thêm thẻ lệnh ở cuối câu trả lời (mỗi việc một thẻ, đúng cú pháp):
        [MO_APP: tên ứng dụng] mở ứng dụng. Người dùng muốn mở app nào thì LUÔN thêm thẻ này với đúng tên họ nói,
          KHÔNG được tự phán là "không có/không tìm thấy" — hệ thống tự tìm app phù hợp, kể cả khi tên hiển thị khác
          (vd Telegram ↔ Nekogram, YouTube ↔ bản khác, Zalo, truyền hình…); chỉ hệ thống mới báo nếu thật sự không có.
        [BAO_THUC: HH:MM | nhãn] đặt báo thức theo giờ 24h
        [HEN_GIO: số giây | nhãn] hẹn giờ đếm ngược
        [DEN_PIN: bat] hoặc [DEN_PIN: tat] bật/tắt đèn pin
        [AM_LUONG: số 0-100] chỉnh âm lượng nhạc
        [GOI: tên liên hệ hoặc số điện thoại] tra danh bạ rồi mở màn hình gọi
        [YOUTUBE: từ khoá] mở app YouTube và tìm — DÙNG cho mọi yêu cầu nghe/xem nhạc, bài hát, MV, video, ca sĩ,
          phim, clip (vd "mở nhạc trẻ", "phát bài X", "xem video Y"); KHÔNG mở trình duyệt cho mấy việc này
        [TIM: từ khoá] mở trang tìm Google trong trình duyệt — CHỈ khi người dùng nói rõ "mở Google/Chrome/trình duyệt"
        [CHI_DUONG: địa điểm] chỉ đường bằng bản đồ
        [CAI_DAT: mục] mở trang cài đặt, mục là một trong: wifi, bluetooth, mang, du_lieu, hotspot, vi_tri,
          am_thanh, khong_lam_phien, man_hinh, pin, luu_tru, ung_dung, thong_bao, bao_mat, ngon_ngu, ban_phim,
          ngay_gio, tro_nang, nfc, may_bay, sao_luu, nha_phat_trien, gioi_thieu, chung
        [CAI_DAT_APP: tên ứng dụng] mở trang thông tin/quyền của một ứng dụng
        [TIN_NHAN: tên liên hệ hoặc số điện thoại | nội dung] tra danh bạ rồi soạn tin nhắn SMS
        [LICH: tiêu đề | yyyy-MM-dd HH:mm] tạo sự kiện lịch
        [MAY_ANH] mở máy ảnh
        [WEB: địa chỉ trang web] mở trang web
        Khi dùng thẻ, nói ngắn gọn việc đang làm, ví dụ: "Em đặt báo thức 6 giờ 30 sáng cho anh nhé. [BAO_THUC: 06:30 | Đi làm]".
        Việc không có trong danh sách thì nói thật là chưa làm được, tuyệt đối không nói là đã làm.
    """.trimIndent()

    private val TAG = Regex("""\[([A-Z_]+):\s*([^\]]*)]""")

    /** Trả về câu trả lời đã bỏ thẻ; lệnh nào lỗi thì nói rõ. */
    fun handle(ctx: Context, reply: String): String {
        val fails = mutableListOf<String>()
        TAG.findAll(reply).forEach { m ->
            val (cmd, arg) = m.destructured
            lastStarted = null
            val ok = runCatching { run(ctx, cmd, arg.trim()) }
                .onFailure { Log.w("HaMi", "Lệnh $cmd lỗi", it) }.getOrDefault(false)
            if (!ok) fails += failText(cmd, arg.trim())
            // Báo kết quả lên đảo động / thông báo để người dùng biết lệnh đã chạy thật
            val (title, short) = label(ctx, cmd, arg.trim())
            Notifier.done(ctx, ok, if (ok) title else "Chưa làm được: " + title.replaceFirstChar { it.lowercase() },
                short, if (ok) tapIntent(cmd) else null)
        }
        val clean = reply.replace(TAG, "").trim()
        return if (fails.isEmpty()) clean else (fails.joinToString(" ")).ifEmpty { clean }
    }

    /** Bấm vào thông báo → mở đúng app liên quan (báo thức → Đồng hồ, mở app → app đó, cài đặt → trang đó…). */
    private fun tapIntent(cmd: String): Intent? = when (cmd) {
        "BAO_THUC" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
        "HEN_GIO" -> Intent(AlarmClock.ACTION_SHOW_TIMERS)
        "LICH" -> Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
            .appendPath(System.currentTimeMillis().toString()).build())
        "AM_LUONG" -> Intent(Settings.ACTION_SOUND_SETTINGS)
        "DEN_PIN" -> null
        else -> lastStarted
    }?.let { Intent(it).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    /** Màn hình vừa được mở bởi lệnh gần nhất. */
    private var lastStarted: Intent? = null

    /** Nội dung thông báo: (tiêu đề, chữ ngắn trên đảo động). */
    private fun label(ctx: Context, cmd: String, arg0: String): Pair<String, String> {
        // Tên app lấy đúng như trên máy (YouTube, TikTok…), không theo cách AI viết
        val arg = if (cmd == "MO_APP" || cmd == "CAI_DAT_APP") appLabel(ctx, arg0) ?: Pretty.fix(ctx, arg0) else arg0
        val p = arg.split("|").map { it.trim() }
        return when (cmd) {
            "MO_APP" -> "Đã mở $arg" to arg.take(12)
            "BAO_THUC" -> "Đã đặt báo thức ${p[0]}" + (p.getOrNull(1)?.let { " · $it" } ?: "") to "⏰ ${p[0]}"
            "HEN_GIO" -> { val s = p[0].filter { it.isDigit() }.toIntOrNull() ?: 0
                "Đã hẹn giờ ${if (s >= 60) "${s / 60} phút" else "$s giây"}" to "⏱ ${s / 60}:${"%02d".format(s % 60)}" }
            "DEN_PIN" -> (if (arg.startsWith("b", true)) "Đã bật đèn pin" else "Đã tắt đèn pin") to "🔦"
            "AM_LUONG" -> "Âm lượng ${arg.filter { it.isDigit() }}%" to "🔊 ${arg.filter { it.isDigit() }}%"
            "GOI" -> "Đã mở màn hình gọi $arg" to "📞"
            "TIN_NHAN" -> "Đã soạn tin nhắn tới ${p[0]}" to "✉"
            "LICH" -> "Đã tạo lịch: ${p[0]}" to "📅"
            "CHI_DUONG" -> "Đã mở chỉ đường tới $arg" to "🧭"
            "CAI_DAT", "CAI_DAT_APP" -> "Đã mở cài đặt $arg" to "⚙"
            "MAY_ANH" -> "Đã mở máy ảnh" to "📷"
            "YOUTUBE" -> "Đã tìm trên YouTube: $arg" to "▶"
            else -> "Đã mở $arg" to arg.take(12)
        }
    }

    private fun failText(cmd: String, arg: String) = when (cmd) {
        "MO_APP" -> "Mình không tìm thấy ứng dụng $arg trên máy."
        "GOI", "TIN_NHAN" -> "Mình không tìm thấy số điện thoại của ${arg.substringBefore('|').trim()} trong danh bạ."
        else -> "Xin lỗi, mình chưa làm được việc này trên máy."
    }

    private fun run(ctx: Context, cmd: String, arg: String): Boolean {
        val parts = arg.split("|").map { it.trim() }
        return when (cmd) {
            "MO_APP" -> open(ctx, arg)
            "BAO_THUC" -> {
                val (h, m) = parts[0].split(":", "h", "g").map { it.trim().toInt() }.let { it[0] to it.getOrElse(1) { 0 } }
                start(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, parts.getOrElse(1) { "Việt Ximi" })
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            "HEN_GIO" -> start(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, parts[0].filter { it.isDigit() }.toInt())
                .putExtra(AlarmClock.EXTRA_MESSAGE, parts.getOrElse(1) { "Việt Ximi" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "DEN_PIN" -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                cm.setTorchMode(id, norm(arg).startsWith("bat") || arg == "on"); true
            }
            "AM_LUONG" -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val pct = arg.filter { it.isDigit() }.toInt().coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * pct / 100, AudioManager.FLAG_SHOW_UI); true
            }
            "GOI" -> phone(ctx, arg)?.let {
                start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(it))))
            } ?: false
            "YOUTUBE" -> openYoutube(ctx, arg)
            "TIM" -> start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg))))
            "CHI_DUONG" -> start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(arg))))
                || start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(arg))))
            "CAI_DAT" -> start(ctx, Intent(SETTINGS[norm(arg)] ?: Settings.ACTION_SETTINGS))
                || start(ctx, Intent(Settings.ACTION_SETTINGS))
            "CAI_DAT_APP" -> findApp(ctx, arg)?.let {
                start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it")))
            } ?: false
            "TIN_NHAN" -> phone(ctx, parts[0])?.let {
                start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(it)))
                    .putExtra("sms_body", parts.getOrElse(1) { "" }))
            } ?: false
            "LICH" -> {
                val t = runCatching {
                    java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).parse(parts[1])!!.time
                }.getOrDefault(System.currentTimeMillis() + 3600_000)
                start(ctx, Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, parts[0])
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, t)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, t + 3600_000))
            }
            "MAY_ANH" -> start(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "WEB" -> start(ctx, Intent(Intent.ACTION_VIEW,
                Uri.parse(if (arg.startsWith("http")) arg else "https://$arg")))
            else -> false
        }
    }

    /** Thời điểm vừa mở màn hình khác (phiên Live dùng để tự ẩn nhường chỗ). */
    @Volatile var lastLaunch = 0L

    /** Tìm nhạc/video → mở TRONG app YouTube đã cài (kể cả bản tên gói khác), không rơi vào Chrome. */
    private fun openYoutube(ctx: Context, query: String): Boolean {
        val pkg = findApp(ctx, "youtube")
        val url = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        if (pkg != null) {
            // Mở URL tìm kiếm NHƯNG ép vào đúng app YouTube (không cho trình duyệt xử lý)
            if (start(ctx, Intent(Intent.ACTION_VIEW, url).setPackage(pkg))) return true
            if (start(ctx, Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra("query", query))) return true
            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { if (start(ctx, it)) return true }
        }
        return start(ctx, Intent(Intent.ACTION_VIEW, url)) // không có app YouTube → đành mở trình duyệt
    }

    private fun start(ctx: Context, i: Intent) = runCatching {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Không phải từ màn hình đang hiện (bảng Live, nền) → mở qua màn hình trung gian để không bị máy chặn
        if (ctx is android.app.Activity) ctx.startActivity(i)
        else ctx.startActivity(Intent(ctx, LaunchActivity::class.java).putExtra(LaunchActivity.EXTRA, i)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        lastLaunch = System.currentTimeMillis()
        lastStarted = i; true
    }.getOrDefault(false)

    private fun norm(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace('đ', 'd').replace('Đ', 'D')
        .lowercase().replace(Regex("[^a-z0-9]"), "")

    /** Số nhập trực tiếp hoặc số của liên hệ khớp tên nhất trong danh bạ. */
    private fun phone(ctx: Context, value: String): String? {
        val direct = value.trim().filter { it.isDigit() || it == '+' }
        if (direct.count { it.isDigit() } >= 3 && value.none { it.isLetter() }) return direct
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null

        val wanted = norm(value)
        if (wanted.isEmpty()) return null
        var best: Pair<Int, String>? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
            ), null, null, null
        )?.use { cursor ->
            val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
            val numberCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val name = norm(cursor.getString(nameCol) ?: continue)
                val score = when {
                    name == wanted -> 0
                    name.startsWith(wanted) || wanted.startsWith(name) -> 1
                    name.contains(wanted) || wanted.contains(name) -> 2
                    else -> continue
                }
                val number = cursor.getString(numberCol)?.filter { it.isDigit() || it == '+' }.orEmpty()
                if (number.isNotEmpty() && (best == null || score < best!!.first)) best = score to number
            }
        }
        return best?.second
    }

    private val SETTINGS = mapOf(
        "wifi" to Settings.ACTION_WIFI_SETTINGS,
        "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "mang" to Settings.ACTION_WIRELESS_SETTINGS,
        "dulieu" to Settings.ACTION_DATA_ROAMING_SETTINGS,
        "hotspot" to Settings.ACTION_WIRELESS_SETTINGS,
        "vitri" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "amthanh" to Settings.ACTION_SOUND_SETTINGS,
        "khonglamphien" to "android.settings.ZEN_MODE_SETTINGS",
        "manhinh" to Settings.ACTION_DISPLAY_SETTINGS,
        "pin" to Intent.ACTION_POWER_USAGE_SUMMARY,
        "luutru" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "ungdung" to Settings.ACTION_APPLICATION_SETTINGS,
        "thongbao" to "android.settings.NOTIFICATION_SETTINGS",
        "baomat" to Settings.ACTION_SECURITY_SETTINGS,
        "ngonngu" to Settings.ACTION_LOCALE_SETTINGS,
        "banphim" to Settings.ACTION_INPUT_METHOD_SETTINGS,
        "ngaygio" to Settings.ACTION_DATE_SETTINGS,
        "tronang" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "nfc" to Settings.ACTION_NFC_SETTINGS,
        "maybay" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "saoluu" to Settings.ACTION_PRIVACY_SETTINGS,
        "nhaphattrien" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        "gioithieu" to Settings.ACTION_DEVICE_INFO_SETTINGS,
        "chung" to Settings.ACTION_SETTINGS,
    )

    fun open(ctx: Context, name: String): Boolean {
        val pkg = findApp(ctx, name) ?: return false
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(ctx, intent)
    }

    private fun appLabel(ctx: Context, name: String): String? = when (norm(name)) {
        "youtube", "yt", "youtub" -> "YouTube"            // tên app thật có thể là tên Trung Quốc
        "telegram", "tele", "tg" -> "Telegram"
        "youtubemusic", "ytmusic", "nhacyoutube" -> "YouTube Music"
        else -> null
    } ?: findApp(ctx, name)?.let { pkg ->
        runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrNull()
    }

    /**
     * YouTube trên nhiều máy (nhất là máy bản Trung Quốc không có Google) là bản sửa hoặc app thay thế
     * với tên gói khác; gọi "YouTube" thì mở bản nào đang có, theo thứ tự ưu tiên này.
     */
    private val YOUTUBE = listOf(
        "com.google.android.youtube", "app.revanced.android.youtube", "app.rvx.android.youtube",
        "app.morphe.android.youtube", "com.vanced.android.youtube", "com.mgoogle.android.youtube",
        "com.google.android.youtube.tv", "com.liskovsoft.smarttubetv.beta", "com.liskovsoft.smarttubetv",
        "org.schabi.newpipe", "org.polymorphicshade.newpipe", "org.polymorphicshade.tubular",
        "com.github.libretube", "free.rm.skytube.oss", "app.grayjay",
        // Bản YouTube cài dưới tên gói app Trung Quốc (máy bản nội địa): coi tất cả là YouTube
        "com.kuaishou.nebula", "com.smile.gifmaker", "tv.danmaku.bili", "com.xingin.xhs", "cn.kuwo.player",
        "com.youku.phone", "com.tencent.qqmusic", "com.sina.weibo", "com.qiyi.video", "com.tencent.qqlive",
        "com.apple.android.music", "com.kugou.android", "com.ss.android.ugc.aweme.lite", "com.ss.android.ugc.aweme",
        "com.baidu.haokan", "com.phoenix.read", "com.zhiliaoapp.musically", "com.netease.cloudmusic",
    )
    private val YOUTUBE_MUSIC = listOf(
        "com.google.android.apps.youtube.music", "app.revanced.android.apps.youtube.music",
        "app.rvx.android.apps.youtube.music", "app.morphe.android.apps.youtube.music",
        "com.vanced.android.apps.youtube.music", "it.vfsfitvnm.vimusic", "it.fast4x.rimusic",
        "com.maxrave.simpmusic", "com.zionhuang.music", "com.metrolist.music",
    )

    /** Mọi bản Telegram (Nekogram, Telegram X, Plus…) đều là "Telegram". */
    private val TELEGRAM = listOf(
        "org.telegram.messenger", "org.telegram.messenger.web", "tw.nekomimi.nekogram", "xyz.nextalone.nagram",
        "nekox.messenger", "org.thunderdog.challegram", "org.telegram.plus", "com.exteragram.messenger",
        "uz.unnarsx.cherrygram", "it.octogram.android", "com.radolyn.ayugram", "org.forkgram.messenger",
    )
    /** App xem truyền hình (VietMiTV, VXM TV, FPT Play, TV360, VTVgo, MyTV, VieON…) gọi chung là "truyền hình". */
    private val TV = listOf(
        "com.ai.vietximi2", "com.vxm.voiceassist.googletv", "com.vxm.vietmitv", "vn.fptplay.mobile", "com.fptplay.mobile",
        "com.viettel.tv360", "vn.vtv.vtvgo", "com.vnpt.mytv", "vn.vnpt.mytv", "com.vieon.tv", "vieon.tv",
        "com.vtvcab.ontv", "com.sctv.app", "vn.htv.htvc",
    )

    /** Tên gói của app khớp tên nhất (bỏ dấu, không phân biệt hoa thường). */
    private fun findApp(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = norm(name).ifEmpty { return null }
        val installed = apps.map { it.activityInfo.packageName }.toSet()
        // YouTube Music / YouTube: nhận mọi bản sửa, app thay thế và biến thể tên (YouTube Vanced/ReVanced/Plus…)
        val alias = when {
            q.contains("youtube") && (q.contains("music") || q.contains("nhac")) -> YOUTUBE_MUSIC
            q == "ytmusic" || q == "nhacyoutube" -> YOUTUBE_MUSIC
            q.contains("youtube") || q == "yt" || q == "ytb" || q == "youtub" -> YOUTUBE
            else -> null
        }
        // Telegram và mọi biến thể (Telegram Plus/X, Nekogram, exteraGram…): "mở telegram ..." đều mở app Telegram trên máy
        if (q.contains("telegram") || q.contains("nekogram") || q == "tele" || q == "tg" ||
            (q.contains("gram") && !q.contains("instagram") && !q.contains("program"))) {
            TELEGRAM.firstOrNull { it in installed }?.let { return it }
            installed.firstOrNull { it.contains("telegram") || (it.contains("gram") && !it.contains("instagram")) }?.let { return it }
        }
        // Truyền hình / TV / xem tivi: app TV đã biết, rồi app có "TV" trong tên
        if (q in setOf("truyenhinh", "tv", "tivi", "xemtivi", "xemtv", "xemtruyenhinh", "apptruyenhinh", "ungdungtruyenhinh")) {
            TV.firstOrNull { it in installed }?.let { return it }
            apps.firstOrNull { ri -> Regex("(^|[^a-z])tv([^a-z]|$)", RegexOption.IGNORE_CASE)
                .containsMatchIn(ri.loadLabel(pm).toString()) && !ri.activityInfo.packageName.contains("tools") }
                ?.let { return it.activityInfo.packageName }
        }
        if (alias != null) {
            alias.firstOrNull { it in installed }?.let { return it }
            val music = alias === YOUTUBE_MUSIC
            installed.firstOrNull { p -> p.contains("youtube") && p.contains("music") == music && !p.contains("kids") }
                ?.let { return it }
        }
        // Gọi theo loại app ("thời tiết", "máy ảnh", "CH Play"…) → app cùng loại trên máy (tên hoặc tên gói)
        CATEGORY.entries.firstOrNull { (k, _) -> q == k || q == "ungdung$k" || q == "app$k" }?.value?.let { keys ->
            apps.firstOrNull { ri ->
                val l = norm(ri.loadLabel(pm).toString()); val p = ri.activityInfo.packageName.lowercase()
                keys.any { k -> l.contains(k) || p.contains(k) }
            }?.let { return it.activityInfo.packageName }
        }
        // Ưu tiên: trùng tên > tên bắt đầu bằng > tên chứa > tên gói chứa > gần giống (nghe nhầm, gõ sai)
        val scored = apps.mapNotNull { ri ->
            val label = norm(ri.loadLabel(pm).toString())
            val pkg = ri.activityInfo.packageName.lowercase()
            val score = when {
                label == q -> 100.0
                label.startsWith(q) || q.startsWith(label) && label.length >= 3 -> 90.0
                label.contains(q) -> 80.0
                pkg.contains(q) -> 70.0
                else -> similar(q, label).let { if (it >= 0.72) it * 60 else 0.0 }
            }
            if (score > 0) score to ri else null
        }
        return scored.maxByOrNull { it.first }?.second?.activityInfo?.packageName
    }

    /** Độ giống nhau 0..1 (Levenshtein) giữa hai tên đã bỏ dấu. */
    private fun similar(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return 1.0 - d[b.length].toDouble() / maxOf(a.length, b.length)
    }

    /** Tên loại app tiếng Việt → từ khoá trong tên app hoặc tên gói. */
    private val CATEGORY = mapOf(
        "thoitiet" to listOf("thoitiet", "weather"),
        "dongho" to listOf("dongho", "clock", "deskclock"),
        "baothuc" to listOf("dongho", "clock", "deskclock"),
        "mayanh" to listOf("mayanh", "camera"),
        "camera" to listOf("camera"),
        "anh" to listOf("thuvienanh", "gallery", "photos", "album"),
        "thuvienanh" to listOf("thuvienanh", "gallery", "photos", "album"),
        "lich" to listOf("calendar"),
        "danhba" to listOf("danhba", "contacts"),
        "dienthoai" to listOf("dienthoai", "dialer", "contacts", "phone"),
        "goidien" to listOf("dialer", "contacts", "phone"),
        "tinnhan" to listOf("tinnhan", "mms", "messaging", "messages"),
        "maytinh" to listOf("maytinh", "calculator"),
        "ghiam" to listOf("ghiam", "recorder", "soundrecorder"),
        "tep" to listOf("quanlytep", "filemanager", "files", "fileexplorer", "documentsui"),
        "quanlytep" to listOf("quanlytep", "filemanager", "files", "fileexplorer"),
        "caidat" to listOf("caidat", "settings"),
        "chplay" to listOf("com.android.vending", "playstore", "cuahangplay"),
        "cuahang" to listOf("appmarket", "market", "vending", "store"),
        "bando" to listOf("bando", "maps"),
        "trinhduyet" to listOf("chrome", "browser", "trinhduyet"),
        "nhac" to listOf("music", "nhac"),
        "ghichu" to listOf("ghichu", "notes", "notepad"),
        "email" to listOf("gmail", "email", "mail"),
        "video" to listOf("video", "player"),
    )

    /** Tên các app đang cài (để AI chọn đúng tên khi người dùng nói sai / máy nghe nhầm). */
    @Volatile var installedNames: String = ""
        private set

    fun refreshInstalled(ctx: Context) {
        val pm = ctx.packageManager
        installedNames = runCatching {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString().trim() }.distinct().sorted().joinToString(", ")
        }.getOrDefault("")
    }
}
