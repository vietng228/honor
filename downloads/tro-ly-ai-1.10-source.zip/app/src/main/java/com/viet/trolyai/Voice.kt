package com.viet.trolyai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

/** Nghe (SpeechRecognizer) và đọc (TextToSpeech) tiếng Việt. Dùng trên luồng chính. */
class Voice(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onPartial(text: String) {}
        /** Trạng thái khi nghe bằng Gemini ("Đang nghe…", "Đang chuyển giọng thành chữ…"). */
        fun onStatus(text: String) {}
        /** Độ to giọng nói 0..1 (để vẽ sóng âm). */
        fun onLevel(level: Float) {}
        /** null = không nghe được gì. */
        fun onHeard(text: String?)
        fun onSpeakDone() {}
    }

    private val main = Handler(Looper.getMainLooper())
    var listening = false; private set
    var speaking = false; private set
    @Volatile private var generation = 0
    @Volatile private var track: android.media.AudioTrack? = null
    /** null = đọc được tiếng Việt. */
    var ttsProblem: String? = "Bộ đọc giọng nói chưa sẵn sàng"; private set

    /**
     * Chọn bộ nhận giọng THẬT trên máy (ưu tiên Google), bỏ qua bộ giả của chính app: khi Việt Ximi là trợ lý
     * mặc định, một số máy (Honor…) đặt bộ nhận mặc định thành bộ giả đó nên nghe không ra gì.
     * Không có bộ nào → nghe bằng Gemini (CloudEar).
     */
    private fun pickRecognizer(): android.content.ComponentName? {
        val list = ctx.packageManager.queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
            .map { android.content.ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
            .filter { it.packageName != ctx.packageName }
        // Bộ mặc định của máy nếu là bộ thật thì dùng luôn
        android.provider.Settings.Secure.getString(ctx.contentResolver, "voice_recognition_service")
            ?.let { android.content.ComponentName.unflattenFromString(it) }
            ?.let { def -> list.firstOrNull { it == def } }?.let { return it }
        val prefer = listOf("com.google.android.googlequicksearchbox", "com.google.android.tts")
        // Bộ lạ của app khác (vd ứng dụng chat) thường không chạy độc lập → không dùng, chuyển sang Gemini
        return prefer.firstNotNullOfOrNull { p -> list.firstOrNull { it.packageName == p } }
    }

    private val cloud = CloudEar()
    /** true = máy không nghe được bằng bộ nhận giọng → dùng Gemini. */
    private var useCloud = false

    private val recognizer: SpeechRecognizer? = pickRecognizer()?.let { SpeechRecognizer.createSpeechRecognizer(ctx, it) }?.apply {
        setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                main.removeCallbacks(silence); muteOthers(false)
                listening = false
                cb.onHeard(onlyViEn(r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                    ?.takeIf { !isEcho(it) })
            }
            override fun onPartialResults(r: Bundle) {
                heardAny = true
                armSilence()
                r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { cb.onPartial(it) }
            }
            override fun onError(error: Int) {
                main.removeCallbacks(silence); muteOthers(false)
                if (!listening) return
                Log.w("HaMi", "Nhận giọng lỗi $error")
                // Lỗi do máy (không hỗ trợ tiếng Việt, mất kết nối dịch vụ, thiếu quyền…) → chuyển sang nghe bằng Gemini
                val broken = error in setOf(SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS, 11, 12, 13)
                if (broken && !heardAny && Store.keyOf("Gemini") != null) { useCloud = true; listening = false; listen(); return }
                listening = false; cb.onHeard(null)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { cb.onLevel(((v + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { if (listening) this@apply.stopListening() }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
    }

    /** Một số máy chờ rất lâu mới tự kết thúc: im lặng ~1,2 s sau khi có chữ thì tự ngắt. */
    private val silence: Runnable = Runnable { if (listening) recognizer?.stopListening() }
    private var heardAny = false
    private fun armSilence() { main.removeCallbacks(silence); main.postDelayed(silence, 1200) }

    private lateinit var tts: TextToSpeech
    init {
        all += this
        tts = TextToSpeech(ctx) {
            if (it != TextToSpeech.SUCCESS) { ttsProblem = "Không khởi động được bộ đọc giọng nói"; return@TextToSpeech }
            val r = tts.setLanguage(Locale("vi", "VN"))
            ttsProblem = if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
                "Máy chưa có giọng đọc tiếng Việt: vào Cài đặt › Chuyển văn bản thành giọng nói để tải" else null
            Log.i("HaMi", "TTS vi-VN setLanguage=$r engine=${tts.defaultEngine}")
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = main.post { speaking = false; cb.onSpeakDone() }.let {}
            @Deprecated("") override fun onError(id: String?) = main.post { speaking = false; cb.onSpeakDone() }.let {}
        })
    }

    fun listen() {
        // Dừng mọi giọng Việt Ximi đang đọc (app lẫn micro nổi) để micro không thu lại chính nó
        all.toList().forEach { it.stopSpeaking() }
        listening = true; heardAny = false
        muteOthers(true)
        val key = Store.keyOf("Gemini")
        if (recognizer == null || useCloud) {
            if (key == null) { listening = false; cb.onHeard(null); return }
            cb.onStatus("Đang nghe…")
            cloud.start(key, { part -> main.post { if (listening) onlyViEn(part)?.let { cb.onPartial(it) } } },
                { lv -> main.post { if (listening) cb.onLevel(lv) } }) { text ->
                main.post { muteOthers(false); if (listening) { listening = false; cb.onHeard(onlyViEn(text)?.takeUnless { isEcho(it) }) } }
            }
            return
        }
        recognizer.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        })
    }

    /**
     * Chỉ nhận tiếng Việt và tiếng Anh: bỏ chữ Hàn, Nhật, Trung (nhận nhầm); không còn gì thì coi như không nghe rõ.
     */
    private fun onlyViEn(t: String?): String? = t
        ?.replace(Regex("[\\u1100-\\u11FF\\u3040-\\u30FF\\u3130-\\u318F\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uAC00-\\uD7AF\\uFF66-\\uFF9F]+"), " ")
        ?.replace(Regex("\\s+"), " ")?.trim()?.takeIf { it.any { c -> c.isLetter() } }

    /** Micro thu lại chính giọng Việt Ximi vừa đọc (loa ngoài) → không coi là người dùng nói. */
    private fun isEcho(heard: String): Boolean {
        fun n(x: String) = x.lowercase().filter { it.isLetterOrDigit() }
        val h = n(heard); if (h.length < 8) return false
        val last = Store.messages.lastOrNull { !it.user }?.text?.let(::n) ?: return false
        return last.contains(h.take(24)) || h.contains(last.take(24))
    }

    fun stopListening() {
        main.removeCallbacks(silence); muteOthers(false)
        if (listening) { listening = false; cloud.cancel(); recognizer?.cancel() }
    }

    /** Đọc bằng giọng đã chọn: "ai:<tên>" = giọng AI Gemini, "sys:<tên>" = giọng của máy. */
    fun speak(rawText: String, voiceId: String = Store.ttsVoice) {
        val text = Censor.beep(rawText)   // không phát ra tiếng chửi bậy, thay bằng "bíp"
        stopSpeaking()
        speaking = true
        val gen = ++generation
        val geminiKey = Store.keyOf("Gemini")
        if (voiceId.startsWith("ai:") && geminiKey != null) {
            thread {
                try {
                    val pcm = AiVoice.fetch(text, voiceId.removePrefix("ai:"), geminiKey)
                    if (gen != generation) return@thread
                    AiVoice.play(pcm, { track = it }) { gen != generation }
                    main.post { if (gen == generation) { speaking = false; track = null; cb.onSpeakDone() } }
                } catch (e: Exception) {
                    Log.w("HaMi", "Giọng AI lỗi, chuyển sang giọng máy: ${e.message}")
                    main.post {
                        if (gen == generation) {
                            speaking = false
                            val quota = e.message?.contains("HTTP 429") == true
                            Toast.makeText(ctx, if (quota)
                                "Giọng AI đã hết hạn mức, đang dùng giọng máy"
                            else "Giọng AI tạm lỗi, đang dùng giọng máy", Toast.LENGTH_LONG).show()
                            speakSystem(text, null)
                        }
                    }
                }
            }
        } else speakSystem(text, voiceId.removePrefix("sys:").takeIf { it.isNotEmpty() })
    }

    private fun speakSystem(text: String, voiceName: String?) {
        if (ttsProblem != null) { speaking = false; cb.onSpeakDone(); return }
        val v = voiceName?.let { n -> tts.voices?.firstOrNull { it.name == n } }
        if (v != null) tts.voice = v else tts.setLanguage(Locale("vi", "VN"))
        val r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
        speaking = r == TextToSpeech.SUCCESS
    }

    /** Giọng tiếng Việt có sẵn trên máy (tên kỹ thuật). */
    fun systemVoices(): List<String> =
        runCatching { tts.voices.filter { it.locale.language == "vi" }.map { it.name }.sorted() }.getOrDefault(emptyList())

    fun stopSpeaking() {
        generation++
        track?.let { t -> runCatching { t.pause(); t.flush() } }; track = null
        if (speaking) { speaking = false; tts.stop() }
    }

    /**
     * Giữ "quyền phát âm thanh": app khác (nhạc, video) tạm dừng khi Việt Ximi nghe/nói, trả lại thì phát tiếp.
     */
    private val am = ctx.getSystemService(android.media.AudioManager::class.java)
    private val focus = android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
        .setAudioAttributes(android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setOnAudioFocusChangeListener { }
        .build()
    private var holding = false

    /**
     * Tắt tiếng nhạc/video của app khác trong lúc NGHE (TikTok… không chịu dừng khi được yêu cầu, micro thu lẫn
     * nên không nhận ra giọng). Nghe xong bật lại ngay; lúc Việt Ximi đọc trả lời thì không tắt.
     */
    private var muted = false
    private fun muteOthers(on: Boolean) {
        if (on == muted) return
        muted = on
        runCatching {
            am?.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                if (on) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE, 0)
        }
    }

    fun holdFocus(on: Boolean) {
        if (on == holding) return
        holding = on
        if (on) am?.requestAudioFocus(focus) else am?.abandonAudioFocusRequest(focus)
    }

    fun destroy() { muteOthers(false); holdFocus(false); all -= this; stopSpeaking(); cloud.cancel(); recognizer?.destroy(); tts.shutdown() }

    companion object { private val all = mutableSetOf<Voice>() }
}
