package com.viet.trolyai

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * Chống sửa APK: so chữ ký thực tế của gói đang chạy với chữ ký VietMiTV đã nhúng.
 * Sửa dù 1 byte trong APK sẽ phá chữ ký v2/v3 → cài được chỉ khi ký lại bằng khoá khác →
 * hash khác → app tự thoát. Gọi [enforce] ở mọi điểm vào (Activity, Service).
 */
object Guard {
    // SHA-256 (DER) của chứng chỉ VietMiTV — phải khớp "SHA256:" khi keytool -list -v.
    private const val CERT = "09e227a709535c15ea3dcfc3c6dfd1e9b7974ec3878cc86072f42258ca0d9d2f"

    @Volatile private var checked = false
    @Volatile private var ok = false

    /** true nếu chữ ký đúng; sai thì trả về false (bên gọi tự thoát). Kết quả được nhớ. */
    fun ok(ctx: Context): Boolean {
        if (checked) return ok
        ok = verify(ctx); checked = true
        return ok
    }

    /** Sai chữ ký → kết thúc tiến trình ngay, không cho app chạy tiếp. */
    fun enforce(ctx: Context) {
        if (!ok(ctx)) { android.os.Process.killProcess(android.os.Process.myPid()); kotlin.system.exitProcess(10) }
    }

    private fun verify(ctx: Context): Boolean = try {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.let { if (it.hasMultipleSigners()) it.apkContentsSigners else it.signingCertificateHistory }
                ?: emptyArray()
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val md = MessageDigest.getInstance("SHA-256")
        sigs.any { md.digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } == CERT }
    } catch (e: Throwable) { false }
}
