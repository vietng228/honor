package com.viet.trolyai

import com.anthropic.client.AnthropicClient
import com.anthropic.client.okhttp.AnthropicOkHttpClient
import com.anthropic.models.messages.MessageCreateParams
import com.anthropic.models.messages.OutputConfig
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Bộ não: gọi nhà cung cấp AI đang chọn (Gemini, Groq, Grok, OpenAI, Claude). Gọi từ luồng nền. */
class Brain(val provider: String, private val apiKey: String) {
    private val claude: AnthropicClient? =
        if (provider == "Claude") AnthropicOkHttpClient.builder().apiKey(apiKey).build() else null
    private var history = listOf<Pair<Boolean, String>>() // true = người dùng
    /** Tệp đính kèm của lượt hiện tại (gắn vào tin người dùng cuối cùng). */
    private var attach = listOf<Attach>()

    /** [msgs] là lịch sử đã lưu, tin cuối là câu hỏi của người dùng. */
    fun ask(msgs: List<Msg>): String {
        // Gộp các tin liền nhau cùng vai (vd tin trước gửi lỗi), bắt đầu bằng người dùng
        val merged = mutableListOf<Pair<Boolean, String>>()
        for (m0 in msgs.takeLast(20)) {
            // Tin cũ có đính kèm: chỉ ghi tên tệp để giữ ngữ cảnh, không gửi lại nội dung
            val m = if (m0.files.isEmpty()) m0 else m0.copy(text = (m0.text + " [đính kèm: " +
                m0.files.joinToString { it.name } + "]").trim())
            if (merged.isEmpty() && !m.user) continue
            if (merged.isNotEmpty() && merged.last().first == m.user)
                merged[merged.lastIndex] = m.user to merged.last().second + "\n" + m.text
            else merged += m.user to m.text
        }
        history = merged
        // Đính kèm của lượt hiện tại = tệp của tin người dùng mới nhất (bỏ qua tin dữ liệu hệ thống ở cuối)
        attach = msgs.takeLast(2).lastOrNull { it.user && it.files.isNotEmpty() }?.files ?: emptyList()
        return (if (claude != null) askClaude(claude) else if (provider == "Gemini") askGemini() else askOpenAICompatible())
            .trim().ifEmpty { "Xin lỗi, mình chưa nghĩ ra câu trả lời." }
    }

    private fun askClaude(client: AnthropicClient): String {
        val b = MessageCreateParams.builder()
            .model(CLAUDE_MODEL)
            .maxTokens(2000L)
            .system(system())
            .outputConfig(OutputConfig.builder().effort(OutputConfig.Effort.LOW).build())
        for ((isUser, t) in history) if (isUser) b.addUserMessage(t) else b.addAssistantMessage(t)
        return client.messages().create(b.build()).content()
            .flatMap { it.text().map { t -> listOf(t.text()) }.orElse(emptyList()) }
            .joinToString("")
    }

    /** Quá tải (503) / hết lượt (429) / quá lâu: chuyển sang model dự phòng. */
    private fun firstWorking(models: List<String>, call: (String) -> String): String {
        var last: Exception? = null
        for (m in models) {
            try { return call(m) }
            catch (e: Busy) { last = e }
            catch (e: java.net.SocketTimeoutException) { last = RuntimeException("$provider phản hồi quá lâu, thử lại sau nhé") }
        }
        throw last!!
    }

    private class Busy(msg: String) : RuntimeException(msg)

    /** POST JSON; lỗi 429/503 (hoặc model không tồn tại) ném Busy để thử model khác. */
    private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 10000; conn.readTimeout = if (attach.isEmpty()) 25000 else 120000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val resp = ((if (code in 200..299) conn.inputStream else conn.errorStream) ?: return JSONObject())
            .bufferedReader().use { it.readText() }
        if (code in 200..299) return JSONObject(resp)
        val msg = runCatching { JSONObject(resp).getJSONObject("error").getString("message") }.getOrDefault("HTTP $code")
        // Hết lượt / quá tải / model không có trên tài khoản → thử model kế tiếp
        val noModel = code in 400..404 && msg.contains("model", true)
        throw if (code == 429 || code == 503 || noModel) Busy(msg) else HttpError(code, msg)
    }

    private class HttpError(val code: Int, msg: String) : RuntimeException(msg)

    private fun askGemini() = firstWorking(GEMINI_MODELS) { model ->
        val contents = JSONArray()
        history.forEachIndexed { i, (isUser, t) ->
            val parts = JSONArray()
            // Gắn ảnh/video/file vào tin người dùng cuối cùng
            if (isUser && i == history.lastIndex - (if (history.last().first) 0 else 1)) attach.forEach { parts.put(media(it)) }
            parts.put(JSONObject().put("text", t.ifBlank { "Hãy xem tệp đính kèm." }))
            contents.put(JSONObject().put("role", if (isUser) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            // Suy nghĩ tối thiểu để trả lời nhanh; model không hỗ trợ thì gửi lại không kèm cấu hình
            .put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal")))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val h = mapOf("x-goog-api-key" to apiKey)
        val r = try { post(url, h, body) } catch (e: HttpError) {
            if (e.code != 400) throw e
            body.remove("generationConfig"); post(url, h, body)
        }
        val parts = r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
    }

    /** Tệp ≤ 14 MB gửi thẳng; lớn hơn (video…) tải lên Gemini Files API rồi tham chiếu. */
    private fun media(a: Attach): JSONObject {
        val f = java.io.File(a.path)
        return if (f.length() <= 14L * 1024 * 1024) JSONObject().put("inline_data", JSONObject()
            .put("mime_type", a.mime).put("data", android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP)))
        else JSONObject().put("file_data", JSONObject().put("mime_type", a.mime).put("file_uri", upload(f, a.mime)))
    }

    private val uploaded = mutableMapOf<String, String>()

    private fun upload(f: java.io.File, mime: String): String = uploaded.getOrPut(f.path) {
        val start = URL("https://generativelanguage.googleapis.com/upload/v1beta/files").openConnection() as HttpURLConnection
        start.requestMethod = "POST"; start.doOutput = true
        start.setRequestProperty("x-goog-api-key", apiKey)
        start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
        start.setRequestProperty("X-Goog-Upload-Command", "start")
        start.setRequestProperty("X-Goog-Upload-Header-Content-Length", f.length().toString())
        start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
        start.setRequestProperty("Content-Type", "application/json")
        start.outputStream.use { it.write(JSONObject().put("file", JSONObject().put("display_name", f.name)).toString().toByteArray()) }
        val upUrl = start.getHeaderField("x-goog-upload-url") ?: throw RuntimeException("Không tải được tệp lên (${start.responseCode})")
        val up = URL(upUrl).openConnection() as HttpURLConnection
        up.requestMethod = "POST"; up.doOutput = true; up.setFixedLengthStreamingMode(f.length())
        up.connectTimeout = 15000; up.readTimeout = 120000
        up.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
        up.setRequestProperty("X-Goog-Upload-Offset", "0")
        f.inputStream().use { i -> up.outputStream.use { i.copyTo(it) } }
        val file = JSONObject(up.inputStream.bufferedReader().use { it.readText() }).getJSONObject("file")
        // Video cần xử lý xong (ACTIVE) mới dùng được
        var state = file.optString("state"); var tries = 0
        while (state == "PROCESSING" && tries++ < 60) {
            Thread.sleep(2000)
            val g = URL("https://generativelanguage.googleapis.com/v1beta/${file.getString("name")}").openConnection() as HttpURLConnection
            g.setRequestProperty("x-goog-api-key", apiKey)
            state = JSONObject(g.inputStream.bufferedReader().use { it.readText() }).optString("state")
        }
        if (state == "FAILED") throw RuntimeException("Gemini không xử lý được tệp ${f.name}")
        file.getString("uri")
    }

    /** OpenAI, Grok (xAI), Groq: cùng chuẩn chat/completions, chỉ khác địa chỉ và model. */
    private fun askOpenAICompatible(): String {
        val (base, models) = OPENAI_COMPAT.getValue(provider)
        return firstWorking(models) { model ->
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
            for ((isUser, t) in history) msgs.put(JSONObject().put("role", if (isUser) "user" else "assistant").put("content", t))
            val r = post("$base/chat/completions", mapOf("Authorization" to "Bearer $apiKey"),
                JSONObject().put("model", model).put("messages", msgs))
            r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
        }
    }

    /** Lời dặn + giờ hiện tại (để đặt báo thức đúng) + danh sách lệnh thao tác máy. */
    private fun system() = "Bạn là trợ lý giọng nói thân thiện tên \"${Store.aiName}\", nói tiếng Việt tự nhiên như người thật.\n" +
        Store.voiceStyle.takeIf { it.isNotBlank() }?.let {
            "Hãy trả lời theo phong cách/giọng điệu: $it (áp dụng vào cách dùng từ, cảm xúc; KHÔNG nhắc lại hay đọc ra mô tả phong cách này).\n"
        }.orEmpty() +
        SYSTEM + "\nBây giờ là " +
        java.text.SimpleDateFormat("HH:mm, EEEE dd/MM/yyyy", java.util.Locale("vi", "VN")).format(java.util.Date()) +
        ".\n" + Tools.GUIDE + "\n" + AppLauncher.GUIDE +
        AppLauncher.installedNames.takeIf { it.isNotEmpty() }?.let {
            "\nỨng dụng đang cài trên máy (tham khảo để chọn tên gần nhất khi người dùng nói sai/nghe nhầm, hoặc gọi " +
                "theo loại như \"thời tiết\", \"bản đồ\"). Nhưng dù tên có trong danh sách này hay không, hễ người dùng " +
                "bảo mở app thì vẫn phải thêm [MO_APP: …], không tự từ chối: $it"
        }.orEmpty()

    companion object {
        const val CLAUDE_MODEL = "claude-opus-5-5"
        val GEMINI_MODELS = listOf("gemini-3.1-flash-lite", "gemini-flash-latest", "gemini-flash-lite-latest")
        val OPENAI_COMPAT = mapOf(
            "OpenAI" to ("https://api.openai.com/v1" to listOf("gpt-5-mini", "gpt-4.1-mini", "gpt-4o-mini")),
            "Grok" to ("https://api.x.ai/v1" to listOf("grok-4-fast-non-reasoning", "grok-4-fast", "grok-3-mini")),
            "Groq" to ("https://api.groq.com/openai/v1" to listOf("openai/gpt-oss-120b", "llama-3.3-70b-versatile", "qwen/qwen3-32b")),
        )

        fun detect(key: String) = when {
            key.startsWith("sk-ant-") -> "Claude"
            key.startsWith("xai-") -> "Grok"
            key.startsWith("gsk_") -> "Groq"
            key.startsWith("sk-") -> "OpenAI"
            else -> "Gemini"
        }
        val SYSTEM = """
            Câu trả lời vừa hiện trên màn hình vừa được đọc thành tiếng, nên: trả lời ngắn gọn 1-3 câu,
            không dùng markdown, gạch đầu dòng hay emoji. Số liệu viết bằng chữ số và ký hiệu chuẩn cho dễ nhìn,
            ví dụ 136.200.000 đ, 22,5°C, 75%, 3.735 USD/oz, 06:30, 19/11/2026.
            Người dùng có thể gửi kèm ảnh, video, âm thanh, PDF hay tài liệu: hãy xem kỹ và trả lời theo nội dung đó
            (mô tả, tóm tắt, dịch, giải bài, trích số liệu…); khi phân tích tệp được phép trả lời dài hơn cho đủ ý.
            Luôn viết hoa chữ cái đầu câu; viết đúng chính tả tên riêng, tên ứng dụng và thương hiệu
            (YouTube, TikTok, Facebook, Zalo, ChatGPT, iPhone, Xiaomi…).
            Tuyệt đối không bịa số liệu (giá cả, thời tiết, tỷ số, tin tức…): chỉ dùng số từ thẻ dữ liệu được cung cấp;
            cần thông tin mới thì tự tra bằng thẻ [TIM_WEB: …] rồi trả lời; tra không ra thì nói thật.
            Nếu người dùng muốn nghe chi tiết hơn thì mới trả lời dài.
            Đây là trợ lý CÁ NHÂN: khi chủ cà khịa, trêu hay chửi yêu, bạn được phép đáp trả tương tự cho vui,
            bỗ bã, lầy lội, xưng hô theo chủ (tao/mày nếu chủ dùng); từ tục cứ dùng tự nhiên, hệ thống tự che thành ***.
            Nhưng chỉ cà khịa qua lại cho vui, tuyệt đối không xúc phạm thật sự, không đụng tới người khác hay vấn đề nhạy cảm.
""".trimIndent()
    }
}
