package com.viet.trolyai

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/** Tệp đính kèm đã chép vào bộ nhớ riêng của app (ảnh, video, PDF, âm thanh…). */
data class Attach(val path: String, val mime: String, val name: String) {
    val isImage get() = mime.startsWith("image/")
    val isVideo get() = mime.startsWith("video/")
}

data class Msg(val user: Boolean, val text: String, val time: Long, val files: List<Attach> = emptyList())

/** Trạng thái dùng chung giữa app và bong bóng nổi; lịch sử chat lưu vào máy. */
object Store {
    private lateinit var prefs: SharedPreferences
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val listeners = mutableSetOf<() -> Unit>()

    val messages = mutableListOf<Msg>()
    var brain: Brain? = null; private set
    var busy = false; private set
    /**
     * Cửa sổ đang hiện của Việt Ximi (màn hình chính hoặc bảng Live). Mở app qua cửa sổ này thì hệ thống coi là
     * người dùng mở nên app bật lên ngay, không bị Xiaomi/Honor chặn như khi mở từ nền.
     */
    @Volatile var uiContext: Context? = null

    fun init(ctx: Context) {
        if (::prefs.isInitialized) return
        Guard.enforce(ctx)   // sai chữ ký (APK bị sửa / ký lại) → thoát ngay
        app = ctx.applicationContext
        prefs = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        // Bản cũ chỉ có một key: chuyển sang lưu theo nhà cung cấp
        prefs.getString("key", null)?.let { old ->
            val p = Brain.detect(old)
            prefs.edit().putString("key_$p", old).putString("provider", p).remove("key").apply()
        }
        rebuild()
        kotlin.concurrent.thread { AppLauncher.refreshInstalled(app) }
        runCatching {
            val a = JSONArray(prefs.getString("chat", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                val f = it.optJSONArray("f")
                val files = if (f == null) emptyList() else (0 until f.length()).map { j ->
                    f.getJSONObject(j).let { o -> Attach(o.getString("p"), o.getString("m"), o.getString("n")) } }
                messages += Msg(it.getBoolean("u"), it.getString("t"), it.getLong("ts"), files)
            }
        }
    }

    /** Nhà cung cấp đang dùng. */
    var provider: String
        get() = prefs.getString("provider", "Gemini")!!
        set(v) { prefs.edit().putString("provider", v).apply(); rebuild(); changed() }

    fun keyOf(p: String): String? = prefs.getString("key_$p", null)
    fun setKey(p: String, k: String?) {
        prefs.edit().apply { if (k == null) remove("key_$p") else putString("key_$p", k) }.apply()
        rebuild(); changed()
    }

    private fun rebuild() { brain = keyOf(provider)?.let { Brain(provider, it) } }

    /** Giọng đọc: "ai:<tên>" (Gemini) hoặc "sys:<tên>" (giọng máy). */
    /** Giọng đọc đã chọn, dùng cố định cho mọi câu trả lời: "ai:<tên>" (Gemini) hoặc "sys:<tên>" (giọng máy). */
    var ttsVoice: String
        get() = prefs.getString("voice", "ai:Despina")!!
        set(v) = prefs.edit().putString("voice", v).apply()

    /** Tên trợ lý do người dùng đặt để cá nhân hoá (logo và tên app vẫn là Việt Ximi). */
    var aiName: String
        get() = prefs.getString("ainame", "Việt Ximi")!!.ifBlank { "Việt Ximi" }
        set(v) = prefs.edit().putString("ainame", v.trim().take(24).ifBlank { "Việt Ximi" }).apply()

    /** Phong cách giọng riêng (vd "ấm áp, chậm rãi"); rỗng = đọc giọng nền bình thường. Chỉ dùng cho giọng AI. */
    var voiceStyle: String
        get() = prefs.getString("vstyle", "")!!
        set(v) = prefs.edit().putString("vstyle", v.trim().take(60)).apply()

    var speakReplies: Boolean
        get() = prefs.getBoolean("speak", true)
        set(v) = prefs.edit().putBoolean("speak", v).apply()

    /** Gửi câu hỏi; [done] chạy trên luồng chính khi có kết quả. */
    fun send(text0: String, files: List<Attach> = emptyList(), done: (Result<String>) -> Unit = {}) {
        val text = if (text0.isBlank()) text0 else Pretty.fix(app, text0)
        var b = brain ?: return done(Result.failure(IllegalStateException("Chưa nhập API key")))
        if (files.isNotEmpty() && b.provider != "Gemini") {
            // Ảnh/video/file do Gemini xử lý: dùng key Gemini cho lượt này nếu có
            b = keyOf("Gemini")?.let { Brain("Gemini", it) }
                ?: return done(Result.failure(IllegalStateException("Gửi ảnh, video, file cần key Gemini (nhập trong Cài đặt › API)")))
        }
        messages += Msg(true, text, System.currentTimeMillis(), files)
        busy = true; save(); changed()
        val snapshot = messages.toList()
        thread {
            val raw = runCatching {
                val first = b.ask(snapshot)
                if (!Tools.has(first)) first
                // AI xin số liệu (thời tiết, giá vàng…) → lấy dữ liệu thật rồi hỏi lại để trả lời
                else b.ask(snapshot + Msg(true, "[Dữ liệu hệ thống]\n" + Tools.fetchAll(first) +
                    "\nDựa vào dữ liệu trên, trả lời câu hỏi vừa rồi một cách tự nhiên; không dùng thẻ dữ liệu nữa.",
                    System.currentTimeMillis()))
            }
            main.post {
                // Thẻ [MO_APP: …] → mở ứng dụng, câu trả lời hiển thị/đọc không còn thẻ
                val r = raw.map { Pretty.fix(app, AppLauncher.handle(uiContext ?: app, it)) }
                busy = false
                r.onSuccess { messages += Msg(false, it, System.currentTimeMillis()) }
                save(); changed(); done(r)
            }
        }
    }

    fun clear() {
        messages.flatMap { it.files }.forEach { java.io.File(it.path).delete() }
        messages.clear(); save(); changed()
    }

    /** Chép tệp người dùng chọn vào bộ nhớ riêng của app để lịch sử vẫn xem được sau này. */
    fun importFile(uri: android.net.Uri): Attach? = runCatching {
        val cr = app.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        var name = "tep"
        cr.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        val dir = java.io.File(app.filesDir, "att").apply { mkdirs() }
        val out = java.io.File(dir, "${System.currentTimeMillis()}_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        cr.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        Attach(out.path, mime, name)
    }.getOrNull()

    fun listen(l: () -> Unit) { listeners += l }
    fun unlisten(l: () -> Unit) { listeners -= l }
    private fun changed() = listeners.toList().forEach { it() }

    private fun save() {
        while (messages.size > 300) messages.removeAt(0)
        val a = JSONArray()
        messages.forEach { m ->
            val o = JSONObject().put("u", m.user).put("t", m.text).put("ts", m.time)
            if (m.files.isNotEmpty()) o.put("f", JSONArray().apply {
                m.files.forEach { put(JSONObject().put("p", it.path).put("m", it.mime).put("n", it.name)) } })
            a.put(o)
        }
        prefs.edit().putString("chat", a.toString()).apply()
    }
}
