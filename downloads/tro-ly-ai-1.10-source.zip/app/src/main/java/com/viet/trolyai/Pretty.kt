package com.viet.trolyai

import android.content.Context
import android.content.Intent

/**
 * Trình bày chữ cho chuyên nghiệp: viết hoa chữ cái đầu câu và viết đúng tên ứng dụng
 * (YouTube, TikTok, Zalo, ChatGPT…) theo đúng tên ứng dụng đang cài trên máy.
 */
object Pretty {
    @Volatile private var names: List<Pair<Regex, String>>? = null

    /** Tên app chữ Latin (tên thương hiệu) đang cài; bỏ tên tiếng Việt như "Lịch", "Ảnh" để không sửa nhầm từ thường. */
    private fun names(ctx: Context): List<Pair<Regex, String>> = names ?: run {
        val pm = ctx.packageManager
        val labels = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString().trim() }
            .filter { it.length >= 3 && it.all { c -> c.code < 128 } && it.any { c -> c.isLetter() } }
        val known = listOf("YouTube", "TikTok", "Facebook", "Messenger", "Zalo", "Instagram", "ChatGPT", "Gemini",
            "Google", "Gmail", "Chrome", "Telegram", "Shopee", "Lazada", "Grab", "Netflix", "Spotify", "WhatsApp", "Zing MP3")
        (labels + known).distinctBy { it.lowercase() }.sortedByDescending { it.length }
            .map { Regex("(?<![\\p{L}\\d])" + Regex.escape(it) + "(?![\\p{L}\\d])", RegexOption.IGNORE_CASE) to it }
            .also { names = it }
    }

    fun fix(ctx: Context, text: String): String {
        var s = text.trim()
        for ((re, name) in names(ctx)) s = re.replace(s, name)
        return s.replaceFirstChar { it.uppercase() }
    }
}
