package com.viet.trolyai

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Danh sách tin nhắn dạng bong bóng (nội dung đặc, không phải kính): nhận bên trái nền trung tính,
 * gửi bên phải màu nhấn. Thanh điều khiển kính nổi phía trên/dưới nên có padding để cuộn xuống dưới chúng.
 */
class ChatView(context: Context) : ScrollView(context) {
    companion object { const val RECEIVED = 0x33FFFFFF }

    private val list = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), 0, dp(12), 0)
        // Tương đương role="log": TalkBack đọc tin mới mà không ngắt người dùng
        accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
    }
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val anims = mutableListOf<ObjectAnimator>()

    init {
        isFillViewport = true; clipToPadding = false; isVerticalScrollBarEnabled = false
        addView(list)
    }

    fun render(msgs: List<Msg>, busy: Boolean) {
        anims.forEach { it.cancel() }; anims.clear()
        list.removeAllViews()
        if (msgs.isEmpty()) list.addView(TextView(context).apply {
            text = "Xin chào, mình là ${Store.aiName}.\nNhắn tin hoặc chạm micro để nói chuyện."
            setTextColor(0xD9FFFFFF.toInt()); textSize = 15f; gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, 0x66000000)
            setPadding(0, dp(80), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        val lastSent = msgs.indexOfLast { it.user }
        msgs.forEachIndexed { i, m ->
            if (m.files.isNotEmpty()) list.addView(attachments(m.files, m.user))
            if (m.text.isNotBlank()) list.addView(bubble(m.text, m.user))
            if (i == lastSent) {
                val status = when {
                    i < msgs.lastIndex -> "Đã xem ✓✓"
                    busy -> "Đã xem ✓✓"
                    else -> "Chưa gửi được"
                }
                list.addView(TextView(context).apply {
                    text = "${fmt.format(Date(m.time))} · $status"
                    textSize = 11f; setTextColor(0xCCFFFFFF.toInt()); gravity = Gravity.END
                    setShadowLayer(4f, 0f, 1f, 0x66000000)
                    setPadding(0, dp(2), dp(4), dp(6))
                }, LinearLayout.LayoutParams(-1, -2))
            }
        }
        if (busy) list.addView(typing())
        post { fullScroll(View.FOCUS_DOWN) }
    }

    /** Bong bóng 3 chấm nhún lần lượt (đứng yên nếu bật giảm chuyển động). */
    private fun typing(): View {
        val dots = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bubbleBg(sent = false)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            contentDescription = "${Store.aiName} đang trả lời"
        }
        val still = A11y.reduceMotion(context)
        repeat(3) { i ->
            val dot = View(context).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            }
            dots.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = if (i > 0) dp(5) else 0 })
            if (!still) anims += ObjectAnimator.ofFloat(dot, "translationY", 0f, -dp(6).toFloat(), 0f, 0f).apply {
                duration = 900; startDelay = i * 150L
                repeatCount = ObjectAnimator.INFINITE
                interpolator = AccelerateDecelerateInterpolator()
                start()
            }
        }
        return wrap(dots, sent = false)
    }

    private fun bubble(text: String, sent: Boolean) = wrap(TextView(context).apply {
        this.text = if (sent) text else Censor.mask(text); textSize = 16f; setTextColor(Color.WHITE)
        background = bubbleBg(sent)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setTextIsSelectable(true)
    }, sent)

    private val thumbs = android.util.LruCache<String, android.graphics.Bitmap>(24)

    /** Ảnh thu nhỏ của ảnh/video (đọc một lần rồi nhớ). */
    private fun thumb(a: Attach): android.graphics.Bitmap? = thumbs.get(a.path) ?: runCatching {
        val f = java.io.File(a.path)
        if (a.isImage) {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(a.path, o)
            var s = 1; while (o.outWidth / s > 720 || o.outHeight / s > 720) s *= 2
            android.graphics.BitmapFactory.decodeFile(a.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = s })
        } else if (a.isVideo && android.os.Build.VERSION.SDK_INT >= 29)
            android.media.ThumbnailUtils.createVideoThumbnail(f, android.util.Size(640, 640), null)
        else null
    }.getOrNull()?.also { thumbs.put(a.path, it) }

    /** Ảnh/video hiện dạng thẻ bo góc (video có nút ▶); tệp khác hiện tên trong viên kính. */
    private fun attachments(files: List<Attach>, sent: Boolean): View {
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = if (sent) Gravity.END else Gravity.START }
        for (a in files) {
            val bmp = thumb(a)
            if (bmp != null) {
                val box = FrameLayout(context).apply {
                    background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x33FFFFFF)
                        setStroke(dp(1), 0x59FFFFFF) }
                    clipToOutline = true; contentDescription = a.name
                }
                box.addView(android.widget.ImageView(context).apply {
                    setImageBitmap(bmp); scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                }, FrameLayout.LayoutParams(-1, -1))
                if (a.isVideo) box.addView(TextView(context).apply {
                    text = "▶"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x80000000.toInt()) }
                }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
                val w = dp(220); val h = (w * bmp.height / maxOf(1, bmp.width)).coerceIn(dp(120), dp(300))
                col.addView(box, LinearLayout.LayoutParams(w, h).apply { bottomMargin = dp(4) })
            } else col.addView(TextView(context).apply {
                text = "📄  ${a.name}"; textSize = 14f; setTextColor(Color.WHITE); maxLines = 2
                background = bubbleBg(sent); setPadding(dp(14), dp(10), dp(14), dp(10))
            }, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(4) })
        }
        return wrap(col, sent)
    }

    /** Khung căn trái/phải, giới hạn bề rộng bong bóng ~75% cột. */
    private fun wrap(child: View, sent: Boolean): View {
        val row = object : FrameLayout(context) {
            override fun onMeasure(w: Int, h: Int) {
                if (child is TextView) child.maxWidth = (MeasureSpec.getSize(w) * 0.75f).toInt()
                super.onMeasure(w, h)
            }
        }
        row.setPadding(0, dp(3), 0, dp(3))
        row.addView(child, FrameLayout.LayoutParams(-2, -2, if (sent) Gravity.END else Gravity.START))
        return row
    }

    /** Bo góc rộng, riêng góc dưới phía người nói bo hẹp làm "đuôi". */
    private fun bubbleBg(sent: Boolean) = GradientDrawable().apply {
        // Kính trong viền trắng như giao diện máy; tin gửi là kính xanh
        setColor(if (sent) 0xD93B82F6.toInt() else RECEIVED)
        setStroke(resources.displayMetrics.density.toInt().coerceAtLeast(1), if (sent) 0x66FFFFFF else 0x59FFFFFF)
        val r = dp(18).toFloat(); val t = dp(4).toFloat()
        // thứ tự: trên-trái, trên-phải, dưới-phải, dưới-trái
        cornerRadii = if (sent) floatArrayOf(r, r, r, r, t, t, r, r) else floatArrayOf(r, r, r, r, r, r, t, t)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
