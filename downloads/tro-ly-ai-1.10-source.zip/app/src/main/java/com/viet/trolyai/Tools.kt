package com.viet.trolyai

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.util.Locale

/**
 * Dữ liệu thời gian thực từ nguồn miễn phí (như Việt Ximi). AI chèn thẻ dữ liệu, ví dụ [THOI_TIET: Đà Nẵng];
 * app lấy số liệu rồi hỏi lại AI để trả lời. Gọi từ luồng nền.
 */
object Tools {
    val GUIDE = """
        Để trả lời câu hỏi cần số liệu mới, CHỈ trả về các thẻ dữ liệu cần dùng (không kèm lời), app sẽ gửi lại số liệu:
        [THOI_TIET: tên thành phố] thời tiết hiện tại và 3 ngày tới (không nói thành phố thì dùng Hà Nội)
        [GIA_VANG] giá vàng SJC trong nước và vàng thế giới
        [GIA_VANG_ALL] giá vàng mọi thương hiệu: SJC, PNJ, Bảo Tín, DOJI, nhẫn 24K…
        [GIA_XANG] giá xăng dầu Petrolimex (RON 95, E5, dầu diesel, dầu hoả…)
        [GIA_BAC] giá bạc thế giới
        [GIA_DAU_THO] giá dầu thô Brent và WTI
        [CHI_SO: VNINDEX hoặc VN30 hoặc HNX] chỉ số chứng khoán
        [TY_GIA: mã tiền tệ, vd USD, EUR, JPY, CNY] tỷ giá so với đồng Việt Nam
        [TIEN_SO: mã, vd BTC, ETH] giá tiền mã hoá
        [CHUNG_KHOAN: mã cổ phiếu, vd VNM, FPT] giá cổ phiếu Việt Nam gần nhất
        [TRA_CUU: chủ đề] tra Wikipedia tiếng Việt về người, địa danh, sự kiện, khái niệm
        [TIM_WEB: câu tìm kiếm] tìm trên Internet và đọc nội dung trang: dùng cho tin tức, sự kiện, kết quả thể thao,
          giá cả khác, hướng dẫn, đánh giá sản phẩm… và MỌI câu hỏi cần thông tin mới mà các thẻ trên không có.
        QUY TẮC: khi người dùng hỏi "tìm …", "… là gì", "… thế nào", cần thông tin → LUÔN dùng [TIM_WEB: …] để tự
        trả lời NGAY trong cuộc trò chuyện. TUYỆT ĐỐI không tự mở trình duyệt/Chrome/Google để người dùng tự đọc,
        trừ khi họ nói rõ "mở Google/Chrome/trình duyệt".
    """.trimIndent()

    private val TAG = Regex("""\[(TIM_WEB|THOI_TIET|GIA_VANG_ALL|GIA_VANG|GIA_XANG|GIA_BAC|GIA_DAU_THO|CHI_SO|TY_GIA|TIEN_SO|CHUNG_KHOAN|TRA_CUU)(?::\s*([^\]]*))?]""")
    private val vnd = NumberFormat.getInstance(Locale("vi", "VN"))

    fun has(reply: String) = TAG.containsMatchIn(reply)

    /** Lấy dữ liệu cho mọi thẻ trong câu trả lời; nguồn nào lỗi thì ghi rõ để AI nói thật. */
    fun fetchAll(reply: String) = TAG.findAll(reply).joinToString("\n") { m ->
        val arg = m.groupValues[2].trim()
        runCatching {
            when (m.groupValues[1]) {
                "THOI_TIET" -> weather(arg.ifEmpty { "Hà Nội" })
                "TIM_WEB" -> web(arg)
                "GIA_VANG" -> gold()
                "GIA_VANG_ALL" -> goldAll()
                "GIA_XANG" -> fuel()
                "GIA_BAC" -> commodity("Bạc thế giới", "SI=F", "USD/oz")
                "GIA_DAU_THO" -> commodity("Dầu Brent", "BZ=F", "USD/thùng") + "; " + commodity("Dầu WTI", "CL=F", "USD/thùng")
                "CHI_SO" -> index(arg)
                "TY_GIA" -> rate(arg.ifEmpty { "USD" })
                "TIEN_SO" -> crypto(arg.ifEmpty { "BTC" })
                "CHUNG_KHOAN" -> stock(arg)
                else -> wiki(arg)
            }
        }.getOrElse { "${m.groupValues[1]} $arg: không lấy được dữ liệu (${it.message})" }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) HaMi")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun wmo(code: Int) = when (code) {
        0 -> "trời quang"; 1, 2 -> "ít mây"; 3 -> "nhiều mây"; 45, 48 -> "sương mù"
        in 51..57 -> "mưa phùn"; in 61..65, in 80..82 -> "có mưa"; 66, 67 -> "mưa lạnh"
        in 71..77, 85, 86 -> "tuyết"; in 95..99 -> "dông"; else -> "không rõ"
    }

    private fun weather(city: String): String {
        val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=vi&name=" + Uri.encode(city)))
            .getJSONArray("results").getJSONObject(0)
        val f = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}" +
            "&longitude=${g.getDouble("longitude")}&timezone=auto&forecast_days=3" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code"))
        val c = f.getJSONObject("current"); val d = f.getJSONObject("daily")
        val days = (0 until 3).joinToString("; ") { i ->
            "${d.getJSONArray("time").getString(i)}: ${wmo(d.getJSONArray("weather_code").getInt(i))}, " +
                "${d.getJSONArray("temperature_2m_min").getDouble(i)}–${d.getJSONArray("temperature_2m_max").getDouble(i)}°C, " +
                "khả năng mưa ${d.getJSONArray("precipitation_probability_max").optInt(i)}%"
        }
        return "Thời tiết ${g.getString("name")}: hiện ${c.getDouble("temperature_2m")}°C (cảm giác ${c.getDouble("apparent_temperature")}°C), " +
            "${wmo(c.getInt("weather_code"))}, độ ẩm ${c.getInt("relative_humidity_2m")}%, gió ${c.getDouble("wind_speed_10m")} km/h. Dự báo: $days"
    }

    private fun gold(): String {
        val s = JSONObject(get("https://giavang.now/api/prices?type=SJL1L10"))
        val sjc = "Vàng miếng SJC (${s.optString("time")} ${s.optString("date")}): mua ${vnd.format(s.getLong("buy"))} đ, " +
            "bán ${vnd.format(s.getLong("sell"))} đ mỗi lượng (thay đổi ${vnd.format(s.optLong("change_sell"))} đ)"
        val world = runCatching {
            val p = yahoo("GC=F"); "Vàng thế giới: ${"%.1f".format(p)} USD/ounce"
        }.getOrDefault("")
        return "$sjc. $world"
    }

    private fun yahoo(symbol: String) = JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/$symbol?range=1d&interval=1d"))
        .getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta").getDouble("regularMarketPrice")

    private fun rate(code: String): String {
        val c = code.uppercase().filter { it.isLetter() }.take(3)
        val r = JSONObject(get("https://open.er-api.com/v6/latest/$c")).getJSONObject("rates").getDouble("VND")
        return "Tỷ giá: 1 $c = ${vnd.format(r.toLong())} đồng (tham khảo thị trường)"
    }

    private fun crypto(code: String): String {
        val c = code.uppercase().filter { it.isLetterOrDigit() }
        return "Giá $c: ${"%,.2f".format(yahoo("$c-USD"))} USD"
    }

    private fun stock(code: String): String {
        val c = code.uppercase().filter { it.isLetterOrDigit() }
        val now = System.currentTimeMillis() / 1000
        val j = JSONObject(get("https://dchart-api.vndirect.com.vn/dchart/history?resolution=D&symbol=$c&from=${now - 14 * 86400}&to=$now"))
        val close = j.getJSONArray("c"); val n = close.length()
        val last = close.getDouble(n - 1); val prev = if (n > 1) close.getDouble(n - 2) else last
        return "Cổ phiếu $c: giá đóng cửa gần nhất ${vnd.format((last * 1000).toLong())} đ, " +
            "phiên trước ${vnd.format((prev * 1000).toLong())} đ (${"%+.2f".format((last - prev) / prev * 100)}%)"
    }

    private fun goldAll(): String {
        val j = JSONObject(get("https://giavang.now/api/prices"))
        val p = j.getJSONObject("prices")
        val rows = p.keys().asSequence().map { k ->
            val o = p.getJSONObject(k)
            val cur = o.optString("currency")
            if (cur == "USD") "${o.getString("name")}: ${o.getDouble("buy")} USD/oz"
            else "${o.getString("name")}: mua ${vnd.format(o.getLong("buy"))} đ, bán ${vnd.format(o.optLong("sell"))} đ"
        }.joinToString("; ")
        return "Giá vàng các thương hiệu (${j.optString("time")} ${j.optString("date")}, đơn vị theo nguồn, thường là đ/lượng): $rows"
    }

    private fun fuel(): String {
        val req = JSONObject("""{"FilterBy":{"And":[{"SystemID":{"Equals":"6783dc1271ff449e95b74a9520964169"}},{"RepositoryID":{"Equals":"a95451e23b474fe5886bfb7cf843f53c"}},{"RepositoryEntityID":{"Equals":"3801378fe1e045b1afa10de7c5776124"}},{"Status":{"Equals":"Published"}}]},"SortBy":{"LastModified":"Descending"},"Pagination":{"TotalRecords":-1,"TotalPages":0,"PageSize":0,"PageNumber":0}}""")
        val b64 = android.util.Base64.encodeToString(req.toString().toByteArray(), android.util.Base64.NO_WRAP)
        val objs = JSONObject(get("https://portals.petrolimex.com.vn/~apis/portals/cms.item/search?x-request=" + Uri.encode(b64)))
            .getJSONArray("Objects")
        var updated = ""
        val rows = (0 until objs.length()).map { i ->
            val o = objs.getJSONObject(i)
            if (updated.isEmpty()) updated = o.optString("LastModified").take(10)
            "${o.getString("Title")}: vùng 1 ${vnd.format(o.getLong("Zone1Price"))} đ, vùng 2 ${vnd.format(o.getLong("Zone2Price"))} đ"
        }
        return "Giá bán lẻ xăng dầu Petrolimex (đ/lít hoặc đ/kg, cập nhật $updated): ${rows.joinToString("; ")}"
    }

    private fun commodity(name: String, symbol: String, unit: String) = "$name: ${"%,.2f".format(yahoo(symbol))} $unit"

    private fun index(code: String): String {
        val c = code.uppercase().filter { it.isLetterOrDigit() }.ifEmpty { "VNINDEX" }
        val now = System.currentTimeMillis() / 1000
        val j = JSONObject(get("https://dchart-api.vndirect.com.vn/dchart/history?resolution=D&symbol=$c&from=${now - 14 * 86400}&to=$now"))
        val close = j.getJSONArray("c"); val n = close.length()
        val last = close.getDouble(n - 1); val prev = if (n > 1) close.getDouble(n - 2) else last
        return "Chỉ số $c: ${"%,.2f".format(last)} điểm (${"%+.2f".format(last - prev)} điểm, ${"%+.2f".format((last - prev) / prev * 100)}%)"
    }

    /** Tìm DuckDuckGo, lấy tiêu đề + đoạn trích + nội dung 2 trang đầu để AI tự tổng hợp câu trả lời. */
    private fun web(q: String): String {
        val html = get("https://html.duckduckgo.com/html/?kl=vn-vi&q=" + Uri.encode(q))
        val links = Regex("""class="result__a"[^>]*href="[^"]*uddg=([^&"]+)[^"]*"[^>]*>(.*?)</a>""").findAll(html)
            .map { java.net.URLDecoder.decode(it.groupValues[1], "UTF-8") to strip(it.groupValues[2]) }
            .filter { !it.first.contains("duckduckgo.com") }.take(5).toList()
        val snippets = Regex("""class="result__snippet"[^>]*>(.*?)</a>""").findAll(html).map { strip(it.groupValues[1]) }.toList()
        if (links.isEmpty()) return "Tìm \"$q\": không có kết quả."
        val list = links.mapIndexed { i, (u, t) -> "${i + 1}) $t – ${snippets.getOrElse(i) { "" }} ($u)" }.joinToString("\n")
        val pages = links.filter { !it.first.contains("youtube.com") }.take(2).mapNotNull { (u, t) ->
            runCatching { "Nội dung trang \"$t\" ($u): " + strip(get(u)).take(2500) }.getOrNull()
        }.joinToString("\n")
        return "Kết quả tìm \"$q\":\n$list\n$pages"
    }

    /** Bỏ thẻ HTML, script/style, gom khoảng trắng. */
    private fun strip(h: String) = h.replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("<[^>]+>"), " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'")
        .replace("&nbsp;", " ").replace(Regex("&#?\\w+;"), " ").replace(Regex("\\s+"), " ").trim()

    private fun wiki(topic: String): String {
        val s = JSONObject(get("https://vi.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=" + Uri.encode(topic)))
            .getJSONObject("query").getJSONArray("search").getJSONObject(0).getString("title")
        val p = JSONObject(get("https://vi.wikipedia.org/api/rest_v1/page/summary/" + Uri.encode(s.replace(' ', '_'))))
        return "Wikipedia – $s: ${p.optString("extract").take(1200)}"
    }
}
