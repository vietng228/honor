package com.viet.trolyai

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.sqrt

/**
 * Nhận giọng trực tiếp cho máy không có bộ nhận giọng dùng được (vd Honor không có Google):
 * truyền âm thanh micro liên tục tới Gemini Live API, chữ về ngay khi nói, tự kết thúc khi ngừng nói.
 */
class CloudEar {
    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    @Volatile private var session: Session? = null

    fun start(key: String, onPartial: (String) -> Unit, onLevel: (Float) -> Unit, onDone: (String?) -> Unit) {
        session?.stop()
        session = Session(key, onPartial, onLevel, onDone).also { it.run() }
    }

    fun cancel() { session?.stop(); session = null }

    private inner class Session(val key: String, val onPartial: (String) -> Unit,
                                val onLevel: (Float) -> Unit, val onDone: (String?) -> Unit) {
        private val finished = AtomicBoolean(false)
        @Volatile private var recording = true
        private val text = StringBuilder()
        private var ws: WebSocket? = null

        fun stop() { finished.set(true); recording = false; ws?.cancel() }

        private fun finish(result: String?) {
            if (!finished.compareAndSet(false, true)) return
            recording = false
            ws?.close(1000, null)
            onDone(result?.trim()?.takeIf { it.isNotEmpty() })
        }

        fun run() {
            val req = Request.Builder().url("wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key").build()
            ws = http.newWebSocket(req, object : WebSocketListener() {
                override fun onOpen(w: WebSocket, r: Response) {
                    w.send(JSONObject().put("setup", JSONObject()
                        .put("model", "models/gemini-3.1-flash-live-preview")
                        // Khoá tiếng Việt để không nhận nhầm thành tiếng Hàn/Nhật/Trung
                        .put("generationConfig", JSONObject().put("responseModalities", org.json.JSONArray().put("AUDIO"))
                            .put("speechConfig", JSONObject().put("languageCode", "vi-VN")))
                        .put("inputAudioTranscription", JSONObject())).toString())
                    thread { record(w) }
                }
                override fun onMessage(w: WebSocket, msg: String) {
                    val sc = runCatching { JSONObject(msg).optJSONObject("serverContent") }.getOrNull() ?: return
                    sc.optJSONObject("inputTranscription")?.optString("text")?.let {
                        text.append(it); onPartial(text.toString().trim())
                    }
                    // Gemini bắt đầu trả lời = người dùng đã nói xong → lấy chữ, bỏ phần trả lời của Live
                    if (text.isNotBlank() && (sc.has("modelTurn") || sc.optBoolean("turnComplete"))) finish(text.toString())
                }
                override fun onMessage(w: WebSocket, bytes: okio.ByteString) = onMessage(w, bytes.utf8())
                override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                    Log.w("HaMi", "Live API lỗi: ${t.message} ${r?.code}"); finish(text.toString())
                }
                override fun onClosed(w: WebSocket, code: Int, reason: String) { finish(text.toString()) }
            })
        }

        /** Gửi micro 16 kHz theo từng đoạn 100 ms; tự dừng nếu không ai nói hoặc im lặng lâu. */
        @SuppressLint("MissingPermission")
        private fun record(w: WebSocket) {
            val rate = 16000
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = runCatching {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
            }.getOrElse { finish(null); return }
            val buf = ShortArray(1600) // 100 ms
            val bytes = ByteBuffer.allocate(3200).order(ByteOrder.LITTLE_ENDIAN)
            var floor = 0.0; var chunks = 0; var started = false; var silentMs = 0; var totalMs = 0
            try {
                rec.startRecording()
                while (recording) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) break
                    bytes.clear(); var sum = 0.0
                    for (i in 0 until n) { bytes.putShort(buf[i]); sum += buf[i].toDouble() * buf[i] }
                    w.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                        .put("data", Base64.encodeToString(bytes.array(), 0, n * 2, Base64.NO_WRAP))
                        .put("mimeType", "audio/pcm;rate=16000"))).toString())
                    val rms = sqrt(sum / n); totalMs += 100; chunks++
                    onLevel((kotlin.math.ln(1 + rms) / kotlin.math.ln(1 + 6000.0)).toFloat())
                    if (chunks <= 3) { floor += rms / 3; continue }
                    if (rms > maxOf(floor * 3, 400.0)) { started = true; silentMs = 0 } else if (started) silentMs += 100
                    if (!started && totalMs > 7000) { finish(null); break }        // không ai nói
                    if (started && silentMs >= 1500 || totalMs > 20000) break      // nói xong / quá dài
                }
            } finally { runCatching { rec.stop() }; rec.release() }
            if (!finished.get()) {
                // Báo hết âm thanh để Gemini chốt chữ; chờ tối đa 4 s
                w.send(JSONObject().put("realtimeInput", JSONObject().put("audioStreamEnd", true)).toString())
                Thread.sleep(4000); finish(text.toString())
            }
        }
    }
}
