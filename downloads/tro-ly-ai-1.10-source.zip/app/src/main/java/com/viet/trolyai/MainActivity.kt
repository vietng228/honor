package com.viet.trolyai

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity(), Voice.Callback {
    private lateinit var chat: ChatView
    private lateinit var subtitle: TextView
    private lateinit var titleView: TextView
    private lateinit var input: EditText
    private lateinit var action: GlassView      // nút micro / gửi / dừng
    private lateinit var actionIcon: ImageView
    private lateinit var halo: View
    private lateinit var chip: GlassView        // thông báo lỗi
    private lateinit var chipText: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var bottomWrap: LinearLayout
    private lateinit var chipsRow: LinearLayout
    /** Ảnh/video/tệp đã chọn, chờ gửi cùng tin nhắn. */
    private val pending = mutableListOf<Attach>()
    private lateinit var voice: Voice
    private val glassViews = mutableListOf<GlassView>()
    private var haloAnim: ObjectAnimator? = null

    private val onStore = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        buildUi()
        // Nền = hình nền điện thoại được làm mờ (đồng bộ giao diện kính của máy)
        if (Build.VERSION.SDK_INT >= 31 && !A11y.reduceTransparency(this)) window.setBackgroundBlurRadius(dp(40))
        voice = Voice(this, this)
        Store.listen(onStore)
        refresh()
        if (Store.brain == null) askKey()
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.READ_CONTACTS
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        handleAssist(intent)
    }

    override fun onPause() { super.onPause(); if (Store.uiContext === this) Store.uiContext = null }

    override fun onResume() {
        super.onResume()
        Store.uiContext = this
        refresh()
    }

    // ---------- Giao diện ----------

    private fun buildUi() {
        chat = ChatView(this)

        // Thanh trên: kính dạng viên thuốc nổi trên nội dung
        val avatar = ImageView(this).apply {
            setImageResource(R.drawable.app_icon); clipToOutline = true
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        titleView = TextView(this).apply {
            text = Store.aiName; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        subtitle = TextView(this).apply { textSize = 12f; setTextColor(0xD9FFFFFF.toInt()) }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(titleView); addView(subtitle)
        }
        val settingsBtn = iconButton(R.drawable.ic_tune, "Cài đặt", 40) { openSettings() }
        val top = glass().apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(avatar, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
                addView(settingsBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
            })
        }

        // Thanh dưới: ô nhập dạng viên thuốc + nút hành động tròn (micro ⇄ gửi)
        input = EditText(this).apply {
            hint = "Nhắn cho ${Store.aiName}…"; setHintTextColor(0xB3FFFFFF.toInt()); setTextColor(Color.WHITE)
            textSize = 16f; maxLines = 5; background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = updateAction()
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val inputPill = glass(radiusDp = 26f).apply { addView(input) }
        halo = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x55EF4444) }
            visibility = View.INVISIBLE
        }
        actionIcon = ImageView(this).apply { imageTintList = ColorStateList.valueOf(Color.WHITE) }
        action = glass().apply {
            isFocusable = true; isClickable = true
            addView(actionIcon, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            setOnClickListener { onAction() }
        }
        val actionBox = FrameLayout(this).apply {
            clipChildren = false
            addView(halo, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            addView(action, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        }
        val attachBtn = glass().apply {
            contentDescription = "Đính kèm ảnh, video, tệp"; isFocusable = true; isClickable = true
            glass.fillColor = GLASS_BAR
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_attach); imageTintList = ColorStateList.valueOf(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            setOnClickListener { pickAttach() }
        }
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM; clipChildren = false
            addView(attachBtn, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(8) })
            addView(inputPill, LinearLayout.LayoutParams(0, -2, 1f))
            addView(actionBox, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(8) })
        }

        chipsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipsScroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; visibility = View.GONE; addView(chipsRow)
        }
        bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; clipChildren = false
            addView(chipsScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            addView(bottomBar, LinearLayout.LayoutParams(-1, -2))
        }

        chipText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; maxLines = 2
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        chip = glass().apply { addView(chipText); visibility = View.GONE }

        val root = FrameLayout(this).apply {
            // Lớp tối nhẹ trên hình nền mờ để chữ trắng luôn rõ (tương phản cao: gần đặc)
            setBackgroundColor(if (A11y.reduceTransparency(context)) 0xF0111318.toInt() else 0x59000000)
            fitsSystemWindows = true; clipChildren = false
            addView(chat, FrameLayout.LayoutParams(-1, -1))
            addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(dp(12), dp(8), dp(12), 0) })
            addView(chip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(76) })
            addView(bottomWrap, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
        }
        setContentView(root)

        // Nội dung cuộn được xuống dưới lớp kính; kính làm mờ lại khi nội dung đổi
        val pad = { chat.setPadding(0, top.height + dp(16), 0, bottomWrap.height + dp(20)) }
        top.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> pad() }
        bottomWrap.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> pad() }
        chat.viewTreeObserver.addOnScrollChangedListener { glassViews.forEach { it.invalidate() } }
        chat.viewTreeObserver.addOnGlobalLayoutListener { glassViews.forEach { it.invalidate() } }
        updateAction()
    }

    private fun glass(radiusDp: Float = -1f) = GlassView(this, radiusDp).also { it.source = chat; glassViews += it }

    // Nút nằm trong thanh kính: không làm mờ lần nữa (tránh kính lồng kính)
    private fun iconButton(icon: Int, desc: String, sizeDp: Int, onClick: () -> Unit) = GlassView(this).apply {
        contentDescription = desc; isFocusable = true; isClickable = true
        addView(ImageView(context).apply {
            setImageResource(icon); imageTintList = ColorStateList.valueOf(Color.WHITE)
        }, FrameLayout.LayoutParams(dp(sizeDp / 2), dp(sizeDp / 2), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    private fun refresh() {
        chat.render(Store.messages, Store.busy)
        subtitle.text = when {
            voice.listening -> "Đang nghe…"
            Store.busy -> "Đang trả lời…"
            Store.brain == null -> "Chưa có API key"
            else -> "${Store.brain!!.provider} · Sẵn sàng"
        }
    }

    /** Nút hành động: đang nghe → Dừng; có chữ → Gửi; còn lại → Micro. */
    private fun updateAction() {
        val stop = this::voice.isInitialized && (voice.listening || voice.speaking)
        val send = !stop && (input.text.isNotBlank() || pending.isNotEmpty())
        actionIcon.setImageResource(if (stop) R.drawable.ic_stop else if (send) R.drawable.ic_send else R.drawable.ic_mic)
        action.contentDescription = if (stop) "Dừng" else if (send) "Gửi" else "Nói chuyện bằng giọng"
        action.glass.fillColor = when {
            stop -> 0xFFEF4444.toInt()
            send -> ACCENT
            else -> GLASS_BAR
        }
        action.invalidate()
        haloAnim?.cancel(); haloAnim = null
        halo.visibility = if (stop && voice.listening) View.VISIBLE else View.INVISIBLE
        if (halo.visibility == View.VISIBLE && !A11y.reduceMotion(this)) {
            haloAnim = ObjectAnimator.ofPropertyValuesHolder(halo,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.5f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.5f),
                PropertyValuesHolder.ofFloat("alpha", 1f, 0f)).apply {
                duration = 1100; repeatCount = ObjectAnimator.INFINITE; start()
            }
        }
    }

    private fun onAction() {
        when {
            voice.listening || voice.speaking -> stopVoice()
            input.text.isNotBlank() || pending.isNotEmpty() -> sendTyped()
            else -> listen()
        }
    }

    // ---------- Hội thoại ----------

    /** Gửi nội dung ô nhập (gõ tay hoặc vừa nói); bật "Đọc to" thì đọc câu trả lời. */
    private fun sendTyped() {
        val text = input.text.toString().trim()
        if ((text.isEmpty() && pending.isEmpty()) || Store.busy) return
        input.setText("")
        val files = pending.toList(); pending.clear(); renderChips()
        Store.send(text, files) { r ->
            r.onSuccess { if (Store.speakReplies) speakReply(it) }
            r.onFailure { showError(it) }
            updateAction()
        }
    }

    private fun speakReply(text: String) {
        val ai = Store.ttsVoice.startsWith("ai:") && Store.keyOf("Gemini") != null
        if (!ai) voice.ttsProblem?.let { showError(Exception(it)); return }
        voice.holdFocus(true)
        voice.speak(text); updateAction()
    }

    /** Micro: nghe một câu, chữ hiện ngay trong ô nhập, nói xong tự ngắt và gửi. */
    private fun listen() {
        if (Store.brain == null) { askKey(); return }
        voice.stopSpeaking()
        input.setText(""); input.hint = "Đang nghe…"
        voice.holdFocus(true)
        voice.listen()
        refresh(); updateAction()
    }

    override fun onStatus(text: String) { input.setText(""); input.hint = text }

    override fun onPartial(text: String) { input.setText(Pretty.fix(this, text)); input.setSelection(input.text.length) }

    override fun onHeard(text: String?) {
        input.hint = "Nhắn cho ${Store.aiName}…"
        if (text != null) { input.setText(text); sendTyped() } else voice.holdFocus(false)
        refresh(); updateAction()
    }

    override fun onSpeakDone() { voice.holdFocus(false); updateAction() }

    private fun stopVoice() {
        voice.stopListening(); voice.stopSpeaking(); voice.holdFocus(false)
        input.hint = "Nhắn cho ${Store.aiName}…"
        refresh(); updateAction()
    }

    private fun showError(e: Throwable) {
        chipText.text = "Lỗi: ${e.message}"; chip.visibility = View.VISIBLE
        chip.postDelayed({ if (!voice.listening) chip.visibility = View.GONE }, 6000)
    }

    // ---------- Đính kèm ----------

    /** Chọn nguồn: thư viện ảnh/video hoặc tệp bất kỳ (PDF, Word, âm thanh…). */
    private fun pickAttach() {
        val d = Dialog(this)
        val dens = resources.displayMetrics.density
        fun option(label: String, sub: String, onClick: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = GlassDrawable(dens, 0x26FFFFFF, 18f)
            isClickable = true; isFocusable = true; setPadding(dp(18), dp(12), dp(18), dp(12))
            addView(TextView(context).apply { text = label; textSize = 16f; setTextColor(Color.WHITE) })
            addView(TextView(context).apply { text = sub; textSize = 12f; setTextColor(0xCCFFFFFF.toInt()) })
            setOnClickListener { d.dismiss(); onClick() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GlassDrawable(dens, if (A11y.reduceTransparency(context)) 0xF21E222B.toInt() else GLASS_SMOKE, 28f)
            setPadding(dp(16), dp(16), dp(16), dp(8))
            addView(option("Ảnh / Video", "Chọn từ thư viện của máy") {
                val i = if (Build.VERSION.SDK_INT >= 33) Intent(android.provider.MediaStore.ACTION_PICK_IMAGES)
                    .putExtra(android.provider.MediaStore.EXTRA_PICK_IMAGES_MAX, 5)
                else Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*")).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                runCatching { startActivityForResult(i, PICK) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            addView(option("Tệp", "PDF, Word, Excel, âm thanh, văn bản…") {
                runCatching {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), PICK)
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        d.setContentView(card)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM); decorView.setPadding(dp(12), 0, dp(12), dp(90))
            blurBehind(this)
        }
        d.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<android.net.Uri>()
        val clip = data.clipData
        if (clip != null) for (i in 0 until clip.itemCount) uris += clip.getItemAt(i).uri
        else data.data?.let { uris += it }
        kotlin.concurrent.thread {
            val got = uris.take(5).mapNotNull { Store.importFile(it) }
            runOnUiThread { pending += got; renderChips(); updateAction() }
        }
    }

    /** Tệp đang chờ gửi: viên kính nhỏ có tên + nút ✕. */
    private fun renderChips() {
        chipsRow.removeAllViews()
        (chipsRow.parent as View).visibility = if (pending.isEmpty()) View.GONE else View.VISIBLE
        for (a in pending.toList()) chipsRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GlassDrawable(resources.displayMetrics.density, GLASS_BAR)
            setPadding(dp(14), dp(8), dp(8), dp(8))
            addView(TextView(context).apply {
                text = (if (a.isImage) "🖼  " else if (a.isVideo) "🎬  " else "📄  ") + a.name
                textSize = 13f; setTextColor(Color.WHITE); maxWidth = dp(180); isSingleLine = true
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_close); imageTintList = ColorStateList.valueOf(Color.WHITE)
                setPadding(dp(4), dp(4), dp(4), dp(4)); contentDescription = "Bỏ ${a.name}"
                setOnClickListener { pending.remove(a); java.io.File(a.path).delete(); renderChips(); updateAction() }
            }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(4) })
        }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
    }


    // ---------- Cài đặt ----------

    private fun openSettings() {
        val d = Dialog(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(24))
            background = GlassDrawable(resources.displayMetrics.density,
                if (A11y.reduceTransparency(context)) 0xF21E222B.toInt() else GLASS_SMOKE, 28f)
        }
        content.addView(View(this).apply {
            background = GradientDrawable().apply { setColor(0x80FFFFFF.toInt()); cornerRadius = dp(3).toFloat() }
        }, LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })
        content.addView(TextView(this).apply {
            text = "Cài đặt"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })

        section(content, "TRÍ TUỆ NHÂN TẠO")
        val k = Store.brain?.let { Store.keyOf(it.provider) }
        row(content, "API", if (k == null) "Chưa nhập" else "${Store.provider} · ${k.take(6)}••••${k.takeLast(4)}", null) {
            d.dismiss(); askKey()
        }

        row(content, "Đặt làm trợ lý mặc định",
            "Thay Google/Gemini: chọn Việt Ximi ở mục Ứng dụng trợ lý kỹ thuật số", null) {
            d.dismiss()
            runCatching { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                .recoverCatching { startActivity(Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS")) }
                .recoverCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        section(content, "CÁ NHÂN HOÁ")
        row(content, "Tên trợ lý", "${Store.aiName} · đặt tên riêng để gọi", null) { d.dismiss(); askName() }
        row(content, "Phong cách trả lời", Store.voiceStyle.ifBlank { "Mặc định · mô tả để cá nhân hoá cách nói" }, null) {
            d.dismiss(); askVoiceStyle()
        }

        section(content, "GIỌNG NÓI")
        row(content, "Giọng đọc", voiceLabel(Store.ttsVoice), null) { d.dismiss(); pickVoice() }
        val speak = Switch(this).apply { isChecked = Store.speakReplies }
        row(content, "Đọc to câu trả lời", "Đọc mọi câu trả lời bằng giọng đã chọn", speak) { speak.toggle() }
        speak.setOnCheckedChangeListener { _, v -> Store.speakReplies = v }


        section(content, "DỮ LIỆU")
        row(content, "Xoá lịch sử trò chuyện", "${Store.messages.size} tin nhắn đã lưu trên máy", null, danger = true) {
            AlertDialog.Builder(this).setTitle("Xoá toàn bộ lịch sử?")
                .setMessage("Không thể khôi phục sau khi xoá.")
                .setPositiveButton("Xoá") { _, _ -> Store.clear(); d.dismiss() }
                .setNegativeButton("Huỷ", null).show()
        }
        content.addView(TextView(this).apply {
            text = "Việt Ximi 1.4"; textSize = 12f; setTextColor(0x99FFFFFF.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })

        d.setContentView(android.widget.ScrollView(this).apply { addView(content) })
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            decorView.setPadding(dp(10), 0, dp(10), dp(10))
            blurBehind(this)
        }
        d.show()
    }

    private fun section(parent: LinearLayout, name: String) = parent.addView(TextView(this).apply {
        text = name; textSize = 12f; setTextColor(0xB3FFFFFF.toInt()); letterSpacing = 0.08f
        setPadding(dp(4), dp(20), 0, dp(8))
    })

    private fun row(parent: LinearLayout, title: String, sub: String, end: View?, danger: Boolean = false,
                    onLong: (() -> Unit)? = null, onClick: () -> Unit) {
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = title; textSize = 16f; setTextColor(if (danger) 0xFFF87171.toInt() else Color.WHITE)
            })
            addView(TextView(context).apply { text = sub; textSize = 13f; setTextColor(0xB3FFFFFF.toInt()) })
        }
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(64); setPadding(dp(16), dp(10), dp(12), dp(10))
            background = GlassDrawable(resources.displayMetrics.density, 0x1AFFFFFF, 18f)
            isClickable = true; isFocusable = true
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            end?.let { addView(it) }
            setOnClickListener { onClick() }
            onLong?.let { l -> setOnLongClickListener { l(); true } }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    /** Cửa sổ hộp thoại kính: làm mờ màn hình phía sau (Android 12+), giảm tối nhẹ. */
    private fun blurBehind(w: android.view.Window) {
        w.setDimAmount(0.2f)
        if (Build.VERSION.SDK_INT >= 31 && !A11y.reduceTransparency(this)) {
            w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            w.attributes = w.attributes.apply { blurBehindRadius = dp(28) }
        }
    }

    private fun voiceLabel(id: String): String {
        AiVoice.VOICES.firstOrNull { "ai:${it.first}" == id }?.let { return "${it.second} · ${it.third} · giọng AI" }
        val i = voice.systemVoices().indexOf(id.removePrefix("sys:"))
        return if (i >= 0) "Giọng máy ${i + 1}" else "Giọng máy mặc định"
    }

    /** Bảng chọn giọng dạng kính: chạm để chọn và nghe thử ngay. */
    private fun pickVoice() {
        val dens = resources.displayMetrics.density
        val hasGemini = Store.keyOf("Gemini") != null
        val items = mutableListOf<Pair<String, Pair<String, String>>>()
        if (hasGemini) AiVoice.VOICES.forEach { items += "ai:${it.first}" to (it.second to it.third) }
        voice.systemVoices().forEachIndexed { i, n -> items += "sys:$n" to ("Giọng máy ${i + 1}" to "Có sẵn trên máy · không cần mạng") }
        if (items.isEmpty()) items += "sys:" to ("Giọng máy mặc định" to "Có sẵn trên máy")

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = mutableListOf<Pair<String, GlassDrawable>>()
        fun mark() = rows.forEach { (id, g) -> g.fillColor = if (id == Store.ttsVoice) ACCENT else 0x26FFFFFF; g.invalidateSelf() }
        list.addView(TextView(this).apply {
            text = "Giọng đọc"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), 0, 0, dp(4))
        })
        list.addView(TextView(this).apply {
            text = if (hasGemini) "Chạm để nghe thử. Giọng đã chọn được dùng cố định cho mọi câu trả lời."
                   else "Nhập key Gemini để dùng thêm giọng AI tự nhiên."
            textSize = 13f; setTextColor(0xCCFFFFFF.toInt()); setPadding(dp(6), 0, 0, dp(12))
        })
        for ((id, label) in items) {
            val g = GlassDrawable(dens, 0x26FFFFFF)
            rows += id to g
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = g
                isClickable = true; isFocusable = true
                setPadding(dp(20), dp(10), dp(20), dp(10))
                addView(TextView(context).apply { text = label.first; textSize = 16f; setTextColor(Color.WHITE) })
                addView(TextView(context).apply { text = label.second; textSize = 12f; setTextColor(0xFFD5DAE2.toInt()) })
                contentDescription = "${label.first}, ${label.second}"
                setOnClickListener {
                    Store.ttsVoice = id; mark()
                    voice.speak("Xin chào, mình là ${Store.aiName}. Rất vui được trò chuyện với bạn.", id)
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        mark()
        val card = android.widget.ScrollView(this).apply {
            background = GlassDrawable(dens, if (A11y.reduceTransparency(context)) 0xF21E222B.toInt() else GLASS_SMOKE, 28f)
            setPadding(dp(16), dp(20), dp(16), dp(12)); clipToPadding = false
            addView(list)
        }
        val d = Dialog(this)
        d.setContentView(card)
        d.setOnDismissListener { voice.stopSpeaking(); updateAction() }
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.7f).toInt())
            decorView.setPadding(dp(20), 0, dp(20), 0)
            setDimAmount(0.25f)
            if (Build.VERSION.SDK_INT >= 31 && !A11y.reduceTransparency(context)) {
                addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                attributes = attributes.apply { blurBehindRadius = dp(24) }
            }
        }
        d.show()
    }

    /** Bảng nhập API dạng kính: chỉ một ô nhập, app tự nhận loại key (Gemini, Groq, Grok, OpenAI, Claude). */
    /** Đặt tên trợ lý (cá nhân hoá). Logo và tên app không đổi. */
    private fun askName() = glassInput("Nhập tên trợ lý", Store.aiName, false) { v ->
        Store.aiName = v
        titleView.text = Store.aiName; input.hint = "Nhắn cho ${Store.aiName}…"
        refresh()
    }

    private fun askKey() = glassInput("Nhập API", "", true) { v ->
        val p = Brain.detect(v); Store.setKey(p, v); Store.provider = p
    }

    /** Cá nhân hoá cách trả lời: mô tả phong cách (hài hước, lịch sự, ngắn gọn, nhây…). AI viết câu theo phong cách đó. */
    private fun askVoiceStyle() = glassInput("VD: hài hước, lịch sự, ngắn gọn", Store.voiceStyle, false, allowEmpty = true) { v ->
        Store.voiceStyle = v.trim()
    }

    /** Hộp thoại nhập liệu dạng kính dùng chung (API, tên trợ lý…). */
    private fun glassInput(hintText: String, initial: String, password: Boolean, allowEmpty: Boolean = false, onSave: (String) -> Unit) {
        val d = Dialog(this)
        val dens = resources.displayMetrics.density
        val reduce = A11y.reduceTransparency(this)
        val field = EditText(this).apply {
            hint = hintText; setHintTextColor(0xB3FFFFFF.toInt()); setTextColor(Color.WHITE)
            setText(initial); setSelection(initial.length)
            textSize = 16f; isSingleLine = true; background = GlassDrawable(dens, 0x33FFFFFF, -1f)
            inputType = InputType.TYPE_CLASS_TEXT or
                (if (password) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_CAP_WORDS)
            typeface = Typeface.DEFAULT
            imeOptions = EditorInfo.IME_ACTION_DONE
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        fun pill(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = GlassDrawable(dens, color); isClickable = true; isFocusable = true
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setOnClickListener { onClick() }
        }
        val save = {
            val v = field.text.toString().trim()
            if (v.isNotEmpty() || allowEmpty) onSave(v)
            d.dismiss()
        }
        field.setOnEditorActionListener { _, _, _ -> save(); true }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(pill("Huỷ", 0x33FFFFFF) { d.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(pill("Lưu", ACCENT) { save() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GlassDrawable(dens, if (reduce) 0xF21E222B.toInt() else GLASS_SMOKE, 28f)
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(field, LinearLayout.LayoutParams(-1, -2))
            addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        }
        d.setContentView(card)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            decorView.setPadding(dp(20), 0, dp(20), 0)
            setDimAmount(0.25f)
            // Kính thật: làm mờ màn hình phía sau (Android 12+, máy hỗ trợ làm mờ giữa các cửa sổ)
            if (Build.VERSION.SDK_INT >= 31 && !reduce) {
                addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                attributes = attributes.apply { blurBehindRadius = dp(24) }
            }
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        d.show()
        field.requestFocus()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        Store.unlisten(onStore); voice.destroy(); super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleAssist(intent) }

    /** Mở từ nút trợ lý / lệnh giọng nói → nghe ngay. */
    private fun handleAssist(i: Intent?) {
        if (i?.action in setOf(LISTEN, Intent.ACTION_ASSIST, Intent.ACTION_VOICE_COMMAND, "android.speech.action.WEB_SEARCH"))
            input.post { if (!voice.listening) listen() }
    }

    companion object { const val LISTEN = "com.vxm.assist.LISTEN"; private const val PICK = 7 }
}
