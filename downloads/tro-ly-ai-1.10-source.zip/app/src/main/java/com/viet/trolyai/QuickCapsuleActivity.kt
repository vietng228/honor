package com.viet.trolyai

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Capsule độc lập dành cho Magic Button khi Gemini vẫn là trợ lý mặc định. */
class QuickCapsuleActivity : Activity(), Voice.Callback {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private lateinit var wave: WaveView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var head: LinearLayout
    private lateinit var replyScroll: ScrollView
    private var active = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Store.uiContext = this
        voice = Voice(this, this)
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setBackgroundDrawableResource(android.R.color.transparent)
        createContent()
        active = true
        voice.holdFocus(true)
        if (Store.brain == null) {
            say("Mở app Việt Ximi để nhập API trước nhé.")
            main.postDelayed({ finish() }, 3000)
        } else listen()
    }

    private fun createContent() {
        val density = resources.displayMetrics.density
        val color = 0xFFF5F8FC.toInt()
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            clipToOutline = true; elevation = 2 * density
        }
        wave = WaveView(this)
        heard = TextView(this).apply {
            setTextColor(color); textSize = 15f; maxLines = 2; visibility = View.GONE
            maxWidth = resources.displayMetrics.widthPixels - dp(112)
            setShadowLayer(6f, 0f, 1f, 0x80000000.toInt())
        }
        head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(wave, LinearLayout.LayoutParams(dp(96), dp(22)).apply { marginStart = dp(10) })
            addView(heard, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        }
        reply = TextView(this).apply {
            setTextColor(color); textSize = 16f; maxLines = 10; visibility = View.GONE
            maxWidth = resources.displayMetrics.widthPixels - dp(64)
            setPadding(dp(4), dp(3), dp(4), dp(3))
            setShadowLayer(6f, 0f, 1f, 0x80000000.toInt())
        }
        replyScroll = ScrollView(this).apply {
            visibility = View.GONE
            addView(reply, FrameLayout.LayoutParams(-1, -2))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GlassDrawable(density, 0xD91C222B.toInt(), 24f)
            setPadding(dp(10), dp(8), dp(14), dp(8))
            addView(head)
            addView(replyScroll, LinearLayout.LayoutParams(-1, -2))
        }
        val panel = FrameLayout(this).apply {
            elevation = 10 * density; isClickable = true
            addView(content, FrameLayout.LayoutParams(-2, -2))
            alpha = 0f; scaleX = 0.92f; scaleY = 0.92f
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { if (!voice.speaking) finish() }
            addView(panel, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { setMargins(dp(16), 0, dp(16), dp(22)) })
        })
    }

    private fun listen() {
        if (!active) return
        head.visibility = View.VISIBLE
        heard.visibility = View.GONE
        reply.visibility = View.GONE
        replyScroll.visibility = View.GONE
        wave.visibility = View.VISIBLE
        wave.running = true
        voice.listen()
    }

    override fun onPartial(text: String) {
        if (text.isBlank()) return
        wave.running = false; wave.visibility = View.GONE
        heard.text = Pretty.fix(this, text); heard.visibility = View.VISIBLE
    }

    override fun onLevel(level: Float) { wave.level(level) }

    override fun onHeard(text: String?) {
        wave.running = false
        if (!active) return
        if (text == null) { finish(); return }
        wave.visibility = View.GONE
        heard.text = Pretty.fix(this, text); heard.visibility = View.VISIBLE
        Notifier.thinking(this)
        Store.send(text) { result ->
            if (!active) return@send
            result.onSuccess {
                say(it)
                Notifier.answer(this, it)
                if (System.currentTimeMillis() - AppLauncher.lastLaunch < 3000) {
                    finish(); return@send
                }
                if (Store.speakReplies) voice.speak(it) else main.postDelayed({ listen() }, 600)
            }.onFailure {
                say("Lỗi: ${it.message}")
                main.postDelayed({ finish() }, 3000)
            }
        }
    }

    private fun say(text: String) {
        head.visibility = View.GONE
        reply.text = Censor.mask(Pretty.fix(this, text))
        reply.visibility = View.VISIBLE
        replyScroll.visibility = View.VISIBLE
    }

    override fun onSpeakDone() { if (active) main.postDelayed({ listen() }, 700) }

    /** Trợ lý/app khác lên foreground thì nhả micro và audio focus ngay, không để hai phiên chồng nhau. */
    override fun onPause() {
        super.onPause()
        if (!isChangingConfigurations) {
            releaseSession()
            if (!isFinishing) finish()
        }
    }

    private fun releaseSession() {
        if (!active) return
        active = false
        main.removeCallbacksAndMessages(null)
        wave.running = false
        voice.stopListening()
        voice.stopSpeaking()
        voice.holdFocus(false)
        if (Store.uiContext === this) Store.uiContext = null
    }

    override fun onDestroy() {
        releaseSession()
        voice.destroy()
        super.onDestroy()
    }
}
