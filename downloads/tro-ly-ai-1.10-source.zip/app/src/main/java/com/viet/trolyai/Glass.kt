package com.viet.trolyai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.Build
import android.provider.Settings
import android.view.View
import android.widget.FrameLayout

const val ACCENT = 0xFF3B82F6.toInt()
/** Kính trong (như icon/thư mục của máy): trắng mờ trên nền đã làm mờ. */
const val GLASS_CLEAR = 0x2EFFFFFF
/** Thanh/nút nổi trên nội dung cuộn: kính khói nhẹ để chữ bên dưới không lẫn vào chữ của thanh. */
val GLASS_BAR = 0xD926292F.toInt()
/** Kính khói: dùng khi nằm trên ứng dụng bất kỳ hoặc khi không làm mờ được, để chữ trắng luôn đọc rõ. */
val GLASS_SMOKE = 0xB31E222B.toInt()

/** Tôn trọng cài đặt trợ năng: giảm chuyển động / tương phản cao (thay cho Reduce Transparency). */
object A11y {
    fun reduceMotion(c: Context) =
        Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    fun reduceTransparency(c: Context) =
        Settings.Secure.getInt(c.contentResolver, "high_text_contrast_enabled", 0) == 1
}

/**
 * Vật liệu kính cho lớp điều khiển: lớp màu (tint) + ánh sáng mặt trên + viền sáng như khúc xạ ở mép,
 * góc bo dạng viên thuốc (capsule). Có trạng thái focus (vòng nhấn) và pressed.
 */
class GlassDrawable(private val density: Float, var fillColor: Int, private val radiusDp: Float = -1f) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = ACCENT }
    private val r = RectF(); private val tmp = RectF()
    private var focused = false; private var pressed = false

    fun radius() = if (radiusDp < 0) minOf(r.width(), r.height()) / 2 else radiusDp * density

    override fun onBoundsChange(b: Rect) {
        r.set(b)
        val top = b.top.toFloat(); val bottom = b.bottom.toFloat()
        rim.shader = LinearGradient(0f, top, 0f, bottom,
            intArrayOf(0xD9FFFFFF.toInt(), 0x26FFFFFF, 0x73FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        sheen.shader = LinearGradient(0f, top, 0f, top + b.height() * 0.6f,
            0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun draw(c: Canvas) {
        val rad = radius()
        fill.color = fillColor; c.drawRoundRect(r, rad, rad, fill)
        c.drawRoundRect(r, rad, rad, sheen)
        if (pressed) { fill.color = 0x24FFFFFF; c.drawRoundRect(r, rad, rad, fill) }
        rim.strokeWidth = density
        tmp.set(r); tmp.inset(density / 2, density / 2); c.drawRoundRect(tmp, rad, rad, rim)
        if (focused) {
            ring.strokeWidth = 2 * density
            tmp.set(r); tmp.inset(density, density); c.drawRoundRect(tmp, rad, rad, ring)
        }
    }

    override fun isStateful() = true
    override fun onStateChange(state: IntArray): Boolean {
        val f = android.R.attr.state_focused in state; val p = android.R.attr.state_pressed in state
        if (f == focused && p == pressed) return false
        focused = f; pressed = p; invalidateSelf(); return true
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * Thanh/nút kính nổi trên nội dung: trên Android 12+ làm mờ + tăng bão hoà phần nội dung [source]
 * nằm ngay bên dưới (như thấu kính), sau đó phủ GlassDrawable. Nội dung bản thân không bao giờ thành kính.
 * Không có blur (máy cũ / bật tương phản cao) thì dùng lớp màu gần đặc để luôn dễ đọc.
 */
class GlassView(ctx: Context, radiusDp: Float = -1f) : FrameLayout(ctx) {
    var source: View? = null
    private val blur = Build.VERSION.SDK_INT >= 31 && !A11y.reduceTransparency(ctx)
    val glass = GlassDrawable(resources.displayMetrics.density,
        if (blur) GLASS_BAR else GLASS_SMOKE, radiusDp)
    private val node: Any? = if (blur) RenderNode("glass").apply {
        setRenderEffect(RenderEffect.createChainEffect(
            RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.8f) })),
            RenderEffect.createBlurEffect(28f, 28f, Shader.TileMode.CLAMP)))
    } else null
    private val path = Path(); private val a = IntArray(2); private val b = IntArray(2)

    init { background = glass }

    override fun draw(c: Canvas) {
        val src = source
        if (Build.VERSION.SDK_INT >= 31 && node is RenderNode && src != null && c.isHardwareAccelerated && width > 0) {
            getLocationInWindow(a); src.getLocationInWindow(b)
            node.setPosition(0, 0, width, height)
            val rc = node.beginRecording()
            rc.translate((b[0] - a[0]).toFloat(), (b[1] - a[1]).toFloat())
            src.draw(rc)
            node.endRecording()
            val rad = glass.radius()
            path.reset(); path.addRoundRect(0f, 0f, width.toFloat(), height.toFloat(), rad, rad, Path.Direction.CW)
            c.save(); c.clipPath(path); c.drawRenderNode(node); c.restore()
        }
        super.draw(c)
    }
}

/**
 * Vật liệu capsule giống Việt Ximi: nền kính tối #0F1724→#080C14, ánh sáng trên đỉnh,
 * vệt sáng từ trái, viền sáng chuyển trái→phải; bo tròn hết cỡ (tối đa [maxRadiusDp] khi nhiều dòng).
 * [accent] ≠ 0 thì phủ màu nhấn (vd đỏ khi đang nghe).
 */
class XimiCapsuleDrawable(private val density: Float, private val maxRadiusDp: Float = 22f) : Drawable() {
    var accent = 0
        set(v) { field = v; invalidateSelf() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun draw(c: Canvas) {
        val b = bounds; val w = b.width().toFloat(); val h = b.height().toFloat()
        val rad = minOf(h / 2, maxRadiusDp * density)
        c.save(); c.translate(b.left.toFloat(), b.top.toFloat())
        r.set(1f, 1f, w - 1f, h - 1f)
        p.style = Paint.Style.FILL
        // Kính khói trong suốt: vẫn thấy ứng dụng phía sau nhưng chữ trắng luôn rõ
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xE62A303C.toInt(), 0xF0141821.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        if (accent != 0) { p.shader = null; p.color = accent; c.drawRoundRect(r, rad, rad, p) }
        p.shader = LinearGradient(0f, 0f, 0f, minOf(h, 120 * density), 0x4DFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = LinearGradient(0f, 0f, w, 0f, 0x18FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xE6FFFFFF.toInt(), 0x33FFFFFF, 0x80FFFFFF.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * density
        r.set(1f, 1f, w - 1f, h - 1f)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = null
        c.restore()
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * Sóng âm dạng nhiều vạch mảnh trải hết chiều ngang, cao thấp theo độ to giọng nói ([level] 0..1):
 * giữa cao, hai đầu thấp, mỗi vạch dao động lệch nhịp cho sinh động. Bật "Giảm chuyển động" thì đứng yên.
 */
class WaveView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val barW = 2.5f * d
    private val gap = 3.5f * d
    private var cur = FloatArray(0)
    private val still = A11y.reduceMotion(ctx)
    private var target = 0f
    private var t = 0f
    var running = false
        set(v) { field = v; if (!v) target = 0f; invalidate() }

    fun level(v: Float) { target = v.coerceIn(0f, 1f) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cur = FloatArray(((w + gap) / (barW + gap)).toInt().coerceAtLeast(1)) { 0.12f }
        p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f,
            intArrayOf(0xFF7DD3FC.toInt(), 0xFFA78BFA.toInt(), 0xFF5EEAD4.toInt()), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val n = cur.size; val h = height.toFloat()
        // căn giữa dải vạch trong khung
        val x0 = (width - (n * barW + (n - 1) * gap)) / 2
        t += 0.18f
        for (i in 0 until n) {
            val pos = if (n == 1) 0.5f else i / (n - 1f)
            val env = 0.3f + 0.7f * kotlin.math.sin(Math.PI * pos).toFloat()
            val wobble = if (running && !still) 0.5f + 0.5f * kotlin.math.sin(t * 1.7f + i * 0.9f) else 0.5f
            val goal = if (still || !running) 0.12f
                else (0.12f + env * (0.15f + target * 0.85f) * (0.55f + 0.45f * wobble)).coerceAtMost(1f)
            cur[i] += (goal - cur[i]) * 0.3f
            val bh = maxOf(barW, h * cur[i])
            val x = x0 + i * (barW + gap)
            c.drawRoundRect(x, (h - bh) / 2, x + barW, (h + bh) / 2, barW / 2, barW / 2, p)
        }
        if (running && !still) postInvalidateOnAnimation()
    }
}
