package com.viet.trolyai

/**
 * Che từ tục: hiển thị thành "***", khi đọc thành "bíp". Dùng cho chế độ cà khịa/chửi nhau cho vui,
 * để câu chữ vẫn lịch sự trên màn hình và không phát ra tiếng chửi bậy.
 */
object Censor {
    // Các từ/cụm tục phổ biến (có và không dấu). Khớp cả khi viết dính, không phân biệt hoa thường.
    private val WORDS = listOf(
        "đụ", "đu ", "địt", "dit ", "đéo", "deo ", "lồn", "lon ", "cặc", "cac ", "buồi", "buoi ",
        "cứt", "cut ", "đĩ", "di ", "đĩ điếm", "phò", "đĩ chó",
        "đm", "đmm", "dm ", "đcm", "dcm", "đkm", "vcl", "vl ", "vkl", "clgt", "đmht",
        "thằng chó", "con chó", "đồ chó", "chó chết", "mẹ mày", "bố mày", "cmm", "cmn", "vãi lồn", "vãi cả lồn"
    ).map { it.trim() }.filter { it.isNotEmpty() }.sortedByDescending { it.length }

    private val RE = Regex(
        "(?<![\\p{L}])(" + WORDS.joinToString("|") { Regex.escape(it) } + ")(?![\\p{L}])",
        RegexOption.IGNORE_CASE
    )

    /** Dùng để HIỂN THỊ: từ tục → "***". */
    fun mask(text: String): String = RE.replace(text) { "***" }

    /** Dùng để ĐỌC: từ tục → "bíp" (không phát ra tiếng chửi). */
    fun beep(text: String): String = RE.replace(text) { "bíp" }
}
