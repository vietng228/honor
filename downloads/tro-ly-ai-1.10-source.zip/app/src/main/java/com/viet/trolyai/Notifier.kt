package com.viet.trolyai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color

/**
 * Báo kết quả lệnh / câu trả lời dạng thông báo "hoạt động trực tiếp":
 * Android 16+ đưa lên đảo động của máy (Magic Capsule của Honor, Super Island của Xiaomi…);
 * máy cũ hiện thông báo nổi bình thường. Dùng CHUNG một id nên chip tự đổi nội dung (Đang xử lý → kết quả),
 * không xếp chồng. Tự biến mất sau vài giây.
 */
object Notifier {
    private const val CH = "actions"
    private const val ID = 100           // một chip duy nhất, luôn cập nhật

    /** Hiện ngay khi vừa nhận lệnh (đảo động: "Đang xử lý…"); giữ đến khi có kết quả thay thế. */
    fun thinking(ctx: Context) = post(ctx, "${Store.aiName} đang xử lý…", "…", null, ongoingMs = 0, colorOn = false)

    /** Câu trả lời của trợ lý (phiên Live) → hiện trên đảo động, bấm vào mở app xem lại. */
    fun answer(ctx: Context, text: String) {
        val t = Censor.mask(text.replace("\n", " ").trim())
        post(ctx, t, t.take(16), null)
    }

    /** [tap] = màn hình mở ra khi bấm vào thông báo/đảo động (null → mở Việt Ximi). */
    fun done(ctx: Context, ok: Boolean, title: String, short: String, tap: Intent? = null) =
        post(ctx, title, short, tap)

    private fun post(ctx: Context, title: String, short: String, tap: Intent?,
                     ongoingMs: Long = 8000, colorOn: Boolean = true) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (android.os.Build.VERSION.SDK_INT >= 33 && !nm.areNotificationsEnabled()) return
        nm.createNotificationChannel(NotificationChannel(CH, "Trợ lý", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Trạng thái và kết quả lệnh trên đảo động"; setSound(null, null); enableVibration(false)
        })
        val open = PendingIntent.getActivity(ctx, ID, tap ?: Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = Notification.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(Store.aiName)
            .style(title)                 // mở rộng xem đầy đủ câu dài
            .setContentIntent(open)
            .setOngoing(true)             // hoạt động trực tiếp phải là thông báo đang diễn ra
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .setColor(ACCENT)
            .setColorized(colorOn)        // nền chip theo màu nhấn Việt Ximi (máy hỗ trợ)
        if (ongoingMs > 0) b.setTimeoutAfter(ongoingMs)
        // Android 16+: "nâng" lên đảo động + chữ ngắn trên đảo (reflection để chạy được cả máy chưa có API)
        runCatching { b.javaClass.getMethod("setRequestPromotedOngoing", Boolean::class.javaPrimitiveType).invoke(b, true) }
        runCatching { b.javaClass.getMethod("setShortCriticalText", String::class.java).invoke(b, short) }
        nm.notify(ID, b.build())
    }

    private fun Notification.Builder.style(text: String) =
        if (text.length > 40) setStyle(Notification.BigTextStyle().bigText(text)) else this
}
