package com.viet.trolyai

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Điểm vào dành cho phím AI của MagicOS: hiện capsule rồi đóng ngay. */
class CapsuleTriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (AssistService.showCapsule()) {
            finish()
            overridePendingTransition(0, 0)
            return
        }
        startActivity(Intent(this, QuickCapsuleActivity::class.java))
        finish()
        overridePendingTransition(0, 0)
    }
}
