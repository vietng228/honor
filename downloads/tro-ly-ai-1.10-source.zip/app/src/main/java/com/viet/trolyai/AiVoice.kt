package com.viet.trolyai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Giọng đọc AI của Gemini (miễn phí với key Gemini). Gọi từ luồng nền. */
object AiVoice {
    /** id, tên hiển thị, mô tả. */
    val VOICES = listOf(
        Triple("Kore", "Kore", "Nữ · trầm ấm"),
        Triple("Aoede", "Aoede", "Nữ · nhẹ nhàng"),
        Triple("Leda", "Leda", "Nữ · trẻ trung"),
        Triple("Zephyr", "Zephyr", "Nữ · tươi sáng"),
        Triple("Despina", "Despina", "Nữ · mềm mại"),
        Triple("Sulafat", "Sulafat", "Nữ · ấm áp"),
        Triple("Puck", "Puck", "Nam · vui vẻ"),
        Triple("Charon", "Charon", "Nam · điềm đạm"),
        Triple("Fenrir", "Fenrir", "Nam · hào hứng"),
        Triple("Orus", "Orus", "Nam · chắc chắn"),
        Triple("Iapetus", "Iapetus", "Nam · rõ ràng"),
    )
    // Mỗi model chỉ gọi một lần; Flash-Lite dùng quota riêng khi Flash đạt giới hạn ngày.
    private val MODELS = listOf("gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts")

    class Pcm(val data: ByteArray, val rate: Int)

    fun fetch(text: String, voice: String, key: String): Pcm {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        var last: Exception? = null
        for (m in MODELS) {
            try {
                val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                    .openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.doOutput = true
                conn.connectTimeout = 10000; conn.readTimeout = 30000
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                if (conn.responseCode !in 200..299) {
                    last = RuntimeException("TTS $m HTTP ${conn.responseCode}"); Thread.sleep(700); continue
                }
                val inline = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    .getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
                return decode(inline.getString("mimeType"), Base64.decode(inline.getString("data"), Base64.DEFAULT))
            } catch (e: Exception) { last = e }
        }
        throw last!!
    }

    /** WAV → lấy đoạn "data"; L16 → PCM thô (rate trong mimeType). */
    private fun decode(mime: String, bytes: ByteArray): Pcm {
        if (mime.contains("wav") && bytes.size > 44 && String(bytes, 0, 4) == "RIFF") {
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val rate = bb.getInt(24)
            var i = 12
            while (i + 8 <= bytes.size) {
                val id = String(bytes, i, 4); val size = bb.getInt(i + 4)
                if (id == "data") return Pcm(bytes.copyOfRange(i + 8, minOf(bytes.size, i + 8 + size)), rate)
                i += 8 + size
            }
        }
        val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toInt() ?: 24000
        return Pcm(bytes, rate)
    }

    /** Phát PCM 16-bit mono; trả về khi phát xong hoặc khi [cancelled] = true. */
    fun play(pcm: Pcm, onTrack: (AudioTrack) -> Unit, cancelled: () -> Boolean) {
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(pcm.rate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(AudioTrack.getMinBufferSize(pcm.rate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4)
            .build()
        onTrack(track)
        try {
            track.play()
            var off = 0
            while (off < pcm.data.size && !cancelled()) {
                val n = track.write(pcm.data, off, minOf(8192, pcm.data.size - off))
                if (n <= 0) break
                off += n
            }
            val frames = pcm.data.size / 2
            while (!cancelled() && track.playbackHeadPosition < frames) Thread.sleep(50)
        } finally {
            runCatching { track.stop() }; track.release()
        }
    }
}
