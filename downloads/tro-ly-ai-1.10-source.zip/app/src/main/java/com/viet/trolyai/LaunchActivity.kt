package com.viet.trolyai

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Màn hình trung gian trong suốt: mở app đích rồi tự đóng ngay.
 * Honor/Xiaomi chặn app mở app khác khi không có màn hình đang hiện (vd từ bảng Live của nút nguồn);
 * mở qua màn hình này thì được coi là người dùng mở nên app đích bật lên ngay.
 */
class LaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        val target = intent.getParcelableExtra<Intent>(EXTRA)
        if (target != null) runCatching { startActivity(target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        finish()
        overridePendingTransition(0, 0)
    }

    companion object { const val EXTRA = "target" }
}
