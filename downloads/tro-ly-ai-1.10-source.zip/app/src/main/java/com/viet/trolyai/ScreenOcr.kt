package com.viet.trolyai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

data class OcrLine(val box: Rect, val original: String, val translated: String, val darkBackground: Boolean)
data class OcrTranslation(val imageWidth: Int, val imageHeight: Int, val sourceLanguage: String, val lines: List<OcrLine>)

/** OCR có tọa độ + dịch ngoại tuyến; mô hình ngôn ngữ được tải một lần khi cần. */
object ScreenOcr {
    fun translate(bitmap: Bitmap, status: (String) -> Unit, done: (Result<OcrTranslation>) -> Unit) {
        status("Đang nhận diện chữ…")
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizers = listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
        )
        val results = arrayOfNulls<Text>(recognizers.size)
        fun run(index: Int) {
            if (index == recognizers.size) {
                recognizers.forEach { it.close() }
                val recognized = chooseResult(results.filterNotNull())
                val lines = recognized.textBlocks.flatMap { it.lines }.mapNotNull { line ->
                    line.boundingBox?.let {
                        val x = it.centerX().coerceIn(0, bitmap.width - 1)
                        val y = it.centerY().coerceIn(0, bitmap.height - 1)
                        val color = bitmap.getPixel(x, y)
                        val luminance = (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
                        OcrLine(Rect(it), line.text.trim(), "", luminance < 128)
                    }
                }.filter { it.original.isNotEmpty() }
                if (lines.isEmpty()) {
                    done(Result.failure(IllegalStateException("Không tìm thấy chữ trên màn hình.")))
                    return
                }
                identifyAndTranslate(bitmap, lines, status, done)
                return
            }
            recognizers[index].process(image)
                .addOnSuccessListener { results[index] = it; run(index + 1) }
                .addOnFailureListener { run(index + 1) }
        }
        run(0)
    }

    /** Ưu tiên bộ OCR có nhiều ký tự thuộc hệ chữ chuyên dụng; màn hình Latin dùng kết quả đầu tiên. */
    private fun chooseResult(results: List<Text>): Text {
        if (results.isEmpty()) throw IllegalStateException("OCR không khởi động được.")
        val specialized = results.drop(1).maxByOrNull { text ->
            text.text.count { c -> isHan(c) || isKana(c) || isHangul(c) }
        }
        return specialized?.takeIf { text -> text.text.any { isHan(it) || isKana(it) || isHangul(it) } }
            ?: results.first()
    }

    private fun identifyAndTranslate(bitmap: Bitmap, lines: List<OcrLine>, status: (String) -> Unit,
                                     done: (Result<OcrTranslation>) -> Unit) {
        status("Đang xác định ngôn ngữ…")
        val identifier = LanguageIdentification.getClient(
            LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.20f).build())
        identifier.identifyLanguage(lines.joinToString("\n") { it.original })
            .addOnSuccessListener { tag ->
                identifier.close()
                // OCR hiện dùng bộ chữ Latin; nếu bộ nhận diện chưa đủ chắc chắn thì tiếng Anh là dự phòng hợp lý.
                val allText = lines.joinToString("\n") { it.original }
                val inferred = when {
                    allText.any(::isHangul) -> TranslateLanguage.KOREAN
                    allText.any(::isKana) -> TranslateLanguage.JAPANESE
                    allText.any(::isHan) -> TranslateLanguage.CHINESE
                    else -> TranslateLanguage.ENGLISH
                }
                val source = TranslateLanguage.fromLanguageTag(tag) ?: inferred
                when {
                    tag == "vi" -> done(Result.success(OcrTranslation(bitmap.width, bitmap.height, tag,
                        lines.map { it.copy(translated = it.original) })))
                    else -> translateLines(bitmap, source, lines, status, done)
                }
            }
            .addOnFailureListener { identifier.close(); done(Result.failure(it)) }
    }

    private fun translateLines(bitmap: Bitmap, source: String, lines: List<OcrLine>, status: (String) -> Unit,
                               done: (Result<OcrTranslation>) -> Unit) {
        val translator = Translation.getClient(TranslatorOptions.Builder()
            .setSourceLanguage(source).setTargetLanguage(TranslateLanguage.VIETNAMESE).build())
        status("Đang tải bộ dịch lần đầu…")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status("Đang dịch ${lines.size} dòng chữ…")
                val output = ArrayList<OcrLine>(lines.size)
                fun next(index: Int) {
                    if (index == lines.size) {
                        translator.close()
                        done(Result.success(OcrTranslation(bitmap.width, bitmap.height, source, output)))
                        return
                    }
                    val line = lines[index]
                    translator.translate(line.original)
                        .addOnSuccessListener { output += line.copy(translated = it); next(index + 1) }
                        .addOnFailureListener { output += line.copy(translated = line.original); next(index + 1) }
                }
                next(0)
            }
            .addOnFailureListener { translator.close(); done(Result.failure(it)) }
    }

    private fun isHan(c: Char) = c.code in 0x3400..0x4DBF || c.code in 0x4E00..0x9FFF
    private fun isKana(c: Char) = c.code in 0x3040..0x30FF
    private fun isHangul(c: Char) = c.code in 0xAC00..0xD7AF || c.code in 0x1100..0x11FF
}

/** Phủ từng bản dịch lên đúng hộp chữ OCR của ảnh màn hình. */
class OcrOverlayView(context: Context) : View(context) {
    var translation: OcrTranslation? = null
        set(value) { field = value; invalidate() }
    private val background = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private val area = RectF()

    override fun onDraw(canvas: Canvas) {
        val result = translation ?: return
        val sx = width.toFloat() / result.imageWidth
        val sy = height.toFloat() / result.imageHeight
        result.lines.forEach { line ->
            area.set(line.box.left * sx, line.box.top * sy, line.box.right * sx, line.box.bottom * sy)
            area.inset(-2f, -2f)
            val dark = line.darkBackground
            background.color = if (dark) 0xEE202124.toInt() else 0xEEF8F9FA.toInt()
            text.color = if (dark) Color.WHITE else 0xFF202124.toInt()
            canvas.drawRoundRect(area, 5f, 5f, background)

            val label = line.translated.ifBlank { line.original }
            text.textSize = (area.height() * 0.72f).coerceIn(11f, 54f)
            while (text.textSize > 11f && text.measureText(label) > area.width()) text.textSize -= 1f
            val fm = text.fontMetrics
            val baseline = area.centerY() - (fm.ascent + fm.descent) / 2
            canvas.save(); canvas.clipRect(area)
            canvas.drawText(label, area.left + 3f, baseline, text)
            canvas.restore()
        }
    }

}
