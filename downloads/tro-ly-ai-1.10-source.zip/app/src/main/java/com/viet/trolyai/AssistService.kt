package com.viet.trolyai

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.Normalizer

/**
 * Cho phép chọn Việt Ximi làm "Ứng dụng trợ lý kỹ thuật số" mặc định (thay Google/Gemini/trợ lý của hãng).
 * Giữ nút nguồn → phiên Live hiện ngay trên màn hình đang dùng (không mở app).
 */
class AssistService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        active = this
    }

    override fun onShutdown() {
        if (active === this) active = null
        super.onShutdown()
    }

    companion object {
        @Volatile private var active: AssistService? = null

        fun showCapsule(): Boolean {
            val service = active ?: return false
            return runCatching {
                service.showSession(Bundle.EMPTY,
                    VoiceInteractionSession.SHOW_WITH_ASSIST or VoiceInteractionSession.SHOW_WITH_SCREENSHOT)
            }.isSuccess
        }
    }
}

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = LiveSession(this)
}

/**
 * Hội thoại kiểu Gemini Live trong một capsule kính ở đáy màn hình, nằm trên ứng dụng đang mở:
 * lúc nghe chỉ có icon Việt Ximi + sóng âm trải hết capsule; khi trả lời capsule mở rộng hiện chữ.
 * Nghe → trả lời (chữ + giọng) → tự nghe tiếp. Im lặng hoặc chạm ra ngoài để kết thúc.
 * Có ảnh màn hình (hệ thống gửi kèm khi gọi trợ lý) để "chụp màn hình", "dịch màn hình", "màn hình này là gì".
 */
class LiveSession(ctx: Context) : VoiceInteractionSession(ctx), Voice.Callback {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private lateinit var you: TextView      // câu người dùng
    private lateinit var reply: TextView    // câu trả lời
    private lateinit var wave: WaveView
    private lateinit var translateButton: TextView
    private lateinit var head: View
    private lateinit var backdrop: Backdrop
    private lateinit var panel: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var replyScroll: android.widget.ScrollView
    private lateinit var root: FrameLayout
    private lateinit var ocrOverlay: OcrOverlayView
    private var active = false
    /** Ảnh màn hình lúc gọi trợ lý (cần bật "Dùng ảnh chụp màn hình" trong Trợ lý & nhập liệu bằng giọng nói). */
    private var screen: Bitmap? = null

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        Store.init(context)
        voice = Voice(context, this)
    }

    override fun onCreateContentView(): View {
        val d = context.resources.displayMetrics.density
        val text = 0xFFF5F8FC.toInt()
        val logo = ImageView(context).apply {
            setImageResource(R.drawable.app_icon); clipToOutline = true
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        // Capsule gọn: icon + sóng âm ngắn; nhận ra chữ thì chữ thay chỗ sóng âm ngay trong capsule
        val maxText = context.resources.displayMetrics.widthPixels - dp(120)
        wave = WaveView(context).apply { contentDescription = "${Store.aiName} đang nghe" }
        translateButton = TextView(context).apply {
            this.text = "Dịch màn hình"; textSize = 14f; setTextColor(0xFFBFDBFE.toInt())
            gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GlassDrawable(d, 0x553B82F6, 18f)
            isClickable = true; isFocusable = true; visibility = View.GONE
            setOnClickListener {
                screen?.let { bitmap -> wave.running = false; translateScreen(bitmap) }
                    ?: say("Chưa lấy được ảnh màn hình: hãy bật quyền dùng ảnh chụp màn hình cho trợ lý.")
            }
        }
        you = TextView(context).apply {
            setTextColor(text); textSize = 16f; maxLines = 3; ellipsize = TextUtils.TruncateAt.START
            maxWidth = maxText; visibility = View.GONE
        }
        head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(32), dp(32)))
            addView(wave, LinearLayout.LayoutParams(dp(112), dp(24)).apply { marginStart = dp(12) })
            addView(you, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12) })
            addView(translateButton, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        }
        reply = TextView(context).apply {
            setTextColor(text); textSize = 17f; maxLines = 16; ellipsize = TextUtils.TruncateAt.END
            maxWidth = context.resources.displayMetrics.widthPixels - dp(84)
            setPadding(dp(6), dp(4), dp(6), dp(4)); visibility = View.GONE
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        replyScroll = android.widget.ScrollView(context).apply {
            visibility = View.GONE
            addView(reply, FrameLayout.LayoutParams(-1, -2))
        }
        // Kính lỏng thật: lớp dưới là chính phần màn hình nằm sau capsule (ảnh màn hình) được làm mờ + tăng màu,
        // lớp trên là kính trong viền trắng giống giao diện app; chữ trắng có bóng nhẹ để luôn đọc rõ.
        content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GlassDrawable(d, 0x1FFFFFFF, 30f)
            setPadding(dp(10), dp(10), dp(18), dp(10))
            addView(head); addView(replyScroll, LinearLayout.LayoutParams(-1, -2))
        }
        backdrop = Backdrop(context)
        // Đo phần nội dung trước, rồi ép lớp kính mờ đúng bằng khung đó
        panel = object : FrameLayout(context) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, h)
                backdrop.measure(MeasureSpec.makeMeasureSpec(measuredWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(measuredHeight, MeasureSpec.EXACTLY))
            }
        }.apply {
            background = GradientDrawable().apply { cornerRadius = 30 * d; setColor(0x33000000) }
            clipToOutline = true; elevation = 10 * d
            isClickable = true // chạm trong capsule không đóng phiên
            addView(backdrop, FrameLayout.LayoutParams(-1, -1))
            addView(content, FrameLayout.LayoutParams(-2, -2))
        }
        listOf(you, reply).forEach { it.setShadowLayer(6f, 0f, 1f, 0x80000000.toInt()) }
        ocrOverlay = OcrOverlayView(context).apply { visibility = View.GONE }
        root = FrameLayout(context).apply {
            // Lớp mờ nhẹ phía dưới cho dễ đọc; phần trên vẫn thấy ứng dụng đang mở
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(0x80000000.toInt(), 0x00000000))
            // Chạm ra ngoài để đóng — nhưng đang ĐỌC trả lời thì không đóng (để không cắt lời giữa chừng)
            setOnClickListener { if (!voice.speaking) finish() }
            addView(ocrOverlay, FrameLayout.LayoutParams(-1, -1))
            addView(panel, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { setMargins(dp(20), 0, dp(20), dp(28)) })
        }
        return root
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        screen = screenshot; backdrop.bitmap = screenshot
        if (active && screenshot != null && ::translateButton.isInitialized && wave.visibility == View.VISIBLE)
            translateButton.visibility = View.VISIBLE
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        active = true
        Store.uiContext = context
        voice.holdFocus(true) // nhạc/video đang phát tạm dừng trong lúc nói chuyện với Việt Ximi
        ocrOverlay.visibility = View.GONE; ocrOverlay.translation = null
        you.visibility = View.GONE; reply.visibility = View.GONE
        if (Store.brain == null) { say("Mở app Việt Ximi để nhập API trước nhé."); main.postDelayed({ finish() }, 4000); return }
        listen()
    }

    override fun onHide() {
        super.onHide()
        if (Store.uiContext === context) Store.uiContext = null
        voice.holdFocus(false)
        active = false; voice.stopListening(); voice.stopSpeaking(); wave.running = false
        ocrOverlay.visibility = View.GONE; ocrOverlay.translation = null
    }

    override fun onDestroy() { voice.destroy(); super.onDestroy() }

    /** Trạng thái nghe: capsule chỉ có icon + sóng âm. */
    private fun listen() {
        if (!active) return
        ocrOverlay.visibility = View.GONE; ocrOverlay.translation = null
        panel.layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { setMargins(dp(20), 0, dp(20), dp(28)) }
        content.layoutParams = FrameLayout.LayoutParams(-2, -2)
        reply.maxLines = 16; reply.ellipsize = TextUtils.TruncateAt.END
        head.visibility = View.VISIBLE; you.visibility = View.GONE; reply.visibility = View.GONE
        replyScroll.visibility = View.GONE
        wave.visibility = View.VISIBLE; wave.running = true
        translateButton.visibility = if (screen != null) View.VISIBLE else View.GONE
        voice.listen()
    }

    /** Vừa nhận ra chữ: ẩn sóng âm, chữ hiện ngay tại chỗ trong capsule. */
    override fun onPartial(text: String) {
        if (text.isBlank()) return
        wave.running = false; wave.visibility = View.GONE
        translateButton.visibility = View.GONE
        you.text = Pretty.fix(context, text); you.visibility = View.VISIBLE
    }
    override fun onLevel(level: Float) = wave.level(level)

    private fun plain(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        .replace('đ', 'd').replace('Đ', 'D').lowercase()

    override fun onHeard(text: String?) {
        wave.running = false
        if (!active) return
        if (text == null) { finish(); return } // im lặng = kết thúc
        wave.visibility = View.GONE
        you.text = Pretty.fix(context, text); you.visibility = View.VISIBLE
        val q = plain(text)
        // "chụp (ảnh) màn hình" → lưu ảnh ngay, không cần hỏi AI
        if (Regex("chup( anh)? man hinh").containsMatchIn(q)) { saveScreenshot(); return }
        // Lệnh về màn hình: dịch / đọc / giải thích / tóm tắt màn hình, "trên đây/ở đây là gì", "dịch trang này"…
        val wantsScreen = q.contains("man hinh") || q.contains("trang nay") ||
            (q.contains("dich") && (q.contains("nay") || q.length < 14)) ||
            Regex("(tren|o) day").containsMatchIn(q)
        val translate = q.contains("dich")
        if (wantsScreen && translate) {
            val bitmap = screen
            if (bitmap == null) {
                say("Chưa lấy được ảnh màn hình: bật \"Dùng ảnh chụp màn hình\" trong Cài đặt › Trợ lý & nhập liệu bằng giọng nói.")
            } else translateScreen(bitmap)
            return
        }
        val files = if (wantsScreen) listOfNotNull(screenFile()) else emptyList()
        if (wantsScreen && files.isEmpty()) {
            say("Chưa lấy được ảnh màn hình: bật \"Dùng ảnh chụp màn hình\" trong Cài đặt › Trợ lý & nhập liệu bằng giọng nói.")
            return
        }
        val prompt = text
        Notifier.thinking(context)   // đảo động hiện "Đang xử lý…" ngay
        Store.send(prompt, files) { r ->
            if (!active) return@send
            r.onSuccess {
                say(it)
                // Vừa mở app/cài đặt → ẩn phiên để nhường màn hình (app đã có thông báo riêng)
                if (System.currentTimeMillis() - AppLauncher.lastLaunch < 3000) { finish(); return@send }
                // Câu trả lời thường (không mở app) → đưa lên đảo động để còn xem lại sau khi capsule tắt
                Notifier.answer(context, it)
                when {
                    Store.speakReplies -> voice.speak(it)
                    else -> main.postDelayed({ listen() }, 600)
                }
            }
            r.onFailure { say("Lỗi: ${it.message}"); Notifier.answer(context, "Lỗi: ${it.message}"); main.postDelayed({ finish() }, 4000) }
        }
    }

    // Chờ loa tắt hẳn rồi mới nghe tiếp, tránh thu lại chính giọng Việt Ximi
    override fun onSpeakDone() { if (active) main.postDelayed({ listen() }, 700) }

    /** Có kết quả: kết quả thay chỗ capsule đang nghe (ẩn icon, sóng âm và câu hỏi). */
    private fun say(t: String) {
        head.visibility = View.GONE; you.visibility = View.GONE
        translateButton.visibility = View.GONE
        reply.text = Censor.mask(Pretty.fix(context, t)); reply.visibility = View.VISIBLE
        replyScroll.visibility = View.VISIBLE
    }

    private fun translateScreen(bitmap: Bitmap) {
        voice.stopListening(); voice.holdFocus(false)
        Notifier.thinking(context)
        ScreenOcr.translate(bitmap, { status -> main.post { if (active) say(status) } }) { result ->
            main.post {
                if (!active) return@post
                result.onSuccess {
                    if (it.sourceLanguage == "vi") {
                        say("Nội dung trên màn hình đã là tiếng Việt.")
                    } else {
                        ocrOverlay.translation = it; ocrOverlay.visibility = View.VISIBLE
                        say("Đã dịch ${it.lines.size} dòng · chạm ra ngoài để đóng")
                        Notifier.answer(context, "Đã dịch trực tiếp ${it.lines.size} dòng trên màn hình.")
                    }
                }.onFailure {
                    say("Chưa dịch được: ${it.message}")
                    Notifier.answer(context, "Chưa dịch được màn hình: ${it.message}")
                }
            }
        }
    }

    /** Ảnh màn hình → tệp JPEG để gửi Gemini. */
    private fun screenFile(): Attach? {
        val b = screen ?: return null
        val dir = File(context.filesDir, "att").apply { mkdirs() }
        val f = File(dir, "manhinh_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return Attach(f.path, "image/jpeg", "Ảnh màn hình")
    }

    /** Lưu ảnh màn hình vào Ảnh › Việt Ximi; bấm thông báo để xem ảnh. */
    private fun saveScreenshot() {
        val b = screen
        if (b == null) {
            say("Chưa lấy được ảnh màn hình: bật \"Dùng ảnh chụp màn hình\" trong Cài đặt › Trợ lý & nhập liệu bằng giọng nói.")
            return
        }
        val uri: Uri? = runCatching {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "VietXimi_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Việt Ximi")
            }
            val u = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            context.contentResolver.openOutputStream(u)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            u
        }.getOrNull()
        Notifier.done(context, uri != null, if (uri != null) "Đã chụp màn hình" else "Chưa lưu được ảnh màn hình", "📸",
            uri?.let { Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/png")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) })
        say(if (uri != null) "Đã chụp màn hình, ảnh lưu trong Ảnh › Việt Ximi." else "Chưa lưu được ảnh màn hình.")
        main.postDelayed({ finish() }, 1500)
    }
}

/**
 * Nền của capsule: vẽ đúng vùng ảnh màn hình nằm sau capsule rồi làm mờ + tăng bão hoà (Android 12+),
 * phủ lớp tối nhẹ để chữ trắng luôn rõ. Chưa có ảnh màn hình (hoặc bật tương phản cao) thì dùng kính khói.
 */
class Backdrop(ctx: Context) : View(ctx) {
    var bitmap: Bitmap? = null
        set(v) { field = v; invalidate() }
    private val loc = IntArray(2)
    private val src = android.graphics.Rect()
    private val dst = android.graphics.Rect()
    private val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
    private val reduce = A11y.reduceTransparency(ctx)

    init {
        if (android.os.Build.VERSION.SDK_INT >= 31 && !reduce) {
            val r = 22 * resources.displayMetrics.density
            setRenderEffect(android.graphics.RenderEffect.createChainEffect(
                android.graphics.RenderEffect.createColorFilterEffect(android.graphics.ColorMatrixColorFilter(
                    android.graphics.ColorMatrix().apply { setSaturation(1.7f) })),
                android.graphics.RenderEffect.createBlurEffect(r, r, android.graphics.Shader.TileMode.CLAMP)))
        }
    }

    /** Không tự đòi kích thước: chỉ lấp đúng khung capsule (do phần nội dung quyết định). */
    override fun onMeasure(w: Int, h: Int) {
        fun size(spec: Int) = if (MeasureSpec.getMode(spec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(spec) else 0
        setMeasuredDimension(size(w), size(h))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(changed, l, t, r, b); invalidate() }

    override fun onDraw(c: android.graphics.Canvas) {
        val bmp = bitmap
        if (bmp == null || reduce || android.os.Build.VERSION.SDK_INT < 31) { c.drawColor(GLASS_SMOKE); return }
        getLocationOnScreen(loc)
        val screenW = (context.getSystemService(android.view.WindowManager::class.java)
            ?.currentWindowMetrics?.bounds?.width() ?: resources.displayMetrics.widthPixels).toFloat()
        val k = bmp.width / screenW // ảnh màn hình có thể nhỏ hơn màn hình thật
        src.set((loc[0] * k).toInt(), (loc[1] * k).toInt(), ((loc[0] + width) * k).toInt(), ((loc[1] + height) * k).toInt())
        dst.set(0, 0, width, height)
        c.drawBitmap(bmp, src, dst, paint)
        c.drawColor(0x40000000) // tối nhẹ cho chữ trắng
    }
}

/** Bắt buộc phải khai báo cho dịch vụ trợ lý; Việt Ximi dùng bộ nhận giọng của máy nên chỉ báo lỗi. */
class StubRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, cb: Callback?) { cb?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onCancel(cb: Callback?) {}
    override fun onStopListening(cb: Callback?) {}
}
