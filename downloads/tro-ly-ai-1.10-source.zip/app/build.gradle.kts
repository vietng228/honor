plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.viet.trolyai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vxm.assist"
        minSdk = 26
        targetSdk = 34
        versionCode = 18
        versionName = "1.10"
        ndk { abiFilters += "arm64-v8a" }
    }

    // Chữ ký VietMiTV: mật khẩu do build-release.ps1 giải mã từ D:\Claude\secrets rồi truyền qua biến môi trường.
    val ksPass = System.getenv("VXM_KS_PASS")
    signingConfigs {
        if (ksPass != null) create("vietmitv") {
            storeFile = file(System.getenv("VXM_KS_FILE") ?: "D:/DATA/TEST/VietMITV/vietmitv-release.jks")
            storePassword = ksPass
            keyAlias = "vietmitv"
            keyPassword = System.getenv("VXM_KEY_PASS") ?: ksPass
            enableV1Signing = false   // bỏ v1 (JAR) để không thể vá kiểu cũ
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release {
            isMinifyEnabled = true        // R8: rút gọn + làm rối mã
            isShrinkResources = true      // bỏ tài nguyên thừa, giảm dung lượng
            isDebuggable = false
            isJniDebuggable = false
            isPseudoLocalesEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Ký khi có VXM_KS_PASS (build-release.ps1); không có thì AGP cảnh báo release chưa ký (debug vẫn build được)
            signingConfig = signingConfigs.findByName("vietmitv")
        }
    }

    // Không nhúng danh sách phụ thuộc vào APK (bớt lộ thông tin cho người dịch ngược)
    dependenciesInfo { includeInApk = false; includeInBundle = false }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/*.version", "META-INF/*.kotlin_module", "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA",
                "kotlin/**", "**/*.kotlin_builtins", "DebugProbesKt.bin", "META-INF/versions/**"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.anthropic:anthropic-java:3.3.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.mlkit:translate:17.0.3")
}
