﻿param([string]$SigningProperties = (Join-Path $PSScriptRoot "release-private/signing.properties"))
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$gradle = Join-Path $env:USERPROFILE '.gradle\wrapper\dists\gradle-8.11.1-bin\bpt9gzteqjrbo1mjrsomdt32c\gradle-8.11.1\bin\gradle.bat'
if (-not (Test-Path -LiteralPath $gradle)) { throw 'Cần Gradle 8.11.1.' }
if (-not (Test-Path -LiteralPath $SigningProperties)) { throw 'Thiếu khóa release riêng. Xem RELEASE.md; không dùng khóa debug thay thế.' }
& $gradle "-PreleaseSigningProperties=$((Resolve-Path -LiteralPath $SigningProperties).Path)" --offline --no-daemon :app:assembleRelease :app:testDebugUnitTest :app:lintRelease
if ($LASTEXITCODE -ne 0) { throw 'Build hoặc kiểm tra thất bại.' }
$releaseOutput = 'dist\release-1.0.15-universal'
New-Item -ItemType Directory -Path $releaseOutput -Force | Out-Null
Copy-Item -LiteralPath 'app\build\outputs\apk\release\app-release.apk' -Destination (Join-Path $releaseOutput 'HONOR-DEBLOAT-1.0.15.apk') -Force
New-Item -ItemType Directory -Path 'release-records\1.0.15' -Force | Out-Null
Copy-Item -LiteralPath 'app\build\outputs\mapping\release\mapping.txt' -Destination 'release-records\1.0.15\mapping.txt' -Force
Get-ChildItem -LiteralPath $releaseOutput -Filter '*.apk' | Get-FileHash -Algorithm SHA256 | ForEach-Object { $_.Hash + '  ' + (Split-Path -Leaf $_.Path) } | Set-Content -Encoding UTF8 (Join-Path $releaseOutput 'SHA256SUMS.txt')
Get-ChildItem -LiteralPath $releaseOutput -Filter '*.apk' | Select-Object Name,Length

