package com.vxm.honor;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.net.nsd.*;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public final class MainActivity extends Activity {
    private WebView web;
    private LocalAdb adb;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private JSONArray catalog, logs;
    private JSONObject completeCatalog;
    private JSONArray scannedPackages=new JSONArray();
    private final Set<String> protectedPackages=new HashSet<>();
    private final Set<String> allowedPackages = new HashSet<>();
    private final Map<String,String> titles = new HashMap<>();
    private final Map<String,String> packageStatus = new HashMap<>();
    private JSONArray userApps=new JSONArray(),systemApps=new JSONArray();
    private JSONObject setupStatus=new JSONObject();
    private JSONObject localeReport=new JSONObject();
    private JSONObject permissionReport=new JSONObject();
    private JSONObject profileReport=new JSONObject();
    private JSONObject confirmation;
    private JSONObject opEditor;
    private Work confirmationWork;
    private boolean busy;
    private boolean ready;
    private JSONObject updateInfo = new JSONObject();
    private String updateStatus = "Chưa kiểm tra";
    private boolean checkingUpdate;
    private final ExecutorService updateWorker=Executors.newSingleThreadExecutor();
    private String model = Build.MODEL, cloud = "?", connection = "Chưa kết nối";
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private boolean resumed;
    private boolean automaticDiscovery;
    private final Runnable reconnect=new Runnable() {
        @Override public void run() {
            if(!resumed || prefs.getBoolean("autoConnectPaused",false))return;
            if(discovery==null && !busy && confirmation==null && (adb==null || !adb.isConnected()))
                findWirelessConnection(false);
            if(prefs.getBoolean("wirelessKnown",false))mainHandler.postDelayed(this,25000);
        }
    };

    @Override public void onCreate(Bundle saved) {
        setTheme(R.style.AppTheme);
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(39,48,57));
        getWindow().setNavigationBarColor(Color.rgb(39,48,57));
        prefs = getSharedPreferences("honor", MODE_PRIVATE);
        try {
            try (InputStream input = getAssets().open("packages.json")) {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int count;
                while ((count = input.read(buffer)) != -1) bytes.write(buffer,0,count);
                catalog = new JSONArray(bytes.toString(StandardCharsets.UTF_8.name()));
            }
            try(InputStream input=getAssets().open("honor-complete.json"); ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
                byte[] buffer=new byte[4096];
                int n;
                while((n=input.read(buffer))!=-1)bytes.write(buffer,0,n);
                completeCatalog=new JSONObject(bytes.toString(StandardCharsets.UTF_8.name()));
            }
            logs = new JSONArray(prefs.getString("logs", "[]"));
            for (int i=0;i<catalog.length();i++) {
                JSONObject p = catalog.getJSONObject(i);
                allowedPackages.add(p.getString("id")); titles.put(p.getString("id"), p.getString("name"));
            }
        } catch (Exception e) { throw new IllegalStateException("Không đọc được danh mục", e); }
        web = new WebView(this);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.setBackgroundColor(Color.rgb(39,48,57));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.getSettings().setGeolocationEnabled(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "Honor");
        web.setWebViewClient(new WebViewClient() {
            // openRawResource supports file-backed font resources; share one TTF with the native theme.
            @android.annotation.SuppressLint("ResourceType")
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("https".equals(u.getScheme()) && "honor.vxm.local".equals(u.getHost()) && "/".equals(u.getPath())) {
                    try { return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html")); }
                    catch(IOException ignored) {}
                }
                if ("https".equals(u.getScheme()) && "honor.vxm.local".equals(u.getHost()) && "/fonts/google-sans.ttf".equals(u.getPath())) {
                    try { return new WebResourceResponse("font/ttf", null, getResources().openRawResource(R.font.google_sans)); }
                    catch(android.content.res.Resources.NotFoundException ignored) {}
                }
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public void onPageFinished(WebView view, String url) {
                ready=true; render();
                if(System.currentTimeMillis()-prefs.getLong("updateChecked",0)>86400000L) checkUpdate(false);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        getWindow().getInsetsController().setSystemBarsAppearance(
                0,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        // Respect Android's window insets without depending on a CSS guess for the status bar.
        root.setOnApplyWindowInsetsListener((v,insets) -> {
            android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.ime());
            v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets;
        });
        web.loadUrl("https://honor.vxm.local/");
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
    }

    private static final int PICK_GBOARD=71, PICK_STORE=72;
    private static final String GBOARD="com.google.android.inputmethod.latin";
    private static final String STORE="com.android.vending";
    private static final String GOOGLE_ASSISTANT="com.google.android.googlequicksearchbox";
    private static final List<String> NOTIFICATION_APPS=List.of(
            "com.google.android.gms","com.vietinbank.ipay","com.facebook.pages.app","com.huawei.health",
            "com.zing.zalo","com.facebook.orca","org.telegram.messenger","com.google.android.gm",
            GOOGLE_ASSISTANT,"com.google.android.apps.bard","com.google.android.ims");

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if((request!=PICK_GBOARD && request!=PICK_STORE) || result!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        String id=request==PICK_GBOARD?GBOARD:STORE;
        confirm("Cài "+(request==PICK_GBOARD?"Gboard":"CH Play")+"?", "Kiểm tra SHA-256 của APK trước khi cài qua self ADB.\n"+id,
                ()->installSetupApk(uri,request));
    }

    private void installSetupApk(Uri uri,int request) throws Exception {
        boolean gboard=request==PICK_GBOARD;
        if(gboard && !Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a"))
            throw new IOException("APK Gboard trong bộ cài chỉ hỗ trợ arm64-v8a");
        String id=gboard?GBOARD:STORE;
        String hash=gboard?"0bbc448e570f4042692c850f8b5a19458e009d245c5f099bff3c0415574c2402":
                "29c8e5d27da59b61a1418ef369a3f903af9b82f4107fbdc2ccd6b33305658f62";
        long size=gboard?80701877:112037919;
        File apk=File.createTempFile("honor-setup-", ".apk", getCacheDir());
        try {
            java.security.MessageDigest digest=java.security.MessageDigest.getInstance("SHA-256");
            try(InputStream input=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(apk)) {
                if(input==null)throw new IOException("Không đọc được APK");
                byte[] buffer=new byte[65536];
                long total=0;
                int n;
                while((n=input.read(buffer))!=-1) {
                    total+=n;
                    if(total>size)throw new IOException("APK không khớp kích thước bộ cài");
                    digest.update(buffer,0,n);
                    out.write(buffer,0,n);
                }
                StringBuilder actual=new StringBuilder();
                for(byte value:digest.digest())actual.append(String.format(Locale.ROOT,"%02x",value&255));
                if(total!=size || !hash.contentEquals(actual))throw new IOException("APK không khớp SHA-256 của bộ cài");
            }
            LocalAdb a=manager();
            String result=a.install(apk);
            boolean installed=Arrays.asList(result.split("\\R")).contains("Success")
                    && packages(a.shell("pm list packages --user 0 "+id)).contains(id);
            log("Cài APK",installed,id+"\n"+result);
            if(installed)refresh();
        } finally { apk.delete(); }
    }

    private Set<String> protectedAppIds() {
        Set<String> ids=new HashSet<>(Arrays.asList("android",getPackageName(),"com.android.systemui",
                "com.android.settings","com.android.phone","com.android.providers.settings",
                "com.android.permissioncontroller","com.google.android.permissioncontroller",
                "com.android.packageinstaller","com.google.android.packageinstaller"));
        ResolveInfo home=getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),PackageManager.MATCH_DEFAULT_ONLY);
        if(home!=null && home.activityInfo!=null)ids.add(home.activityInfo.packageName);
        String keyboard=Settings.Secure.getString(getContentResolver(),Settings.Secure.DEFAULT_INPUT_METHOD);
        if(keyboard!=null && keyboard.contains("/"))ids.add(keyboard.substring(0,keyboard.indexOf('/')));
        return ids;
    }

    private LocalAdb manager() throws Exception { if(adb==null) adb=new LocalAdb(this); return adb; }
    private void task(String name, Work work) {
        runOnUiThread(() -> {
            if(busy) return;
            busy=true; render();
            worker.execute(() -> {
                try { work.run(); }
                catch(Exception e) { log(name, false, e.getMessage()==null ? e.getClass().getSimpleName() : e.getMessage()); }
                finally { runOnUiThread(() -> { busy=false; render(); }); }
            });
        });
    }
    interface Work { void run() throws Exception; }
    private synchronized void log(String title, boolean ok, String detail) {
        try {
            JSONObject entry=new JSONObject().put("title",title).put("ok",ok).put("detail",detail).put("time",System.currentTimeMillis());
            JSONArray next=new JSONArray(); next.put(entry);
            for(int i=0;i<Math.min(logs.length(),99);i++) next.put(logs.get(i));
            logs=next; prefs.edit().putString("logs",logs.toString()).apply();
            runOnUiThread(()->{if(ready&&!isDestroyed())web.evaluateJavascript("window.notifyResult("+entry+")",null);});
        } catch(JSONException ignored) {}
    }
    private void render() {
        if(!ready || isDestroyed()) return;
        try {
            JSONObject state=new JSONObject().put("catalog",catalog).put("logs",logs).put("busy",busy)
                    .put("version",BuildConfig.VERSION_NAME).put("updateInfo",updateInfo)
                    .put("updateStatus",updateStatus).put("checkingUpdate",checkingUpdate)
                    .put("connected",adb!=null && adb.isConnected()).put("connection",connection).put("model",model)
                    .put("cloud",cloud).put("systemApps",systemApps).put("localeReport",localeReport).put("localeSupported",Build.VERSION.SDK_INT>=33)
                    .put("confirmation",confirmation==null?JSONObject.NULL:confirmation).put("opEditor",opEditor==null?JSONObject.NULL:opEditor).put("status",packageSnapshot())
                    .put("scannedPackages",scannedPackages).put("userApps",userApps)
                    .put("backgroundApps",new JSONArray(backgroundApps())).put("permissionReport",permissionReport)
                    .put("profileReport",profileReport).put("profileBackups",new JSONObject(prefs.getString("profileBackups","{}")))
                    .put("setup",setupStatus)
                    .put("playProtectDone",prefs.getBoolean("playProtectDone",false))
                    .put("appsReady",prefs.getBoolean("appsReady",false))
                    .put("saved",new JSONObject(prefs.getString("originals","{}")))
                    .put("port",prefs.getString("port",""))
                    .put("systemReduceMotion",Settings.Global.getFloat(getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1)==0);
            web.evaluateJavascript("window.receiveState("+state+")",null);
        } catch(Exception ignored) {}
    }
    private JSONObject packageSnapshot() { synchronized(packageStatus) { return new JSONObject(packageStatus); } }
    private void refresh() throws Exception {
        LocalAdb a=manager();
        Set<String> installed=packages(a.shell("pm list packages --user 0"));
        Set<String> disabled=packages(a.shell("pm list packages -d --user 0"));
        synchronized(packageStatus) {
            Set<String> visible=new HashSet<>(allowedPackages);visible.addAll(protectedPackages);
            for(String p:visible) packageStatus.put(p, !installed.contains(p)?"missing":disabled.contains(p)?"disabled":"enabled");
        }
        cloud=a.shell("settings get system package_installer_state");
        boolean google=installed.contains("com.google.android.gsf") && installed.contains("com.google.android.gms")
                && !disabled.contains("com.google.android.gsf") && !disabled.contains("com.google.android.gms")
                && (!"HONOR".equalsIgnoreCase(Build.MANUFACTURER)
                    || "1".equals(a.shell("settings --user 0 get secure google_service_status")));
        setupStatus=new JSONObject().put("google",google)
                .put("cloud",!installed.contains("com.hihonor.systemmanager") || "0".equals(cloud))
                .put("scanner",!installed.contains("com.hihonor.securitypluginbase") || disabled.contains("com.hihonor.securitypluginbase"))
                .put("store",installed.contains(STORE)).put("gboard",installed.contains(GBOARD));

        model=a.shell("getprop ro.product.model");
        connection="Đã xác thực shell nội bộ";
    }
    private void scanPackages() throws Exception {
        Set<String> ids=packages(manager().shell("pm list packages --user 0"));
        PackageManager pm=getPackageManager();
        Set<String> core=protectedAppIds();
        List<JSONObject> rows=new ArrayList<>();
        for(String id:ids) {
            if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"))continue;
            String label=id;boolean blocked=core.contains(id), removable=false;
            try { ApplicationInfo info=pm.getApplicationInfo(id,0);label=pm.getApplicationLabel(info).toString();blocked|=info.uid%100000<10000;removable=!blocked && (info.flags & (ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))==0; }
            catch(PackageManager.NameNotFoundException e) { blocked=true; }
            boolean known=false;
            for(int i=0;i<catalog.length();i++)if(id.equals(catalog.getJSONObject(i).getString("id"))){known=true;break;}
            rows.add(new JSONObject().put("id",id).put("name",label).put("group",known?"Danh mục":"Chưa đánh giá")
                    .put("caution",true).put("protected",blocked).put("removable",removable)
                    .put("completeAction",completeCatalog.optString(id)).put("description",blocked?"Thành phần được bảo vệ; không cho thay đổi trong app.":known?"Có trong danh mục debloat tham chiếu.":"Gói chưa được đánh giá. Tắt có thể làm mất tính năng hoặc ảnh hưởng hệ thống."));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));
        for(JSONObject row:rows) {
            String id=row.getString("id");titles.put(id,row.getString("name"));
            if(row.getBoolean("protected")){protectedPackages.add(id);allowedPackages.remove(id);}
            else allowedPackages.add(id);
        }
        scannedPackages=new JSONArray(rows);refresh();
        log("Quét toàn bộ",true,rows.size()+" gói; chưa chọn gói nào tự động.");
    }
    private Set<String> backgroundApps() {
        return new TreeSet<>(prefs.getStringSet("backgroundApps",new HashSet<>(NOTIFICATION_APPS)));
    }

    private void loadUserApps() throws Exception {
        Set<String> ids=packages(manager().shell("pm list packages -3 --user 0"));
        List<JSONObject> rows=new ArrayList<>();
        PackageManager pm=getPackageManager();
        for(String id:ids) {
            String label=id;
            try {label=pm.getApplicationLabel(pm.getApplicationInfo(id,0)).toString();}catch(PackageManager.NameNotFoundException ignored){}
            rows.add(new JSONObject().put("id",id).put("name",label));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));
        userApps=new JSONArray(rows);
        if(!ids.contains(permissionReport.optString("id")))permissionReport=new JSONObject();
    }
    private void readPermissions(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -3 --user 0")).contains(id))
            throw new IOException("Chỉ đọc app người dùng còn cài trên user 0");
        permissionReport=new JSONObject();
        String dump=manager().shell("dumpsys package "+id);
        Map<String,PermissionDump.Entry> parsed=PermissionDump.parse(dump);
        JSONArray rows=new JSONArray();PackageManager pm=getPackageManager();
        for(PermissionDump.Entry entry:parsed.values()) {
            String label=entry.id,type="Không xác định",protection="";boolean editable=false;
            try {
                PermissionInfo info=pm.getPermissionInfo(entry.id,0);
                label=info.loadLabel(pm).toString();
                type=switch(info.getProtection()){case PermissionInfo.PROTECTION_NORMAL->"Thông thường";case PermissionInfo.PROTECTION_DANGEROUS->"Runtime";case PermissionInfo.PROTECTION_SIGNATURE->"Chữ ký";default->"Đặc biệt";};
                protection="0x"+Integer.toHexString(info.protectionLevel);
                editable=PermissionDump.canChange(info.protectionLevel,entry.flags);
                if(entry.granted==null && android.os.Process.myUserHandle().equals(UserHandle.getUserHandleForUid(0)))
                    entry.granted=pm.checkPermission(entry.id,id)==PackageManager.PERMISSION_GRANTED;
            }catch(PackageManager.NameNotFoundException ignored){}
            rows.put(new JSONObject().put("id",entry.id).put("name",label).put("type",type).put("protection",protection)
                    .put("editable",editable).put("granted",entry.granted==null?JSONObject.NULL:entry.granted).put("flags",entry.flags));
        }
        String ops=manager().shell("cmd appops get --user 0 "+id);
        int uid=getPackageManager().getApplicationInfo(id,0).uid;
        JSONObject current=new JSONObject()
                .put("background",ProfileState.opAllowed(manager().shell("cmd appops get --user 0 "+id+" RUN_IN_BACKGROUND"),"RUN_IN_BACKGROUND")
                        &&ProfileState.opAllowed(manager().shell("cmd appops get --user 0 "+id+" RUN_ANY_IN_BACKGROUND"),"RUN_ANY_IN_BACKGROUND"))
                .put("doze",ProfileState.whitelisted(manager().shell("dumpsys deviceidle whitelist"),id))
                .put("dataSaver",ProfileState.uidListed(manager().shell("cmd netpolicy list restrict-background-whitelist"),uid))
                .put("overlay",ProfileState.opAllowed(manager().shell("cmd appops get --user 0 "+id+" SYSTEM_ALERT_WINDOW"),"SYSTEM_ALERT_WINDOW"))
                .put("fullScreen",ProfileState.opAllowed(manager().shell("cmd appops get --user 0 "+id+" USE_FULL_SCREEN_INTENT"),"USE_FULL_SCREEN_INTENT"));
        permissionReport=new JSONObject().put("id",id).put("permissions",rows).put("appops",ops).put("current",current).put("token",UUID.randomUUID().toString());
    }
    private ApplicationInfo requireSystemApp(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -s --user 0")).contains(id))
            throw new IOException("Chỉ áp dụng app hệ thống trên user 0");
        ApplicationInfo app=getPackageManager().getApplicationInfo(id,0);
        if((app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))==0 || !languageApp(app))
            throw new IOException("App hệ thống không có giao diện mở được");
        return app;
    }
    private boolean languageApp(ApplicationInfo app) {
        return app.enabled && (getPackageManager().getLaunchIntentForPackage(app.packageName)!=null
                || app.packageName.equals("com.android.packageinstaller") || app.packageName.equals("com.google.android.packageinstaller"));
    }
    private void loadSystemApps() throws Exception {
        Set<String> installed=packages(manager().shell("pm list packages -s --user 0"));
        List<JSONObject> rows=new ArrayList<>();PackageManager pm=getPackageManager();
        for(ApplicationInfo app:pm.getInstalledApplications(0)) {
            if(installed.contains(app.packageName) && (app.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0 && languageApp(app))
                rows.add(new JSONObject().put("id",app.packageName).put("name",pm.getApplicationLabel(app).toString()));
        }
        rows.sort(Comparator.comparing(x->x.optString("name"),String.CASE_INSENSITIVE_ORDER));systemApps=new JSONArray(rows);
    }
    private Set<String> supportedLocales(ApplicationInfo app,StringBuilder source) throws Exception {
        Set<String> tags=new TreeSet<>();
        if(Build.VERSION.SDK_INT>=33) {
            Context context=createPackageContext(app.packageName,0);
            android.app.LocaleConfig config=Build.VERSION.SDK_INT>=34
                    ? android.app.LocaleConfig.fromContextIgnoringOverride(context) : new android.app.LocaleConfig(context);
            if(config.getStatus()==android.app.LocaleConfig.STATUS_SUCCESS && config.getSupportedLocales()!=null) {
                LocaleList locales=config.getSupportedLocales();for(int i=0;i<locales.size();i++)tags.add(locales.get(i).toLanguageTag());
                if(Build.VERSION.SDK_INT>=35 && config.getDefaultLocale()!=null)tags.add(config.getDefaultLocale().toLanguageTag());
                source.append("localeConfig");return tags;
            }
        }
        tags.addAll(ApkLocales.read(app.sourceDir));
        if(app.splitSourceDirs!=null)for(String split:app.splitSourceDirs)tags.addAll(ApkLocales.read(split));
        source.append("APK");return tags;
    }
    private void readSystemLocales(String id) throws Exception {
        if(Build.VERSION.SDK_INT<33)throw new IOException("Đổi ngôn ngữ từng app cần Android 13");
        ApplicationInfo app=requireSystemApp(id);StringBuilder source=new StringBuilder();Set<String> tags=supportedLocales(app,source);
        JSONArray locales=new JSONArray();for(String tag:tags)locales.put(new JSONObject().put("id",tag).put("name",Locale.forLanguageTag(tag).getDisplayName(Locale.forLanguageTag("vi"))+" · "+tag));
        String raw=manager().shell("cmd locale get-app-locales "+id+" --user 0");Matcher m=Pattern.compile("\\[(.*?)]").matcher(raw);
        localeReport=new JSONObject().put("token",UUID.randomUUID().toString()).put("id",id).put("name",getPackageManager().getApplicationLabel(app).toString())
                .put("locales",locales).put("source",source.toString()).put("current",m.find()?m.group(1):"");
    }
    private void changeSystemLocale(String id,String tag) throws Exception {
        if(Build.VERSION.SDK_INT<33)throw new IOException("Đổi ngôn ngữ từng app cần Android 13");
        ApplicationInfo app=requireSystemApp(id);
        if(!tag.isEmpty() && (!tag.matches("[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*") || !supportedLocales(app,new StringBuilder()).contains(tag)))
            throw new IOException("Ngôn ngữ không có trong danh sách của app");
        String result=manager().shell("cmd locale set-app-locales "+id+" --user 0"+(tag.isEmpty()?"":" --locales "+tag));
        readSystemLocales(id);
        boolean ok=tag.equals(localeReport.optString("current"));
        log("Ngôn ngữ ứng dụng",ok,id+" → "+(tag.isEmpty()?"Theo hệ thống":tag)+"\n"+result);
    }
    private void requireUserApp(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !packages(manager().shell("pm list packages -3 --user 0")).contains(id))
            throw new IOException("Chỉ áp dụng app người dùng trên user 0");
    }
    private void changePermission(String id,String permission,boolean grant) throws Exception {
        requireUserApp(id);
        PermissionDump.Entry entry=PermissionDump.parse(manager().shell("dumpsys package "+id)).get(permission);
        if(entry==null)throw new IOException("App không khai báo quyền này");
        PermissionInfo info=getPackageManager().getPermissionInfo(permission,0);
        if(!PermissionDump.canChange(info.protectionLevel,entry.flags))throw new IOException("Quyền này do hệ thống hoặc chính sách quản lý");
        if(!permission.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+"))throw new IOException("Tên quyền không hợp lệ");
        String output=manager().shell("pm "+(grant?"grant":"revoke")+" --user 0 "+id+" "+permission);
        readPermissions(id);
        Boolean after=null;
        JSONArray rows=permissionReport.getJSONArray("permissions");
        for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);
            if(permission.equals(row.getString("id")) && !row.isNull("granted"))after=row.getBoolean("granted");
        }
        if(after==null || after!=grant)throw new IOException("ROM không đổi quyền: "+output);
        log(grant?"Đã cấp quyền":"Đã thu hồi quyền",true,id+"\n"+permission);
    }
    private void changeAppOp(String id,String op,String mode,String scope) throws Exception {
        requireUserApp(id);
        if(!op.matches("[A-Z][A-Z0-9_]*") || !Set.of("allow","ignore","deny","foreground","default").contains(mode)
                || !Set.of("app","uid").contains(scope))throw new IOException("AppOps không hợp lệ");
        String before=manager().shell("cmd appops get --user 0 "+id+" "+op);
        if(before.contains("Error") || before.contains("Unknown"))throw new IOException(before);
        String output=manager().shell("cmd appops set --user 0 "+(scope.equals("uid")?"--uid ":"")+id+" "+op+" "+mode);
        String check=manager().shell("cmd appops get --user 0 "+id+" "+op);
        AppOpState after=AppOpState.parse(check,op);
        readPermissions(id);
        if(output.contains("Error") || output.contains("Exception") || !mode.equals(scope.equals("uid")?after.uid:after.app))
            throw new IOException("ROM không giữ chế độ yêu cầu: "+output+"\n"+check);
        log("Đã đổi AppOps",true,id+"\n"+op+" · "+scope+" · "+mode);
    }
    static Set<String> packages(String result) {
        Set<String> items=new HashSet<>();
        for(String line:result.split("\\r?\\n")) if(line.startsWith("package:")) items.add(line.substring(8).trim());
        return items;
    }
    static int enabledState(String dump) throws IOException {
        Matcher m=Pattern.compile("(?m)^    User 0:.*?\\benabled=(\\d+)").matcher(dump);
        if(!m.find()) throw new IOException("Không đọc được trạng thái gốc user 0");
        return Integer.parseInt(m.group(1));
    }
    private void remember(String id, Object value) throws JSONException, IOException {
        JSONObject originals=new JSONObject(prefs.getString("originals","{}"));
        if(!originals.has(id)) {
            originals.put(id,value);
            // Persist before issuing a shell mutation, even if the process is killed afterwards.
            if(!prefs.edit().putString("originals",originals.toString()).commit()) throw new IOException("Không lưu được trạng thái hoàn tác; đã dừng trước khi thay đổi.");
        }
    }
    private void changePackage(String p, boolean disable) throws Exception { changePackage(p,disable,false); }
    private void changePackage(String p, boolean disable, boolean enable) throws Exception {
        if(protectedPackages.contains(p) || protectedAppIds().contains(p) || !allowedPackages.contains(p)) throw new IOException("Gói không thuộc danh sách được phép");
        LocalAdb a=manager();
        if(!packages(a.shell("pm list packages --user 0")).contains(p)) { log(titles.get(p),false,"Không có gói này trên máy; đã bỏ qua."); return; }
        int before=enabledState(a.shell("dumpsys package "+p));
        if(disable && (before==2 || before==3 || before==4)) { log(titles.get(p),true,"Đã tắt từ trước; giữ nguyên trạng thái."); return; }
        JSONObject originals=new JSONObject(prefs.getString("originals","{}"));
        if(!disable && !enable && !originals.has(p)) { log(titles.get(p),false,"Không có bản ghi thay đổi từ app này để hoàn tác."); return; }
        int wanted=enable?1:disable?3:originals.getInt(p);
        remember(p,before);
        String verb=switch(wanted){case 0->"default-state";case 1->"enable";case 2->"disable";case 3->"disable-user";case 4->"disable-until-used";default->throw new IOException("Trạng thái gói không hỗ trợ");};
        String result=a.shell("pm "+verb+(wanted==3?" ":" --user 0 ")+p);
        int after=enabledState(a.shell("dumpsys package "+p));
        boolean ok=after==wanted;
        if(ok && !disable && !enable) { originals.remove(p); prefs.edit().putString("originals",originals.toString()).commit(); }
        log(titles.get(p),ok,(ok?(enable?"Đã bật. ":disable?"Đã tắt. ":"Đã hoàn tác. "):"ROM không cho đổi hoặc không đạt trạng thái yêu cầu. ")+result);
    }
    private void feature(String id) throws Exception {
        LocalAdb a=manager(); String output,check;
        switch(id) {
            case "cloud-off", "cloud-on" -> {
                if(!packages(a.shell("pm list packages --user 0")).contains("com.hihonor.systemmanager")) throw new IOException("Không thấy trình quản lý HONOR; không áp dụng công tắc cloud cho máy này.");
                String old=a.shell("settings get system package_installer_state");
                remember("cloudValue",old);
                String wanted=id.equals("cloud-off")?"0":"1";
                output=a.shell("settings put system package_installer_state "+wanted);
                check=a.shell("settings get system package_installer_state");
                log("Kiểm tra cloud APK",wanted.equals(check),"Giá trị đọc lại: "+check+"\n"+output);
            }
            case "scanner-off" -> changePackage("com.hihonor.securitypluginbase",true);
            case "scanner-on" -> {
                String p="com.hihonor.securitypluginbase";
                int old=enabledState(a.shell("dumpsys package "+p)); remember(p,old);
                output=a.shell("pm enable --user 0 "+p);
                check=a.shell("dumpsys package "+p);
                log("Bật lại plugin quét",enabledState(check)==1,output);
            }
            default -> throw new IOException("Thao tác không hợp lệ");
        }
        refresh();
    }
    private void confirm(String title,String text,Work work) {
        runOnUiThread(() -> {
            if(busy) return;
            if(confirmationWork!=null)return;
            try {confirmation=new JSONObject().put("id",UUID.randomUUID().toString()).put("title",title).put("text",text);}
            catch(JSONException e){throw new IllegalStateException(e);}
            confirmationWork=work;render();
        });
    }
    @Override protected void onResume() {
        super.onResume();
        resumed=true;
        scheduleReconnect();
    }

    @Override protected void onPause() {
        resumed=false;
        mainHandler.removeCallbacks(reconnect);
        if(automaticDiscovery)stopDiscovery();
        super.onPause();
    }

    private void scheduleReconnect() {
        mainHandler.removeCallbacks(reconnect);
        if(resumed)mainHandler.post(reconnect);
    }

    private void findWirelessConnection(boolean requested) {
        connection="Đang dò cổng Wireless Debugging…";
        discover("_adb-tls-connect._tcp.",port->{
            if(!requested && !resumed)return;
            if(busy || confirmation!=null || (adb!=null && adb.isConnected()))return;
            task("Kết nối Wireless ADB",()->{
                try {
                    connectLocal(port);
                    prefs.edit().putBoolean("wirelessKnown",true).apply();
                    runOnUiThread(()->{
                        mainHandler.removeCallbacks(reconnect);
                        if(resumed)mainHandler.postDelayed(reconnect,25000);
                    });
                } catch(Exception e) {
                    connection="Chưa kết nối · Kiểm tra ghép đôi";
                    if(requested)throw e;
                }
            });
        },requested?"Không tìm thấy cổng. Bật Gỡ lỗi không dây hoặc nhập cổng thủ công.":null);
        automaticDiscovery=!requested && discovery!=null;
        render();
    }

    private void connectLocal(int port) throws Exception {
        LocalAdb a=manager();
        if(a.isConnected())a.disconnect();
        try {
            if(!a.connect("127.0.0.1",port))throw new IOException("Không kết nối được. Kiểm tra cổng kết nối và ghép đôi.");
            if(!a.shell("id").contains("uid=2000(shell)"))
                throw new IOException("Kết nối không có quyền shell ADB");
            refresh();
        } catch(Exception e) {
            if(a.isConnected())a.disconnect();
            throw e;
        }
        prefs.edit().putString("port",String.valueOf(port)).apply();
        log("Kết nối self ADB",true,"Đã xác thực uid=2000(shell) trên "+model);
    }

    private static final String PAIR_CHANNEL="wireless_pairing";
    private static final String PAIR_REPLY="pair_code";
    private static final int PAIR_NOTICE=91, PAIR_PERMISSION=92;
    private PendingIntent pairingReply;
    private BroadcastReceiver pairingReceiver;
    private long pairingDeadline;

    private void startPairingNotification() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},PAIR_PERMISSION);
            return;
        }
        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(PAIR_CHANNEL,"Ghép đôi Wireless Debugging",NotificationManager.IMPORTANCE_HIGH));
        if(!manager.areNotificationsEnabled() || manager.getNotificationChannel(PAIR_CHANNEL).getImportance()==NotificationManager.IMPORTANCE_NONE) {
            log("Ghép đôi Wireless ADB",false,"Bật thông báo HONOR DEBLOAT hoặc nhập mã trong app.");
            return;
        }
        endPairingNotification();
        String action=getPackageName()+".PAIR."+UUID.randomUUID();
        pairingReceiver=new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if(SystemClock.elapsedRealtime()>=pairingDeadline || pairingReply==null)return;
                Bundle results=RemoteInput.getResultsFromIntent(intent);
                CharSequence code=results==null?null:results.getCharSequence(PAIR_REPLY);
                if(code==null || !code.toString().trim().matches("[0-9]{6}")) {
                    showPairingNotification("Nhập đúng mã gồm 6 chữ số.",true);
                    return;
                }
                if(busy) {
                    showPairingNotification("App đang xử lý. Thử gửi lại sau vài giây.",true);
                    return;
                }
                if(pairingInProgress)return;
                pairingInProgress=true;
                showPairingNotification("Đang dò cổng và ghép đôi…",false);
                String digits=code.toString().trim();
                discover("_adb-tls-pairing._tcp.",port->pairAt(String.valueOf(port),digits,true),
                        "Không tìm thấy cổng ghép đôi. Mở lại hộp mã và nhập mã mới.",
                        ()->pairingRetry("Không tìm thấy cổng. Giữ hộp mã mở và thử lại."));
            }
        };
        IntentFilter filter=new IntentFilter(action);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(pairingReceiver,filter,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(pairingReceiver,filter);
        pairingReply=PendingIntent.getBroadcast(this,0,new Intent(action).setPackage(getPackageName()),PendingIntent.FLAG_MUTABLE);
        pairingDeadline=SystemClock.elapsedRealtime()+180000;
        showPairingNotification("Mở hộp mã trong Cài đặt, kéo thanh thông báo và bấm Nhập mã.",true);
        mainHandler.postDelayed(expirePairing,180000);
        openWirelessSettings(0);
    }

    private boolean pairingInProgress;
    private final Runnable expirePairing=this::endPairingNotification;

    private void pairingRetry(String message) {
        pairingInProgress=false;
        showPairingNotification(message,true);
    }

    private void showPairingNotification(String message,boolean canReply) {
        if(pairingReply==null || SystemClock.elapsedRealtime()>=pairingDeadline)return;
        Notification.Builder notice=new Notification.Builder(this,PAIR_CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Ghép đôi Wireless Debugging").setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setOnlyAlertOnce(true).setTimeoutAfter(pairingDeadline-SystemClock.elapsedRealtime());
        if(canReply)notice.addAction(new Notification.Action.Builder(null,"Nhập mã",pairingReply)
                .addRemoteInput(new RemoteInput.Builder(PAIR_REPLY).setLabel("Mã ghép đôi 6 số").build())
                .setAllowGeneratedReplies(false).setSemanticAction(Notification.Action.SEMANTIC_ACTION_REPLY).build());
        getSystemService(NotificationManager.class).notify(PAIR_NOTICE,notice.build());
    }

    private void endPairingNotification() {
        mainHandler.removeCallbacks(expirePairing);
        pairingInProgress=false;
        if(pairingReply!=null)pairingReply.cancel();
        pairingReply=null;
        if(pairingReceiver!=null)unregisterReceiver(pairingReceiver);
        pairingReceiver=null;
        getSystemService(NotificationManager.class).cancel(PAIR_NOTICE);
    }

    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if(request!=PAIR_PERMISSION)return;
        if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)startPairingNotification();
        else log("Ghép đôi Wireless ADB",false,"Cần quyền thông báo để nhập mã từ thanh thông báo.");
    }

    private void openWirelessSettings(int flags) {
        for(String action : new String[]{"android.settings.WIRELESS_DEBUGGING_SETTINGS",
                Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,Settings.ACTION_SETTINGS}) {
            try { startActivity(new Intent(action).addFlags(flags)); return; }
            catch(ActivityNotFoundException | SecurityException ignored) {}
        }
    }

    private void discover(String service, java.util.function.IntConsumer found, String failure) {
        discover(service,found,failure,()->{});
    }

    private void discover(String service, java.util.function.IntConsumer found, String failure, Runnable onFailure) {
        stopDiscovery();
        nsd=(NsdManager)getSystemService(NSD_SERVICE);
        NsdManager.DiscoveryListener listener=new NsdManager.DiscoveryListener() {
            private void fail() {
                runOnUiThread(()->{
                    if(discovery!=this)return;
                    stopDiscovery();
                    if(service.equals("_adb-tls-connect._tcp."))connection="Chưa kết nối";
                    if(failure!=null)log("Wireless ADB",false,failure);
                    onFailure.run();
                    render();
                });
            }
            public void onDiscoveryStarted(String t) {}
            public void onDiscoveryStopped(String t) {}
            public void onStartDiscoveryFailed(String t,int e) { fail(); }
            public void onStopDiscoveryFailed(String t,int e) {}
            public void onServiceLost(NsdServiceInfo s) {}
            public void onServiceFound(NsdServiceInfo s) {
                NsdManager.DiscoveryListener active=this;
                nsd.resolveService(s,new NsdManager.ResolveListener() {
                    public void onResolveFailed(NsdServiceInfo i,int e) {}
                    public void onServiceResolved(NsdServiceInfo i) {
                        try {
                            if(i.getHost()==null || !isLocal(i.getHost()) || i.getPort()<1 || i.getPort()>65535)return;
                            runOnUiThread(()->{
                                if(discovery!=active)return;
                                stopDiscovery();found.accept(i.getPort());render();
                            });
                        } catch(SocketException ignored) {}
                    }
                });
            }
        };
        discovery=listener;
        try { nsd.discoverServices(service,NsdManager.PROTOCOL_DNS_SD,listener); }
        catch(RuntimeException e) { listener.onStartDiscoveryFailed(service,0); }
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            if(discovery==listener)listener.onStartDiscoveryFailed(service,0);
        },10000);
    }
    static boolean isLocal(InetAddress address) throws SocketException {
        return address.isLoopbackAddress() || NetworkInterface.getByInetAddress(address)!=null;
    }
    private void stopDiscovery() { automaticDiscovery=false; if(discovery!=null){try{nsd.stopServiceDiscovery(discovery);}catch(Exception ignored){} discovery=null;} }

    private void checkUpdate(boolean manual) {
        if(checkingUpdate) return;
        checkingUpdate=true; updateStatus="Đang kiểm tra…"; render();
        updateWorker.execute(()->{
            JSONObject result=new JSONObject(); String status;
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL("https://vietng228.github.io/honor/update.json").openConnection();
                connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
                connection.setInstanceFollowRedirects(false); connection.setUseCaches(false);
                if(connection.getResponseCode()!=200)throw new IOException("Máy chủ chưa sẵn sàng");
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                try(InputStream input=connection.getInputStream()) {
                    byte[] buffer=new byte[2048]; int count;
                    while((count=input.read(buffer))!=-1) {
                        if(bytes.size()+count>32768)throw new IOException("Thông tin cập nhật quá lớn");
                        bytes.write(buffer,0,count);
                    }
                }
                JSONObject data=new JSONObject(bytes.toString(StandardCharsets.UTF_8.name()));
                if(!getPackageName().equals(data.getString("packageName"))
                        || !UpdatePolicy.allowedDownload(data.getString("apkUrl"))
                        || !data.getString("sha256").matches("[a-fA-F0-9]{64}"))
                    throw new IOException("Thông tin cập nhật không hợp lệ");
                int code=data.getInt("versionCode");
                if(code>BuildConfig.VERSION_CODE) {
                    result=data;
                    status=data.getInt("minSdk")>Build.VERSION.SDK_INT?"Bản mới cần Android mới hơn":"Có bản mới: "+data.getString("versionName");
                    result.put("compatible",data.getInt("minSdk")<=Build.VERSION.SDK_INT);
                } else status="Bạn đang dùng bản mới nhất";
                prefs.edit().putLong("updateChecked",System.currentTimeMillis()).apply();
            } catch(Exception e) { status=manual?"Chưa kiểm tra được. Thử lại khi có mạng.":"Chưa kiểm tra được"; }
            finally { if(connection!=null)connection.disconnect(); }
            JSONObject next=result; String message=status;
            runOnUiThread(()->{updateInfo=next;updateStatus=message;checkingUpdate=false;render();});
        });
    }

    public final class Bridge {
        @JavascriptInterface public void applyProfile(String id,String options) {
            if(!id.equals(permissionReport.optString("id")))return;
            task("Chuẩn bị profile",()->{
                if("default".equals(new JSONObject(options).optString("preset"))) {
                    requireUserApp(id);readPermissions(id);
                    profileReport=new JSONObject().put("id",id).put("text","Mặc định: giữ nguyên quyền và thiết lập hiện tại.");
                    log("Mặc định",true,id+" · Giữ nguyên trạng thái hiện tại");return;
                }
                requireUserApp(id);PermissionProfile engine=new PermissionProfile(command->manager().shell(command),getPackageManager(),prefs);
                JSONArray plan=engine.plan(id,options);
                String preset=new JSONObject(options).optString("preset");
                String profileName=switch(preset){case "notify"->"Cấp quyền thông báo";case "default"->"Mặc định";default->"Tùy chỉnh";};
                StringBuilder text=new StringBuilder(profileName+"\n"+id+"\n\n");
                for(int i=0;i<plan.length();i++)text.append("• ").append(plan.getJSONObject(i).getString("label")).append('\n');
                if(plan.length()==0)text.append("Các mục đã chọn đã đúng trạng thái.\n");
                text.append("\nBa công tắc khởi chạy HONOR cần bật trong cài đặt của máy.\nKhông thu hồi quyền không được chọn.");
                runOnUiThread(()->{busy=false;confirm("Áp dụng profile?",text.toString(),()->{
                    String result=engine.apply(id,plan);boolean ok=!result.contains("! ");
                    profileReport=new JSONObject().put("id",id).put("text",result+"\nHONOR: cần kiểm tra Auto-launch, Secondary launch, Run in background trong cài đặt.");
                    readPermissions(id);log("Profile ứng dụng",ok,id+"\n"+profileReport.getString("text"));
                });render();});
            });
        }
        @JavascriptInterface public void restoreProfile(String id) {
            if(!id.equals(permissionReport.optString("id")))return;
            confirm("Hoàn tác profile?",id+"\nKhôi phục các quyền và thiết lập do profile đã thay đổi. Không đổi ba công tắc HONOR.",()->{
                requireUserApp(id);String result=new PermissionProfile(command->manager().shell(command),getPackageManager(),prefs).restore(id);
                profileReport=new JSONObject().put("id",id).put("text",result);readPermissions(id);log("Hoàn tác profile",!result.contains("! "),id+"\n"+result);
            });
        }
        @JavascriptInterface public void openHonorLaunch(String id) { task("Mở thiết lập khởi chạy",()->{
            requireUserApp(id);int uid=getPackageManager().getApplicationInfo(id,0).uid;
            String output=manager().shell("am start --user 0 -n com.hihonor.systemmanager/.power.ui.DetailOfSoftConsumptionActivity --ei uid "+uid+" --es package "+id);
            if(output.contains("Error")||output.contains("Exception"))
                manager().shell("am start --user 0 -a android.settings.APPLICATION_DETAILS_SETTINGS -d package:"+id);
        }); }
        @JavascriptInterface public void checkUpdate() { runOnUiThread(()->MainActivity.this.checkUpdate(true)); }
        @JavascriptInterface public void downloadUpdate() { runOnUiThread(()->{
            String url=updateInfo.optString("apkUrl");
            if(!updateInfo.optBoolean("compatible") || !UpdatePolicy.allowedDownload(url))return;
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); }
            catch(ActivityNotFoundException e) { log("Cập nhật",false,"Cần trình duyệt để tải APK."); }
        }); }
        @JavascriptInterface public void state() { runOnUiThread(()->render()); }
        @JavascriptInterface public void openDebugging() { runOnUiThread(()->openWirelessSettings(
                Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)); }
        @JavascriptInterface public void pairFromNotification() { runOnUiThread(()->{
            if(!busy && !pairingInProgress)startPairingNotification();
        }); }
        @JavascriptInterface public void setAppearance() { runOnUiThread(()->{
            prefs.edit().remove("light").apply();
            setTheme(R.style.AppTheme);
            int color=Color.rgb(39,48,57);
            getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);web.setBackgroundColor(color);
            getWindow().getDecorView().setBackgroundColor(color);
            int mask=android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            getWindow().getInsetsController().setSystemBarsAppearance(0,mask);
        }); }
        @JavascriptInterface public void autoConnect() { runOnUiThread(()->{
            if(busy || confirmation!=null || (adb!=null && adb.isConnected()))return;
            prefs.edit().remove("autoConnectPaused").apply();
            findWirelessConnection(true);
        }); }
        @JavascriptInterface public void connect(String port) { runOnUiThread(()->{
            if(busy)return;
            stopDiscovery();
            prefs.edit().remove("autoConnectPaused").apply();
            task("Kết nối self ADB",()->connectLocal(parsePort(port)));
        }); }
        @JavascriptInterface public void pair(String port,String code) { runOnUiThread(()->{
            if(busy)return;
            if(!code.matches("[0-9]{6}")) {
                log("Ghép đôi Wireless ADB",false,"Mã ghép đôi phải gồm 6 chữ số");return;
            }
            if(port.isEmpty())discover("_adb-tls-pairing._tcp.",n->pairAt(String.valueOf(n),code,false),
                    "Không tìm thấy cổng ghép đôi. Giữ hộp mã mở hoặc nhập cổng thủ công.");
            else { stopDiscovery();pairAt(port,code,false); }
        }); }
        @JavascriptInterface public void disconnect() { runOnUiThread(()->{
            if(busy)return;
            prefs.edit().putBoolean("autoConnectPaused",true).apply();
            mainHandler.removeCallbacks(reconnect);
            stopDiscovery();
            task("Ngắt self ADB",()->{
                if(adb!=null)adb.disconnect();
                connection="Đã ngắt kết nối";
                log("Ngắt self ADB",true,"Đã dừng tự kết nối. Bấm Tự kết nối để bật lại.");
            });
        }); }
        @JavascriptInterface public void answerConfirmation(String token,boolean accept) { runOnUiThread(()->{
            if(confirmation==null || !token.equals(confirmation.optString("id")))return;
            Work work=confirmationWork;String title=confirmation.optString("title");confirmation=null;confirmationWork=null;render();
            if(accept)task(title,work);
        }); }
        @JavascriptInterface public void permissionChange(String id,String permission,boolean grant) {
            if(!id.equals(permissionReport.optString("id")))return;
            JSONArray rows=permissionReport.optJSONArray("permissions");if(rows==null)return;
            for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);
                if(row!=null && permission.equals(row.optString("id")) && row.optBoolean("editable")) {
                    confirm(grant?"Cấp quyền?":"Thu hồi quyền?",row.optString("name")+"\n"+id+"\n"+permission,()->changePermission(id,permission,grant));return;
                }
            }
        }
        @JavascriptInterface public void inspectAppOp(String id,String op) { task("Đọc AppOps",()->{
            requireUserApp(id);
            if(!op.matches("[A-Z][A-Z0-9_]*"))throw new IOException("AppOps không hợp lệ");
            String raw=manager().shell("cmd appops get --user 0 "+id+" "+op);
            if(raw.contains("Error")||raw.contains("Unknown"))throw new IOException(raw);
            AppOpState modes=AppOpState.parse(raw,op);
            opEditor=new JSONObject().put("token",UUID.randomUUID().toString()).put("id",id).put("op",op)
                    .put("app",modes.app).put("uid",modes.uid).put("defaultMode",modes.fallback);
        }); }
        @JavascriptInterface public void closeAppOp() { runOnUiThread(()->{opEditor=null;render();}); }
        @JavascriptInterface public void appOpChange(String id,String op,String mode,String scope) {
            if(!id.equals(permissionReport.optString("id")) || !op.matches("[A-Z][A-Z0-9_]*"))return;
            if(!Pattern.compile("(?m)^(?:Uid mode: )?"+Pattern.quote(op)+": ").matcher(permissionReport.optString("appops")).find())return;
            String shared="";
            if(scope.equals("uid")) {
                try {String[] names=getPackageManager().getPackagesForUid(getPackageManager().getApplicationInfo(id,0).uid);
                    if(names!=null && names.length>1)shared="\nUID dùng chung: "+String.join(", ",names);
                }catch(PackageManager.NameNotFoundException ignored){}
            }
            runOnUiThread(()->opEditor=null);
            confirm("Đổi AppOps?",op+" → "+mode+"\n"+id+"\n"+(scope.equals("uid")?"UID":"Ứng dụng")+shared,()->changeAppOp(id,op,mode,scope));
        }
        @JavascriptInterface public void listSystemApps() { task("Đọc app hệ thống",()->loadSystemApps()); }
        @JavascriptInterface public void systemLocales(String id) { task("Đọc ngôn ngữ",()->readSystemLocales(id)); }
        @JavascriptInterface public void systemLocaleChange(String id,String tag) {
            if(!id.equals(localeReport.optString("id")))return;
            String label="Theo hệ thống";
            if(!tag.isEmpty()) {label=null;JSONArray rows=localeReport.optJSONArray("locales");if(rows==null)return;
                for(int i=0;i<rows.length();i++)if(tag.equals(rows.optJSONObject(i).optString("id")))label=rows.optJSONObject(i).optString("name");
                if(label==null)return;
            }
            confirm("Đổi ngôn ngữ?",localeReport.optString("name")+"\n"+id+"\n"+label,()->changeSystemLocale(id,tag));
        }
        @JavascriptInterface public void pickSetupApk(String kind) { runOnUiThread(()->{
            if(busy || confirmation!=null || adb==null || !adb.isConnected())return;
            int request="gboard".equals(kind)?PICK_GBOARD:"store".equals(kind)?PICK_STORE:0;
            if(request==0)return;
            Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            try { startActivityForResult(picker,request); }
            catch(ActivityNotFoundException e) { log("Chọn APK",false,"Máy không có trình chọn tệp."); }
        }); }

        @JavascriptInterface public void setupGoogle() { confirm("Bật dịch vụ Google?", 
                "Bật Google Basic Services, Google Services Framework và Google Play services cho user 0 trên HONOR.",()->{
            LocalAdb a=manager();
            if(!"HONOR".equalsIgnoreCase(Build.MANUFACTURER))throw new IOException("Công tắc Google Basic Services chỉ dành cho HONOR");
            Set<String> ids=packages(a.shell("pm list packages --user 0"));
            for(String id:List.of("com.google.android.gsf","com.google.android.gms"))
                if(!ids.contains(id))throw new IOException("Thiếu gói "+id);
            a.shell("settings --user 0 put secure google_service_status 1");
            if(!"1".equals(a.shell("settings --user 0 get secure google_service_status")))
                throw new IOException("ROM không lưu được công tắc Google Basic Services");
            for(String id:List.of("com.google.android.gsf","com.google.android.gms")) {
                if(!packages(a.shell("pm list packages -e --user 0 "+id)).contains(id))
                    a.shell("pm enable --user 0 "+id);
                boolean enabled=packages(a.shell("pm list packages -e --user 0 "+id)).contains(id);
                log("Dịch vụ Google",enabled,id+(enabled?" · Đang bật":" · ROM chưa bật được"));
            }
            refresh();
        }); }

        @JavascriptInterface public void confirmSetupStep(String step) { runOnUiThread(()->{
            if(busy || adb==null || !adb.isConnected())return;
            if("playProtectDone".equals(step)) {
                if(!setupStatus.optBoolean("google") || !setupStatus.optBoolean("store"))return;
            } else if("appsReady".equals(step)) {
                if(!prefs.getBoolean("playProtectDone",false)
                        || !setupStatus.optBoolean("google") || !setupStatus.optBoolean("cloud")
                        || !setupStatus.optBoolean("scanner") || !setupStatus.optBoolean("gboard")
                        || !setupStatus.optBoolean("store"))return;
            } else return;
            prefs.edit().putBoolean(step,true).apply();
            render();
        }); }

        @JavascriptInterface public void openPlayProtect() { runOnUiThread(()->{
            Intent store=getPackageManager().getLaunchIntentForPackage(STORE);
            if(store!=null) {
                try { startActivity(store);return; }
                catch(ActivityNotFoundException | SecurityException ignored) {}
            }
            log("Play Protect",false,"CH Play chưa mở được. Cài hoặc bật CH Play rồi quay lại bước này.");
        }); }

        @JavascriptInterface public void setupSettings(String kind) { runOnUiThread(()->{
            String action=switch(kind){
                case "keyboard"->Settings.ACTION_INPUT_METHOD_SETTINGS;
                case "assistant"->Settings.ACTION_VOICE_INPUT_SETTINGS;
                default->null;
            };
            if(action==null)return;
            try { startActivity(new Intent(action)); }
            catch(ActivityNotFoundException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        }); }

        @JavascriptInterface public void setupPowerAssistant() { confirm("Gọi trợ lý khi giữ nút nguồn?",
                "Chọn Google làm trợ lý trong Cài đặt trước. MagicOS có thể dùng thiết lập nút nguồn riêng.",()->{
            LocalAdb a=manager();
            String assistant=a.shell("settings --user 0 get secure assistant");
            if(!assistant.startsWith(GOOGLE_ASSISTANT+"/"))throw new IOException("Chưa đọc được Google là trợ lý mặc định");
            String before=a.shell("settings get global power_button_long_press");
            if(!before.matches("null|[0-9]+"))throw new IOException("Không đọc được thiết lập nút nguồn");
            if(!"5".equals(before)) {
                if(!prefs.contains("setupPowerBefore") && !prefs.edit().putString("setupPowerBefore",before).commit())
                    throw new IOException("Không lưu được thiết lập để hoàn tác");
                a.shell("settings put global power_button_long_press 5");
            }
            boolean saved="5".equals(a.shell("settings get global power_button_long_press"));
            log("Giữ nút nguồn",saved,saved?"Đã lưu giá trị 5. Thử giữ nút nguồn để kiểm tra MagicOS.":"ROM không lưu được giá trị 5.");
        }); }

        @JavascriptInterface public void restoreSetupPower() { confirm("Hoàn tác giữ nút nguồn?",
                "Khôi phục giá trị nút nguồn lưu từ lần áp dụng đầu tiên.",()->{
            String before=prefs.getString("setupPowerBefore","");
            if(!before.matches("null|[0-9]+"))throw new IOException("Chưa có giá trị nút nguồn để hoàn tác");
            LocalAdb a=manager();
            if("null".equals(before))a.shell("settings delete global power_button_long_press");
            else a.shell("settings put global power_button_long_press "+before);
            boolean restored=before.equals(a.shell("settings get global power_button_long_press"));
            if(restored)prefs.edit().remove("setupPowerBefore").apply();
            log("Hoàn tác nút nguồn",restored,"Giá trị cần khôi phục: "+before);
        }); }

        @JavascriptInterface public void selectBackgroundApp(String id,boolean selected) { runOnUiThread(()->{
            if(busy || confirmation!=null || !ProfileState.validPackage(id) || getPackageName().equals(id))return;
            Set<String> apps=backgroundApps();
            if(selected) {
                boolean installed=false;
                for(int i=0;i<userApps.length();i++)
                    if(id.equals(userApps.optJSONObject(i).optString("id"))){installed=true;break;}
                if(!installed)return;
                apps.add(id);
            } else apps.remove(id);
            prefs.edit().putStringSet("backgroundApps",apps).apply();
            render();
        }); }

        @JavascriptInterface public void setupNotifications(boolean apply) { task("Chạy nền cho ứng dụng",()->{
            Set<String> installed=packages(manager().shell("pm list packages --user 0"));
            Set<String> user=packages(manager().shell("pm list packages -3 --user 0"));
            PermissionProfile engine=new PermissionProfile(command->manager().shell(command),getPackageManager(),prefs);
            String options="{\"preset\":\"honorBackground\",\"background\":true,\"doze\":true}";
            Map<String,JSONArray> plans=new LinkedHashMap<>();
            StringBuilder report=new StringBuilder();
            for(String id:backgroundApps()) {
                report.append(id).append(" · ");
                if(!installed.contains(id))report.append("Chưa cài");
                else if(!user.contains(id))report.append("Gói hệ thống, bỏ qua");
                else try {
                    JSONArray plan=engine.plan(id,options);
                    report.append(plan.length()==0?"Đã đúng trạng thái":plan.length()+" mục sẽ đổi");
                    if(plan.length()>0)plans.put(id,plan);
                } catch(Exception e) { report.append(e.getMessage()); }
                report.append('\n');
            }
            if(!apply) {
                LocalAdb a=manager();
                report.append("\nTrợ lý: ").append(a.shell("settings --user 0 get secure assistant"))
                        .append("\nDịch vụ giọng nói: ").append(a.shell("settings --user 0 get secure voice_interaction_service"))
                        .append("\nGiữ nút nguồn: ").append(a.shell("settings get global power_button_long_press"))
                        .append("\nTiết kiệm pin: ").append(a.shell("settings get global low_power"));
            }
            if(!apply || plans.isEmpty()) { log("Rà soát chạy nền",true,report.toString());return; }
            report.append("\nThay đổi AppOps chạy nền và miễn Doze. Hoàn tác từng app trong tab Quyền.");
            confirm("Cho phép chạy nền?",report.toString(),()->{
                for(var entry:plans.entrySet()) {
                    String id=entry.getKey();
                    try {
                        String result=engine.apply(id,entry.getValue());
                        log("Chạy nền",!result.contains("! "),id+"\n"+result);
                    } catch(Exception e) { log("Chạy nền",false,id+"\n"+e.getMessage()); }
                }
            });
        }); }

        @JavascriptInterface public void scanPackages() { task("Quét toàn bộ",()->MainActivity.this.scanPackages()); }
        @JavascriptInterface public void listUserApps() { task("Đọc app người dùng",()->loadUserApps()); }
        @JavascriptInterface public void permissions(String id) { task("Đọc quyền",()->readPermissions(id)); }
        @JavascriptInterface public void refreshState() { task("Làm mới",()->{refresh();log("Làm mới",true,"Đã đọc lại trạng thái gói và tiện ích.");}); }
        @JavascriptInterface public void uninstallBatch(String json) { task("Kiểm tra gói để gỡ",()->{
            JSONArray raw=new JSONArray(json);
            Set<String> ids=new LinkedHashSet<>();
            for(int i=0;i<raw.length();i++)ids.add(raw.getString(i));
            if(ids.isEmpty())return;
            for(String id:ids)verifyUninstallTarget(id);
            StringBuilder text=new StringBuilder("Gỡ khỏi thiết bị và xóa dữ liệu ứng dụng. Không thể hoàn tác.\n\n");
            for(String id:ids)text.append(titles.get(id)).append(" · ").append(id).append("\n");
            confirm("Gỡ hẳn "+ids.size()+" ứng dụng?",text.toString(),()->{
                for(String id:ids) {
                    try {
                        verifyUninstallTarget(id);
                        String result=manager().shell("pm uninstall "+id).trim();
                        boolean removed="Success".equals(result) &&
                                !packages(manager().shell("pm list packages --user 0")).contains(id);
                        log("Gỡ ứng dụng",removed,id+"\n"+result);
                    } catch(Exception e) { log("Gỡ ứng dụng",false,id+"\n"+e.getMessage()); }
                }
                scanPackages();loadUserApps();
            });
        }); }
        private void verifyUninstallTarget(String id) throws Exception {
            if(!id.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+") || !allowedPackages.contains(id)
                    || protectedPackages.contains(id) || getPackageName().equals(id))
                throw new IOException("Gói không hợp lệ: "+id);
            PackageManager pm=getPackageManager();
            ApplicationInfo info=pm.getApplicationInfo(id,0);
            ResolveInfo home=pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),PackageManager.MATCH_DEFAULT_ONLY);
            String keyboard=Settings.Secure.getString(getContentResolver(),Settings.Secure.DEFAULT_INPUT_METHOD);
            if((info.flags & (ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0 || info.uid%100000<10000
                    || (home!=null && home.activityInfo!=null && id.equals(home.activityInfo.packageName))
                    || (keyboard!=null && keyboard.startsWith(id+"/")))
                throw new IOException("Không thể gỡ gói hệ thống hoặc đang được bảo vệ: "+id);
        }
        @JavascriptInterface public void batch(String json,boolean disable) { batchAction(json,disable,false); }
        @JavascriptInterface public void enableBatch(String json) { batchAction(json,false,true); }
        private void batchAction(String json,boolean disable,boolean enable) {
            try {
                JSONArray raw=new JSONArray(json); LinkedHashSet<String> ids=new LinkedHashSet<>();
                for(int i=0;i<raw.length();i++){String p=raw.getString(i);if(protectedPackages.contains(p) || !allowedPackages.contains(p))throw new IOException("Gói không hợp lệ");ids.add(p);}
                if(ids.isEmpty())return;
                StringBuilder description=new StringBuilder(enable?"Bật các gói đã chọn.\n\n":disable?"Tắt cho user 0; không xóa dữ liệu.\n\n":"Hoàn tác về trạng thái app đã lưu, không tự bật gói vốn đã tắt trước đó.\n\n");
                for(String p:ids)description.append("• ").append(titles.get(p)).append("\n").append(p).append("\n");
                if(disable && scannedPackages.length()>0)description.append("\nGói quét thêm chưa được đánh giá an toàn; tắt có thể ảnh hưởng tính năng hệ thống.");
                confirm(enable?"Bật "+ids.size()+" gói đã chọn?":disable?"Tắt "+ids.size()+" gói đã chọn?":"Hoàn tác "+ids.size()+" gói?",description.toString(),()->{
                    for(String p:ids){try{changePackage(p,disable,enable);}catch(Exception e){log(titles.get(p),false,e.getMessage());}}
                    refresh();
                });
            }catch(Exception e){log("Thao tác không hợp lệ",false,e.getMessage());}
        }
        @JavascriptInterface public void utility(String id) {
            String text=switch(id){
                case "cloud-off"->"Tắt Enhanced service của trình cài APK. Kiểm tra cloud của trình cài đặt sẽ bị bỏ qua; quét cục bộ vẫn còn.";
                case "cloud-on"->"Bật lại Enhanced service của trình cài APK HONOR.";
                case "scanner-off"->"Tắt gói com.hihonor.securitypluginbase, gồm Qihoo, AVL và plugin chống gian lận. Giảm bảo vệ APK của HONOR; không tắt Phone Manager hoặc Play Protect.";
                case "scanner-on"->"Bật lại gói plugin quét APK HONOR (Qihoo / AVL / chống gian lận).";
                default->null;
            };
            if(text!=null)confirm("Xác nhận tiện ích",text,()->feature(id));
        }
    }
    static int parsePort(String value) throws IOException {
        try { int n=Integer.parseInt(value);if(n<1||n>65535)throw new NumberFormatException();return n; }
        catch(NumberFormatException e){throw new IOException("Cổng phải nằm trong khoảng 1–65535");}
    }
    private void handleBack() { web.evaluateJavascript("window.dismissTopDialog()",value->{if(!"true".equals(value))finish();}); }
    @Override public void onBackPressed() { handleBack(); }
    private void pairAt(String port,String code,boolean fromNotification) { task("Ghép đôi Wireless ADB",()->{
        try {
            if(!manager().pair("127.0.0.1",parsePort(port),code))
                throw new IOException("Ghép đôi thất bại; mã có thể đã hết hạn");
        } catch(Exception e) {
            if(fromNotification)runOnUiThread(()->pairingRetry("Ghép đôi thất bại. Mở lại hộp mã và nhập mã mới."));
            throw e;
        }
        prefs.edit().remove("autoConnectPaused").putBoolean("wirelessKnown",true).apply();
        log("Ghép đôi Wireless ADB",true,"Đã ghép đôi. Đang tìm cổng kết nối.");
        runOnUiThread(()->{
            if(fromNotification)endPairingNotification();
            findWirelessConnection(true);
            mainHandler.removeCallbacks(reconnect);
            if(resumed)mainHandler.postDelayed(reconnect,25000);
        });
    }); }
    @Override protected void onDestroy(){endPairingNotification();mainHandler.removeCallbacks(reconnect);stopDiscovery();worker.shutdownNow();updateWorker.shutdownNow();if(adb!=null)try{adb.close();}catch(IOException ignored){} web.removeJavascriptInterface("Honor");web.destroy();super.onDestroy();}
}
