package com.vxm.honor;

import android.content.SharedPreferences;
import android.content.pm.*;
import org.json.*;
import java.io.IOException;
import java.util.*;

/** Validated, per-user-app changes with saved prior states and read-back verification. */
final class PermissionProfile {
    interface Shell { String run(String command) throws Exception; }
    private final Shell shell;
    private final PackageManager pm;
    private final SharedPreferences prefs;
    PermissionProfile(Shell shell,PackageManager pm,SharedPreferences prefs) { this.shell=shell;this.pm=pm;this.prefs=prefs; }
    private int requireApp(String id) throws Exception {
        if(!ProfileState.validPackage(id))throw new IOException("Package không hợp lệ");
        ApplicationInfo app=pm.getApplicationInfo(id,0);
        if((app.flags&ApplicationInfo.FLAG_SYSTEM)!=0 || app.uid%100000<10000)
            throw new IOException("Profile chỉ áp dụng app người dùng");
        String installed=shell.run("pm list packages -3 --user 0 "+id);
        if(!MainActivity.packages(installed).contains(id))throw new IOException("App không còn cài trên user 0");
        return app.uid;
    }
    JSONArray plan(String id,String selection) throws Exception {
        int uid=requireApp(id);JSONObject options=new JSONObject(selection);JSONArray steps=new JSONArray();
        Map<String,PermissionDump.Entry> permissions=PermissionDump.parse(shell.run("dumpsys package "+id));
        if("default".equals(options.optString("preset")))return steps;
        if("notify".equals(options.optString("preset"))) {
            final String notification="android.permission.POST_NOTIFICATIONS";
            PermissionDump.Entry entry=permissions.get(notification);
            if(entry==null || entry.granted==null)throw new IOException("App không có quyền Thông báo có thể cấp qua ADB");
            options=new JSONObject().put("permissions",new JSONArray().put(notification));
        }
        JSONArray selected=options.optJSONArray("permissions");Set<String> seen=new HashSet<>();
        if(selected!=null)for(int i=0;i<selected.length();i++) {
            String name=selected.getString(i);if(!seen.add(name))continue;
            if(!ProfileState.validPackage(name))throw new IOException("Tên quyền không hợp lệ");
            if(ProfileState.isLocationPermission(name))throw new IOException("Profile không sử dụng quyền vị trí");
            PermissionDump.Entry entry=permissions.get(name);
            if(entry==null || entry.granted==null)throw new IOException("Không đọc được quyền "+name);
            PermissionInfo info=pm.getPermissionInfo(name,0);
            if((info.getProtection()!=PermissionInfo.PROTECTION_DANGEROUS)
                    || !PermissionDump.canChange(info.protectionLevel,entry.flags))
                throw new IOException("Quyền do hệ thống quản lý: "+name);
            if(!entry.granted)steps.put(step("permission",name,"",info.loadLabel(pm).toString(),"true"));
        }
        String[] peers=pm.getPackagesForUid(uid);boolean shared=peers!=null&&peers.length>1;
        if(options.optBoolean("background")) {
            if(shared)throw new IOException("UID dùng chung: không tự đổi chính sách chạy nền của nhiều app");
            List<String> operations="honorBackground".equals(options.optString("preset"))
                    ?List.of("RUN_IN_BACKGROUND","RUN_ANY_IN_BACKGROUND")
                    :List.of("RUN_IN_BACKGROUND","RUN_ANY_IN_BACKGROUND","WAKE_LOCK");
            for(String op:operations) {
                String raw=shell.run("cmd appops get --user 0 "+id+" "+op);
                if(raw.contains("Unknown")||raw.contains("Error"))throw new IOException("ROM không hỗ trợ "+op);
                AppOpState state=AppOpState.parse(raw,op);
                steps.put(step("op",op,"app",op,"allow"));
                if(!state.uid.equals("default"))steps.put(step("op",op,"uid",op+" · UID","allow"));
            }
        }
        if(options.optBoolean("doze"))steps.put(step("idle","","","Miễn tối ưu Doze","true"));
        if(options.optBoolean("dataSaver")) {
            if(shared)throw new IOException("UID dùng chung: không tự đổi Data Saver");
            steps.put(step("network","","","Dữ liệu nền khi bật Data Saver","true"));
        }
        for(String key:List.of("overlay","fullScreen"))if(options.optBoolean(key)) {
            String permission=key.equals("overlay")?"android.permission.SYSTEM_ALERT_WINDOW":"android.permission.USE_FULL_SCREEN_INTENT";
            if(!permissions.containsKey(permission))throw new IOException("App không khai báo "+permission);
            steps.put(step("op",key.equals("overlay")?"SYSTEM_ALERT_WINDOW":"USE_FULL_SCREEN_INTENT","app",
                    key.equals("overlay")?"Hiển thị trên ứng dụng khác":"Cuộc gọi toàn màn hình","allow"));
            String op=key.equals("overlay")?"SYSTEM_ALERT_WINDOW":"USE_FULL_SCREEN_INTENT";
            AppOpState modes=AppOpState.parse(shell.run("cmd appops get --user 0 "+id+" "+op),op);
            if(!modes.uid.equals("default")) {
                if(shared)throw new IOException("UID dùng chung: không đổi quyền đặc biệt cho nhiều app");
                steps.put(step("op",op,"uid",op+" · UID","allow"));
            }
        }
        if(steps.length()>100)throw new IOException("Quá nhiều thay đổi");
        JSONArray changes=new JSONArray();
        for(int i=0;i<steps.length();i++) {
            JSONObject step=steps.getJSONObject(i);String before=read(id,uid,step);
            if(!before.equals(step.getString("wanted")))changes.put(step.put("before",before));
        }
        return changes;
    }
    private JSONObject step(String kind,String name,String scope,String label,String wanted) throws JSONException {
        return new JSONObject().put("kind",kind).put("name",name).put("scope",scope).put("label",label).put("wanted",wanted);
    }
    private String read(String id,int uid,JSONObject step) throws Exception {
        String kind=step.getString("kind"),name=step.getString("name");
        return switch(kind) {
            case "permission" -> {
                PermissionDump.Entry row=PermissionDump.parse(shell.run("dumpsys package "+id)).get(name);
                if(row==null||row.granted==null)throw new IOException("Không đọc được quyền "+name);
                yield row.granted.toString();
            }
            case "op" -> {
                String raw=shell.run("cmd appops get --user 0 "+id+" "+name);
                if(raw.contains("Error")||raw.contains("Unknown"))throw new IOException(raw);
                AppOpState state=AppOpState.parse(raw,name);
                yield step.getString("scope").equals("uid")?state.uid:state.app;
            }
            case "idle" -> String.valueOf(ProfileState.whitelisted(shell.run("dumpsys deviceidle whitelist"),id));
            case "network" -> String.valueOf(ProfileState.uidListed(shell.run("cmd netpolicy list restrict-background-whitelist"),uid));
            default -> throw new IOException("Thao tác profile không hợp lệ");
        };
    }
    private void write(String id,int uid,JSONObject step,String value) throws Exception {
        String output=switch(step.getString("kind")) {
            case "permission" -> shell.run("pm "+(value.equals("true")?"grant":"revoke")+" --user 0 "+id+" "+step.getString("name"));
            case "op" -> shell.run("cmd appops set --user 0 "+(step.getString("scope").equals("uid")?"--uid ":"")+id+" "+step.getString("name")+" "+value);
            case "idle" -> shell.run("dumpsys deviceidle whitelist "+(value.equals("true")?"+":"-")+id);
            case "network" -> shell.run("cmd netpolicy "+(value.equals("true")?"add":"remove")+" restrict-background-whitelist "+uid);
            default -> throw new IOException("Thao tác profile không hợp lệ");
        };
        if(!read(id,uid,step).equals(value))throw new IOException("ROM không giữ trạng thái: "+output);
    }
    synchronized String apply(String id,JSONArray plan) throws Exception {
        int uid=requireApp(id);JSONObject all=new JSONObject(prefs.getString("profileBackups","{}"));
        JSONArray backup=all.optJSONArray(id);if(backup==null)backup=new JSONArray();
        Set<String> saved=new HashSet<>();for(int i=0;i<backup.length();i++)saved.add(key(backup.getJSONObject(i)));
        for(int i=0;i<plan.length();i++) {
            JSONObject step=plan.getJSONObject(i);
            // Capture at execution, after the user has reviewed the confirmation.
            step.put("before",read(id,uid,step));
            if(saved.add(key(step)))backup.put(new JSONObject(step.toString()));
        }
        if(backup.length()>0)all.put(id,backup);else all.remove(id);
        if(!prefs.edit().putString("profileBackups",all.toString()).commit())throw new IOException("Không lưu được hoàn tác; chưa thay đổi");
        StringBuilder result=new StringBuilder();
        for(int i=0;i<plan.length();i++) {
            JSONObject step=plan.getJSONObject(i);
            try {write(id,uid,step,step.getString("wanted"));result.append("✓ ").append(step.getString("label"));}
            catch(Exception e){result.append("! ").append(step.getString("label")).append(": ").append(e.getMessage());}
            result.append('\n');
        }
        return result.length()==0?"Các mục đã chọn đã đúng trạng thái.":result.toString();
    }
    private String key(JSONObject step) { return step.optString("kind")+":"+step.optString("name")+":"+step.optString("scope"); }
    synchronized String restore(String id) throws Exception {
        int uid=requireApp(id);JSONObject all=new JSONObject(prefs.getString("profileBackups","{}"));
        JSONArray backup=all.optJSONArray(id);if(backup==null)throw new IOException("Chưa có profile để hoàn tác");
        JSONArray remaining=new JSONArray();StringBuilder report=new StringBuilder();
        for(int i=backup.length()-1;i>=0;i--) {
            JSONObject step=backup.getJSONObject(i);
            try {write(id,uid,step,step.getString("before"));report.append("✓ ").append(step.getString("label"));}
            catch(Exception e){remaining.put(step);report.append("! ").append(step.getString("label")).append(": ").append(e.getMessage());}
            report.append('\n');
        }
        if(remaining.length()==0)all.remove(id);else all.put(id,remaining);
        if(!prefs.edit().putString("profileBackups",all.toString()).commit())throw new IOException("Không lưu được kết quả hoàn tác");
        return report.toString();
    }
}
