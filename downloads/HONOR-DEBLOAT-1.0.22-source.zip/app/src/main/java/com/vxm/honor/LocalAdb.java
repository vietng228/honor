package com.vxm.honor;

import android.content.Context;
import android.os.Build;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.concurrent.*;

/** One private, persistent ADB identity. Connections are restricted to this phone. */
final class LocalAdb extends AbsAdbConnectionManager {
    private final PrivateKey key;
    private final Certificate cert;
    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();

    LocalAdb(Context context) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        setHostAddress("127.0.0.1");
        setTimeout(15, TimeUnit.SECONDS);
        // TCP ADB may need to present the system's RSA authorization dialog first.
        setThrowOnUnauthorised(false);
        File dir = new File(context.getNoBackupFilesDir(), "adb");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Không tạo được kho khóa ADB");
        File keyFile = new File(dir, "identity.key"), certFile = new File(dir, "identity.crt");
        if (keyFile.isFile() && certFile.isFile()) {
            key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(keyFile.toPath())));
            try (InputStream in = new FileInputStream(certFile)) { cert = CertificateFactory.getInstance("X.509").generateCertificate(in); }
        } else {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048);
            java.security.KeyPair pair = generator.generateKeyPair();
            key = pair.getPrivate();
            X500Name name = new X500Name("CN=VXM HONOR Local ADB");
            var builder = new JcaX509v3CertificateBuilder(name, new BigInteger(128, new SecureRandom()),
                    new Date(System.currentTimeMillis() - 60000), new Date(System.currentTimeMillis() + 315360000000L), name, pair.getPublic());
            cert = new JcaX509CertificateConverter().getCertificate(builder.build(
                    new JcaContentSignerBuilder("SHA256withRSA").build(key)));
            Files.write(keyFile.toPath(), key.getEncoded());
            Files.write(certFile.toPath(), cert.getEncoded());
        }
    }

    @Override protected PrivateKey getPrivateKey() { return key; }
    @Override protected Certificate getCertificate() { return cert; }
    @Override protected String getDeviceName() { return "VXM HONOR"; }

    String shell(String command) throws Exception {
        return run("shell:", command, null, 20);
    }

    String install(File apk) throws Exception {
        return run("exec:", "cmd package install -r --user 0 -S " + apk.length(), apk, 180);
    }

    private String run(String service, String command, File input, int seconds) throws Exception {
        if (!isConnected()) throw new IOException("Chưa kết nối self ADB");
        String marker="__VXM_END_"+java.util.UUID.randomUUID().toString().replace("-","")+"__";
        byte[] ending=marker.getBytes(StandardCharsets.UTF_8);
        try (AdbStream stream = openStream(service + command + "; printf '\\n"+marker+"'")) {
            ScheduledFuture<?> timeout = timer.schedule(() -> { try { stream.close(); } catch (IOException ignored) {} }, seconds, TimeUnit.SECONDS);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try {
                if(input!=null) {
                    try(InputStream data=new FileInputStream(input)) {
                        byte[] chunk=new byte[32768];
                        int count;
                        while((count=data.read(chunk))!=-1)stream.write(chunk,0,count);
                        stream.flush();
                    }
                }
                byte[] buffer = new byte[4096];
                while (true) {
                    int n;
                    // Read the stream directly so queued bytes are drained even after remote CLSE.
                    try { n = stream.read(buffer, 0, buffer.length); }
                    catch (IOException e) {
                        // This transport reports a drained, normally closed shell as IOException.
                        if (stream.isClosed() && isConnected() && !timeout.isDone()) break;
                        throw e;
                    }
                    if(n == -1) break;
                    bytes.write(buffer, 0, n);
                    if (bytes.size() > 2_000_000) throw new IOException("Kết quả ADB quá lớn");
                    // A completion marker avoids waiting for a delayed remote CLSE after buffered output.
                    byte[] output=bytes.toByteArray();boolean complete=output.length>=ending.length;
                    for(int i=0;complete && i<ending.length;i++)complete=output[output.length-ending.length+i]==ending[i];
                    if(complete)return new String(output,0,output.length-ending.length,StandardCharsets.UTF_8).trim();
                }
                if (timeout.isDone()) throw new IOException("Lệnh vượt thời gian chờ; hãy làm mới trạng thái");
                throw new IOException("Phiên ADB đóng trước khi lệnh hoàn tất");
            } finally { timeout.cancel(false); }
        }
    }

    @Override public void close() throws IOException { timer.shutdownNow(); super.close(); }
}
