# Third-party components

HONOR DEBLOAT uses these unmodified libraries. Dependency archives are included in app/libs for this preview build; their sources remain available at the linked upstream projects.

| Component | Version | License / source |
|---|---|---|
| LibADB Android — Muntashir Al-Islam | 3.1.1 | Apache-2.0 option of dual license; https://github.com/MuntashirAkon/libadb-android/tree/3.1.1 |
| Spake2 Android — Muntashir Al-Islam and contributors | 2.2.1 | Upstream licenses, including LGPL components; https://github.com/MuntashirAkon/spake2-java/tree/2.2.1 |
| Conscrypt — The Android Open Source Project | 2.6.3 | Apache-2.0 with bundled upstream notices; https://github.com/google/conscrypt/tree/2.6.3 |
| Bouncy Castle provider, PKIX, utility — The Legion of the Bouncy Castle | 1.86 | Bouncy Castle license (MIT-style); https://github.com/bcgit/bc-java/tree/r1rv86 |
| AndroidX Annotation — The Android Open Source Project | 1.9.1 | Apache-2.0; https://android.googlesource.com/platform/frameworks/support/ |
| JUnit (test-only) | 4.13.2 | EPL-1.0; https://github.com/junit-team/junit4/tree/r4.13.2 |

License texts are bundled under app/src/main/assets/licenses. The application does not modify the libraries; the source project and replaceable dependency archives are supplied with the APK preview. No third-party app assets or proprietary HONOR code are redistributed.

Font: Google Sans Flex Freeze Regular, extracted from the user-supplied Google Sans Flex Freeze Regular.hwt for this requested preview. The archive did not include a separate font license.

## UAD-ng package recommendations

Source: https://github.com/Universal-Debloater-Alliance/universal-android-debloater-next-generation
Package descriptions and removal classifications are distributed under GPL-3.0. The included snapshot retains removal and description fields. See app/src/main/assets/licenses/UAD-ng-LICENSE.txt and UAD-ng-SOURCE.txt.
